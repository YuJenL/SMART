## reset

int_dir <- getwd()

# Restart SMART by closing the main window and running SMART_main.R again,
# which reloads the data files and all modules in the SMART folder.
# (The previous version sourced old dated file names that are not part of SMART 2.0.)
restartSMART <- function(){
  if (exists("tt")) try(tkdestroy(tt), silent = TRUE)
  main_file <- file.path(int_dir, "SMART_main.R")
  if (!file.exists(main_file)) {
    tkmessageBox(title = "Restart", icon = "warning",
                 message = paste("Cannot find SMART_main.R in", int_dir))
    return(invisible(NULL))
  }
  setwd(int_dir)
  source(main_file)
}
