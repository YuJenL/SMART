rm(list = ls())
gc()
library(tcltk)

# Locate the folder that contains this script, so SMART runs from wherever it is unzipped.
# Order: Rscript --file= argument -> path given to source() -> RStudio editor -> current directory.
.smart_locate_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  f <- sub("^--file=", "", args[grep("^--file=", args)])
  f <- gsub("~+~", " ", f, fixed = TRUE)   # Rscript encodes spaces in the path as ~+~
  if (length(f) > 0 && nzchar(f[1])) return(dirname(normalizePath(f[1])))
  for (i in rev(seq_len(sys.nframe()))) {
    of <- sys.frame(i)$ofile
    if (!is.null(of)) return(dirname(normalizePath(of)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    p <- tryCatch(rstudioapi::getSourceEditorContext()$path, error = function(e) "")
    if (nzchar(p)) return(dirname(normalizePath(p)))
  }
  getwd()
}
smart_dir <- .smart_locate_dir()
if (!file.exists(file.path(smart_dir, "dbMetabo.RData"))) {
  stop("Cannot find the SMART folder (dbMetabo.RData is missing): ", smart_dir,
       "\nPlease run SMART_main.R from the unzipped SMART2.0 folder, e.g. source(\"<path>/SMART2.0/SMART_main.R\").")
}
setwd(smart_dir)

getwd()

load("dbMetabo.RData")
load("function_ls.RData")
# KEGG-derived data (for IOPA) are not distributed with SMART because of KEGG license terms;
# load them only if present. See README, "License and third-party components".
for (kegg_file in c("hsaSPIA_reversible(cumulative_sum).RData", "KEGG_pathway_class.Rdata")) {
  if (file.exists(kegg_file)) load(kegg_file)
}

file <- list.files(pattern = "\\.[Rr]$")
file <- file[!grepl("SMART|Rdata|RData",file)]

file

sapply(file, function(x)source(x))


#msconvert C:/Users/yujen/AppData/Local/Apps
