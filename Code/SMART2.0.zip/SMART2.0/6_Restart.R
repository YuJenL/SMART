## reset

int_dir <- getwd()

restartSMART <- function(){
  tkdestroy(tt)
  setwd(int_dir)
  load("function_ls.RData")
  rm(list = ls())
  gc()
  source("1_Tomoya_tmp_icon_20230703.R")
  source("2_Nagisa_norm_20230705.R")
  source("3_ANCOVA_20220804.R")
  source("4_IOPA_20230703.R")
  source("5_targetd_analysis_20230531.R")
  source("6_restart_20230703.R")
  source("7_calibration_curve_20230705.R")
  source("8_Concentration_calculation_20230703.R")
 
}


            
