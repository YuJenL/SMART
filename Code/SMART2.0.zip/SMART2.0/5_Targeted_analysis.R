targeted_analysis <- function(datafilename = datafilename, params = params,target = target, mz_list = mz_list, outpath = outpath, tol_mz = tol_mz){
  
  data <- xcmsRaw(datafilename,profstep = params$prostep, profmethod = params$profmethod, includeMSn = params$includeMSn, mslevel = params$mslevel, scanrange = params$scanrange)
  filename <- gsub(".mzXML","",strsplit(data@filepath,"/")[[1]][length(strsplit(data@filepath,"/")[[1]])])
  outpath_sample <- paste0(outpath,"/",filename)
  dir.create(outpath_sample,showWarnings = F)
  target$time_l[is.na(target$time_l)] <- min(data@scantime)
  target$time_u[is.na(target$time_u)] <- max(data@scantime)
  
  
  out <- sapply(1:nrow(target), function(x){
    
    if(length(data@msnPrecursorMz)==0|is.na(target$parent_ion[x])){
      scan_id <- 1:length(data@scantime)
    }else{
      scan_id <-which(floor(data@msnPrecursorMz)==floor(target$parent_ion[x]))
    }
    
    mz <- mz_list[[x]]
    rt_time_sec <- rep(NA,length(mz))
    intensity <- rep(NA,length(mz))
    sn <- rep(NA,length(mz))
    est_mz <- rep(NA,length(mz))
    
    n_plot = length(mz)+2
    png(filename = paste0(outpath_sample,"/",filename,"_",target$Name[x],".png"), width = 1920, height = 50+450+250*(n_plot-2))
    
    par(mar=c(1,5,2,2),oma=c(2,0,2,0))
    layout(matrix(1:n_plot,ncol=1),heights = c(50,rep(250,n_plot-1),450))
    plot(0, xaxt = 'n', yaxt = 'n', bty = 'n', pch = '', ylab = '', xlab = '',xlim=c(0,10),ylim=c(0,10))
    txt <- paste0(filename,"    ",target$Name[x],"    RT=",target$Ret_Time.sec[x],"  m/z=",target$mz[x])
    text(0,10,txt,font=2,pos=4,cex=3,xpd=T)
    max_scan <- rep(NA,length(mz))
    for(ii in 1:length(mz)){
      mzL <- mz[ii]*(1-tol_mz) 
      mzU <- mz[ii]*(1+tol_mz)
      #======
      int <- sapply(1:length(scan_id), function(x) getScan(data, scan =scan_id[x] , mzrange=c(mzL,mzU)))
      if(class(int)=="list"){
        names(int) <- scan_id
        ind <- sapply(1:length(int),function(x) length(int[[x]]))
        scan <- which(ind!=0)
        
        int <- int[scan]
        
        int <- data.table(mz = do.call( rbind, int)[,1],
                          intensity = do.call( rbind, int)[,2],
                          scanid = rep(scan_id[scan],ind[scan]/2),
                          RT_sec = rep(data@scantime[scan_id[scan]],ind[scan]/2),
                          RT_min = rep(data@scantime[scan_id[scan]],ind[scan]/2)/60)
      }else{
        int <- data.table(t(int))
        colnames(int) <- c("mz","intensity")
        int$scanid <- scan_id
        int$RT_sec <- data@scantime[scan_id]
        int$RT_min <- data@scantime[scan_id]/60
      }
      
      
      if(nrow(int)!=0){
        int <- int[int[,intensity]!=0,]
        
        int <- int[int[, .I[intensity == max(intensity)], by=scanid]$V1]
        
        
        
        plot(int[,RT_min],int[,intensity]*100/max(int[,intensity]),ylim=c(0,115),type="l",xlab="",ylab="", bty = "n", lwd = 2,xlim = c(0,ceiling(max(data@scantime/60)/5)*5),las=1,cex.main=2.5, cex.lab=2.5,main=paste0("m/z = ",round(mzL,4)," - ",round(mzU,4)), xaxt="n",yaxt="n",col="gray")
        
        idx <- which(int[,"RT_sec"]>=target$time_l[x]&int[,"RT_sec"]<=target$time_u[x])
        
        
        axis(side = 2, at=seq(0,100,20),font=2,las=2, cex.axis =2)
        
        if(ii==1){
          
          text(par("usr")[1],par("usr")[4]*1,"Relative \n Abundance",font=2,cex = 2,xpd=T)}
        if(ii==length(mz)){
          mtext("RT(mins)",outer=F,line = 3,side=1,font=2,cex = 2)
          axis(side = 1, at=0:ceiling(max(data@scantime/60)/5)*5,font=2, cex.axis =2)}
        
        
        if(length(idx)!=0){
          lines(int[idx ,RT_min], int[idx ,intensity]*100/max(int[,intensity]), col = "black",lwd = 2)
          text(int[idx[which.max(int[idx,intensity])],RT_min],int[idx[which.max(int[idx,intensity])],intensity]/max(int[,intensity])*105,round(int[idx[which.max(int[idx,intensity])],RT_min],3),las=1,xpd=NA,font=2,cex = 1.8,pos = 3)
          
          max_scan[ii]<- int[idx[which.max(int[idx,intensity])],scanid]
          rt_time_sec[ii] <- round(int[idx[which.max(int[idx,intensity])],RT_min],4)*60
          
          intensity[ii] <- round(sum(int[idx,intensity]),4)
          
          sn[ii] <-  round(sd(int[idx,intensity])/mean(int[idx,intensity]),4)
          est_mz[ii] <- round(mean(int[idx,mz]),4)
        }
        
        
      }else{
        plot(0,0,ylim=c(0,120),type="l",xlab="",ylab="", bty = "n", lwd = 2,xlim = c(0,ceiling(max(data@scantime/60)/5)*5),las=1,cex.main=2.5, cex.lab=2.5,main=paste0("m/z = ",round(mzL,4)," - ",round(mzU,4)), xaxt="n",yaxt="n",col="gray")
        axis(side = 2, at=seq(0,100,20),font=2,las=2, cex.axis =2)
        
        if(ii==1){
          
          text(par("usr")[1],par("usr")[4]*1,"Relative \n Abundance",font=2,cex = 2,xpd=T)}
        if(ii==length(mz)){
          mtext("RT(mins)",outer=F,line = 3,side=1,font=2,cex = 2)
          axis(side = 1, at=0:ceiling(max(data@scantime/60)/5)*5,font=2, cex.axis =2)}
        
      }
      
    }
    max_scan_mz <- data.frame(mz=mz,max_scan=max_scan)
    max_scan <- data.frame(table(max_scan),stringsAsFactors = F)
    max_scan$Rt <- data@scantime[as.numeric(as.character(max_scan$max_scan))]
    max_scan <- max_scan[max_scan$Freq==max(max_scan$Freq) ,]
    max_scan <- max_scan[!is.na(max_scan$Freq),]
    max_scan <- max_scan[max_scan$Rt>=target$time_l[x]&max_scan$Rt<=target$time_u[x],]
    
    if(nrow(max_scan)>1&!is.na(target$Ret_Time.sec[x])){
      max_scan <- max_scan[which.min(abs(max_scan[,"Rt"]-target$Ret_Time.sec[x])),]
    }
    if(nrow(max_scan)>1){
      max_scan_mz <- max_scan_mz[max_scan_mz$max_scan%in%max_scan$max_scan,]
      max_scan <- max_scan[max_scan$max_scan%in%max_scan_mz$max_scan[which.max(max_scan_mz$mz)],]
    }
    
    if(nrow(max_scan)!=0){
      
      max_scan <- as.numeric(as.character(max_scan$max_scan[which(max_scan$Freq==max(max_scan$Freq))]))
      
      #length(max_scan)
      scan <- getScan(data, scan = max_scan)
      scan <- cbind(scan, relative=scan[,"intensity"]*100/max(scan[,"intensity"]),tmp=floor(scan[,"mz"]))
      
      tmp <- aggregate(intensity ~ tmp,scan,max)
      tmp <- merge(tmp,scan)
      tmp <- tmp[c(which(tmp$tmp%in%mz),which.max(tmp$relative)),]
      col <- ifelse(scan[,"mz"]%in%tmp[which(tmp$tmp%in%mz),"mz"],"red","black")
      scan <- cbind(scan,col=col)
      scan <- scan[order(scan[,"col"]),]
      mz_min <- data@mzrange[1]
      mz_max <- data@mzrange[2]
      
      if(mz_min%in%c(Inf,-Inf)){    mz_min <- min(as.numeric(scan[,"mz"]))}
      if(mz_max%in%c(Inf,-Inf)){    mz_max <- max(as.numeric(scan[,"mz"]))}
      plot(scan[,"mz"],scan[,"relative"],ylim=c(0,120),type="h",xlab="m/z",ylab="", bty = "n", lwd = 1,xlim = c(floor(mz_min),ceiling(mz_max)),las=1, cex.lab=2.5, cex.axis=1, xaxt='n',col=scan[,"col"],yaxt="n")
      
      title(paste0("RT = ",round(int[which(int[,"scanid"]==max_scan),"RT_min"],4)," mins scan #",max_scan), line = -2.5,cex.main=2.5)
      axis(side = 2, at=seq(0,100,20),font=2,las=2, cex.axis =2.3)
      text(par("usr")[1],par("usr")[4]*0.95,"Relative \n Abundance",font=2,cex = 2,xpd=T)
      axis(side = 1, at=seq(round(mz_min,-1),round(mz_max,-1),20),font=2, cex.axis =2.3)
      text(tmp[,"mz"],tmp[,"relative"],round(tmp[,"mz"],4),las=1,xpd=NA,font=2,cex = 1.8,pos = 3)
      
      legend("topright",legend=mz,text.col =ifelse(mz%in%tmp$tmp,"red","black"),bty="n",ncol=length(mz),cex=2, x.intersp=0.1)
    }
    
    dev.off()
    c(est_mz, intensity, rt_time_sec, sn)
  })
  
  unlist(out)
}
Align_targeted <- function(ALtitle = "Peak detection and abundance calculation (Targeted)"){
  
  citation("xcms")
  xcmscitation <- tktoplevel(); if(isIcon) tk2ico.set(xcmscitation,icon)
  tkwm.title(xcmscitation, "Citation of XCMS")
  tkpack(tklabel(xcmscitation, text="",height = 0, font = fontIntro_para))
  tkpack(tklabel(xcmscitation, text= "XCMS", font = fontHeading, justify = "left"))
  tkpack(tklabel(xcmscitation, text = "
	Smith CA, Want EJ, O'Maille G, Abagyan R, Siuzdak G. XCMS: processing mass spectrometry data for metabolite
	profiling using nonlinear peak alignment, matching, and identification. Anal Chem. 2006;78(3):779-87.

	Tautenhahn R, Bottcher C, Neumann S. Highly sensitive feature detection for high resolution LC/MS. BMC 
	Bioinformatics. 2008;9:504.

	Benton HP, Want EJ, Ebbels TM. Correction of mass calibration gaps in liquid chromatography-mass spectrometry 
	metabolomics data. Bioinformatics. 2010;26(19):2488-9.
	", justify = "left"))
  
  tkpack(tkbutton(xcmscitation, text = "  Close  ", command = function() tkdestroy(xcmscitation)))
  tkpack(tklabel(xcmscitation,text="",height = 0, font = fontIntro_para))
  
  
  dlg <- tktoplevel(width = 800); if(isIcon) tk2ico.set(dlg,icon)
  tkwm.title(dlg,"Targeted Analysis") 
  
  fr_input <- tkframe(dlg)
  tkgrid(tklabel(fr_input,text="",height = 0,font = fontIntro_para))
  if(!exists("textmzdatainput")){
    textmzdatainput <<- tclVar()
    textinputWidget <- tkentry(fr_input,width="70", textvariable = textmzdatainput, bg = "white")
    box.input <- tkbutton(fr_input, text = "...",  command = function(){
      tclvalue(textmzdatainput) <- tkchooseDirectory()
    })
    tkgrid(tklabel(fr_input, text = "   Input folder (mzXML file): "), textinputWidget, box.input, tklabel(fr_input, text = "    "), sticky = "w")
  }else{
    if(tclvalue(textmzdatainput)==""){
      textmzdatainput <<- tclVar()
      textinputWidget <- tkentry(fr_input,width="70", textvariable = textmzdatainput, bg = "white")
      box.input <- tkbutton(fr_input, text = "...",  command = function(){
        tclvalue(textmzdatainput) <- tkchooseDirectory()
      })
      tkgrid(tklabel(fr_input, text = "   Input folder (mzXML file): "), textinputWidget, box.input, tklabel(fr_input, text = "    "), sticky = "w")
    }else{
      tkgrid(tklabel(fr_input, text = paste("Input folder: ", tclvalue(textmzdatainput), "    ", sep = ""), padx = 11, wraplength = 720, justify = "left"), sticky = "w")
    }
  }
  
  if(!exists("textoutput")){
    textoutput <<- tclVar()
    textoutputWidget <- tkentry(fr_input,width="70", textvariable = textoutput, bg = "white")
    box.output <- tkbutton(fr_input, text = "...",  command = function(){
      tclvalue(textoutput) <- tkchooseDirectory()
    })
    tkgrid(tklabel(fr_input, text = "   Output folder: "), textoutputWidget, box.output, tklabel(fr_input, text = "    "), sticky = "w")
  }else{
    if(tclvalue(textoutput)==""){
      textoutput <<- tclVar()
      textoutputWidget <- tkentry(fr_input,width="70", textvariable = textoutput, bg = "white")
      box.output <- tkbutton(fr_input, text = "...",  command = function(){
        tclvalue(textoutput) <- tkchooseDirectory()
      })
      tkgrid(tklabel(fr_input, text = "   Output folder: "), textoutputWidget, box.output, tklabel(fr_input, text = "    "), sticky = "w")
    }else{
      if(tclvalue(textmzdatainput)==""){
        tkgrid(tklabel(fr_input, text = "   Output folder: "), tklabel(fr_input, text = tclvalue(textoutput)), tklabel(fr_input, text = "    "), tklabel(fr_input, text = "    "), sticky = "w")
      }else{
        tkgrid(tklabel(fr_input, text = paste("Output folder: ", tclvalue(textoutput), "    ", sep = ""), padx = 11, wraplength = 720, justify = "left"), sticky = "w")
      }
    }
  }
  
  tkgrid(tklabel(fr_input,text="", height = 0, font = fontIntro_para))
  tkpack(fr_input, side = "top", fill = "x")
  
  fr_para <- tkframe(dlg)
  tkpack(fr_para, side = "top", fill = "x")
  tkgrid(tklabel(fr_para, text = "   Parameter setting:"))
  
  fr_IP <- tkframe(dlg)
  tkpack(fr_IP, side = "top", fill = "x")
  
  
  
  fr_IP_head = tkframe(fr_IP)
  tkgrid(tklabel(fr_IP_head, text = "         Peak detection: "))
  tkgrid(fr_IP_head, sticky = "w")
  
  fr_IP_para <- tkframe(fr_IP)
  tkgrid(fr_IP_para, sticky = "w")
  
  
  
  
  labelprofstep <- tklabel(fr_IP_para, text = "                  prostep: ")
  tk2tip(labelprofstep, "XCMS: step size (in m/z) to use for profile generation")
  textprofstep <- tclVar(1)
  textprofstepWidget <- tkentry(fr_IP_para, width = 4, textvariable = textprofstep, bg = "white")
  
  
  labelmslevel <- tklabel(fr_IP_para, text = " , mslevel: ")
  tk2tip(labelmslevel, "XCMS: perform peak picking on data given mslevel (n:NULL)")
  textmslevel <- tclVar("")
  textmslevelWidget <- tkentry(fr_IP_para, width = 6, textvariable = textmslevel, bg = "white")
  
  labelscanrange <- tklabel(fr_IP_para, text = " , scanrange: ")
  tk2tip(labelscanrange, "XCMS: scan range to read (n:NULL)")
  textscanrange <- tclVar("n")
  textscanrangeWidget <- tkentry(fr_IP_para, width = 8, textvariable = textscanrange, bg = "white")
  
  labelnslave <- tklabel(fr_IP_para, text = " , nSlaves: ")
  tk2tip(labelnslave, "number of slaves/cores to be used for parallel peak detection.")
  textnslave <- tclVar(1)
  textnslaveWidget <- ttkcombobox(fr_IP_para, state = "readonly", values = 1:as.numeric(Sys.getenv('NUMBER_OF_PROCESSORS')), width = 4, textvariable = textnslave)
  
  
  tkgrid(labelprofstep, textprofstepWidget,  labelmslevel, textmslevelWidget, labelscanrange, textscanrangeWidget, labelnslave, textnslaveWidget,   tklabel(fr_IP_para, text = "    "), sticky = "w")
  
  fr_IP_prof <- tkframe(fr_IP)
  tkgrid(fr_IP_prof, sticky = "w")
  labelprof <- tklabel(fr_IP_prof, text = "                  profmethod: ")
  tk2tip(labelprof, "XCMS: method to use for profile generation")
  prof.val = tclVar(1)
  prof.bin <- tkradiobutton(fr_IP_prof, variable = prof.val, value = 1)
  labelprof.bin <- tklabel(fr_IP_prof, text = "bin")
  tk2tip(labelprof.bin, "XCMS: simply bins the intensity into the matrix \ncell closest to it in mass")
  prof.binlin <- tkradiobutton(fr_IP_prof, variable = prof.val, value = 2)
  labelprof.binlin <- tklabel(fr_IP_prof, text = "binlin")
  tk2tip(labelprof.binlin, "XCMS: does the same thing except that it uses\nlinear interpolation to fill in cells that \notherwise would have been left at zero")
  prof.binlinbase <- tkradiobutton(fr_IP_prof, variable = prof.val, value = 3)
  labelprof.binlinbase <- tklabel(fr_IP_prof, text = "binlinbase")
  tk2tip(labelprof.binlinbase, "XCMS: uses linear interpolation between data points")
  prof.intlin <- tkradiobutton(fr_IP_prof, variable = prof.val, value = 4)
  labelprof.intlin <- tklabel(fr_IP_prof, text = "intlin")
  tk2tip(labelprof.intlin, "XCMS: uses integration and linear interpolation \nbetween mass/intensity pairs to determine \nthe equally spaced intensity values")
  tkgrid(labelprof, prof.bin, labelprof.bin, prof.binlin, labelprof.binlin, prof.binlinbase, labelprof.binlinbase, prof.intlin, labelprof.intlin)
  
  fr_tar <- tkframe(dlg)
  tkpack(fr_tar, side = "top", fill = "x")
  
  
  fr_tar_head = tkframe(fr_tar)
  tkgrid(tklabel(fr_tar_head, text = "         Peak abundance calculation: "))
  tkgrid(fr_tar_head, sticky = "w")
  
  
  fr_ans <- tkframe(dlg)
  tkpack(fr_ans, side = "top", fill = "x")
  textansfile <- tclVar("")
  textinputWidget <- tkentry(fr_ans,width="50", textvariable = textansfile, bg = "white")
  box.input <- tkbutton(fr_ans, text = "...",  command = function() tclvalue(textansfile) <- tkgetOpenFile(initialfile = tclvalue(textansfile), filetypes = "{{Text Files} {.txt .csv}}"))
  tkgrid(tklabel(fr_ans, text = "", height = 0, font = fontIntro_para))
  tkgrid(tklabel(fr_ans, text="                  true m/z information file:   "),textinputWidget, box.input, tklabel(fr_ans,text="    "), sticky = "w")
  
  tkgrid(tklabel(fr_ans, text = "", height = 0, font = fontIntro_para))
  
  
  fr_tar_tol <- tkframe(fr_tar)
  tkgrid(fr_tar_tol, sticky = "w")
  
  fr_time_tol <- tkframe(fr_tar)
  tkgrid(fr_time_tol, sticky = "w")
  labeltime <- tklabel(fr_time_tol, text = "                  time tolerance: ")
  time.val = tclVar(1)
  
  prof.all <- tkradiobutton(fr_time_tol, variable = time.val, value = 1)
  
  texttolrt <- tclVar(5)
  texttolrtWidget <- tkentry(fr_time_tol, width = 4, textvariable = texttolrt, bg = "white")
  labeltolrt <- tklabel(fr_time_tol, text = " sec ")
  
  prof.custom <- tkradiobutton(fr_time_tol, variable = time.val, value = 2,command=function(){	tkconfigure(texttolrtWidget, state = "disable")})
  labeltime.custom <- tklabel(fr_time_tol, text = "user provided")
  
  prof.auto <- tkradiobutton(fr_time_tol, variable = time.val, value = 3,command=function(){	tkconfigure(texttolrtWidget, state = "disable")})
  labeltime.auto <- tklabel(fr_time_tol, text = "auto detect")
  
  
  tkgrid(labeltime,prof.all,texttolrtWidget,labeltolrt, prof.custom, labeltime.custom, prof.auto, labeltime.auto, sticky = "w")
  
  fr_mz_tol <- tkframe(fr_tar)
  tkgrid(fr_mz_tol, sticky = "w")
  labeltolmz <- tklabel(fr_mz_tol, text = "                  m/z tolerance: ")
  tk2tip(labeltolmz, "m/z tolerance in ppm (parts per million)")
  texttolmz <- tclVar(1000)
  texttolmzWidget <- tkentry(fr_mz_tol, width = 4, textvariable = texttolmz, bg = "white")
  
  tkgrid(labeltolmz, texttolmzWidget,   tklabel(fr_mz_tol, text = " ppm    "), sticky = "w")
  
  
  
  
  
  #========
  fr_add_data <- tkframe(dlg)
  tkpack(fr_add_data, side = "top", fill = "x")
  tk2tip(labelprof, "Additional MSn data?")
  add_data = tclVar(2)
  
  add_data_yes<- tkradiobutton( fr_add_data, variable = add_data, value = 1, command = function(...){
    tkconfigure(OK.but, text = "  Continue  ")
  })
  labeladd.yes <- tklabel(fr_add_data, text = "Yes")
  tk2tip(labeladd.yes, "Yes")
  
  add_data_no <- tkradiobutton(fr_add_data, variable = add_data, value = 2, command = function(...){
    tkconfigure(OK.but, text = "  OK  ")
  })
  labeladd.no <- tklabel(fr_add_data, text = "No")
  tk2tip(labeladd.no, "No")
  tkgrid(tklabel(fr_add_data, text = "   Additional MSn data:"), add_data_yes,labeladd.yes, add_data_no, labeladd.no)
  
  Import_MSn <- function(){
    #check MS1
    if(tclvalue(textmslevel)==""){
      tkmessageBox(title = "Error", message = "Please input the mslevel.", icon = "error", type = "ok")
      cat("Please input the mslevel.")
      stop("Please input the mslevel.")
    }else{
      if(tclvalue(textansfile)==""){
        tkmessageBox(title = "Error", message = "Please input the true m/z information file.", icon = "error", type = "ok")
        cat("Please input the true m/z information file.")
        stop("Please input the true m/z information file.")
      }else{
        target_table <- read.table(tclvalue(textansfile), sep = ",", header = T, quote = "\"", as.is = T, fill = T,stringsAsFactors = F)
        colnames(target_table)[colnames(target_table)%in%"daughter_ion"] <- "mz"
        if(!all(c("Name","mz")%in%colnames(target_table))){
          tkmessageBox(title = "Error", message = "Name, m/z, or daughter ion (m/z) is required.", icon = "error", type = "ok")
          cat("Name, m/z, or daughter ion (m/z) is required.")
          stop("Name, m/z, or daughter ion (m/z) is required.")
        }else{
          colnames(target_table)[colnames(target_table)%in%"daughter_ion"] <- "mz"
          target_mz <- NULL
          target_mz <- sapply(1:nrow(target_table), function(x)as.numeric(unlist(strsplit(as.character(target_table$mz[x]), ";"))))
          if(sum(is.na(target_mz))!=0){
            tkmessageBox(title = "Error", message = "m/z should be numeric or should not be empty.", icon = "error", type = "ok")
            cat("m/z should be numeric or should not be empty.")
            stop("m/z should be numeric or should not be empty.")
          }
        }
      }
    }
    
    
    
    if(as.numeric(tclvalue(time.val))==2){
      if(!"tol_time.sec"%in%colnames(target_table)){
        tkmessageBox(title = "Error", message = "Please provide time tolerance information in the true m/z information file.", icon = "error", type = "ok")
        cat("Please provide time tolerance information in the true m/z information file.")
        stop("Please provide time tolerance information in the true m/z information file.")
      }
      
    }
    
    tkdestroy(dlg)
    import_add <- tktoplevel(); if(isIcon) tk2ico.set(import_add,icon)
    tktitle(import_add) = "Data Import - Additoinal MSn data"
    fr_input_add <- tkframe(import_add)
    tkpack(fr_input_add,side="top", fill="x")
    textadddatafile <- tclVar("") 
    textinputWidget <- tkentry(fr_input_add ,width="50", textvariable = textadddatafile, bg = "white")
    box.input <- tkbutton(fr_input_add, text = "...",  command = function(){
      tclvalue(textadddatafile) <- tkchooseDirectory(initialdir = tclvalue(textadddatafile))
    })
    tkgrid(tklabel(fr_input_add, text = "", height = 0, font = fontIntro_para))
    tkgrid(tklabel(fr_input_add, text="   Input folder for Additional MSn (mzXML file):   "),textinputWidget, box.input, tklabel(fr_input_add,text="    "), sticky = "w")
    
    tkgrid(tklabel(fr_input_add, text = "", height = 0, font = fontIntro_para), sticky = "w")
    
    
    
    # 
    fr_para_add <- tkframe(import_add)
    tkpack(fr_para_add, side = "top", fill = "x")
    tkgrid(tklabel(fr_para_add, text = "   Parameter setting:"))
    
    fr_IP_add <- tkframe(import_add)
    tkpack(fr_IP_add, side = "top", fill = "x")
    
    
    
    fr_IP_head_add = tkframe(fr_IP_add)
    tkgrid(tklabel(fr_IP_head_add, text = "         Peak detection: "))
    tkgrid(fr_IP_head_add, sticky = "w")
    
    fr_IP_para_add <- tkframe(fr_IP_add)
    tkgrid(fr_IP_para_add, sticky = "w")
    
    
    
    
    labelprofstep_add <- tklabel(fr_IP_para_add, text = "                  prostep: ")
    tk2tip(labelprofstep_add, "XCMS: step size (in m/z) to use for profile generation")
    textprofstep_add <- tclVar(1)
    textprofstepWidget_add <- tkentry(fr_IP_para_add, width = 4, textvariable = textprofstep_add, bg = "white")
    
    
    labelmslevel_add <- tklabel(fr_IP_para_add, text = " , mslevel: ")
    tk2tip(labelmslevel_add, "XCMS: perform peak picking on data given mslevel (n:NULL)")
    textmslevel_add <- tclVar("")
    textmslevelWidget_add <- tkentry(fr_IP_para_add, width = 6, textvariable = textmslevel_add, bg = "white")
    
    labelscanrange_add <- tklabel(fr_IP_para_add, text = " , scanrange: ")
    tk2tip(labelscanrange_add, "XCMS: scan range to read (n:NULL)")
    textscanrange_add <- tclVar("n")
    textscanrangeWidget_add <- tkentry(fr_IP_para_add, width = 8, textvariable = textscanrange_add, bg = "white")
    
    
    tkgrid(labelprofstep_add, textprofstepWidget_add,  labelmslevel_add, textmslevelWidget_add, labelscanrange_add, textscanrangeWidget_add,tklabel(fr_IP_para_add, text = "    "), sticky = "w")
    
    fr_IP_prof_add <- tkframe(fr_IP_add)
    tkgrid(fr_IP_prof_add, sticky = "w")
    labelprof_add <- tklabel(fr_IP_prof_add, text = "                  profmethod: ")
    tk2tip(labelprof_add, "XCMS: method to use for profile generation")
    prof.val_add = tclVar(1)
    prof.bin_add <- tkradiobutton(fr_IP_prof_add, variable = prof.val_add, value = 1)
    labelprof.bin_add <- tklabel(fr_IP_prof_add, text = "bin")
    tk2tip(labelprof.bin_add, "XCMS: simply bins the intensity into the matrix \ncell closest to it in mass")
    prof.binlin_add <- tkradiobutton(fr_IP_prof_add, variable = prof.val_add, value = 2)
    labelprof.binlin_add <- tklabel(fr_IP_prof_add, text = "binlin")
    tk2tip(labelprof.binlin_add, "XCMS: does the same thing except that it uses\nlinear interpolation to fill in cells that \notherwise would have been left at zero")
    prof.binlinbase_add <- tkradiobutton(fr_IP_prof_add, variable = prof.val_add, value = 3)
    labelprof.binlinbase_add <- tklabel(fr_IP_prof_add, text = "binlinbase")
    tk2tip(labelprof.binlinbase_add, "XCMS: uses linear interpolation between data points")
    prof.intlin_add <- tkradiobutton(fr_IP_prof_add, variable = prof.val_add, value = 4)
    labelprof.intlin_add <- tklabel(fr_IP_prof_add, text = "intlin")
    tk2tip(labelprof.intlin_add, "XCMS: uses integration and linear interpolation \nbetween mass/intensity pairs to determine \nthe equally spaced intensity values")
    tkgrid(labelprof_add, prof.bin_add, labelprof.bin_add, prof.binlin_add, labelprof.binlin_add, prof.binlinbase_add, labelprof.binlinbase_add, prof.intlin_add, labelprof.intlin_add)
    
    fr_tar_add <- tkframe(import_add)
    tkpack(fr_tar_add, side = "top", fill = "x")
    
    
    fr_tar_head_add = tkframe(fr_tar_add)
    tkgrid(tklabel(fr_tar_head_add, text = "         Peak abundance calculation: "))
    tkgrid(fr_tar_head_add, sticky = "w")
    
    
    fr_ans_add <- tkframe(import_add)
    tkpack(fr_ans_add, side = "top", fill = "x")
    textansfile_add <- tclVar("")
    textinputWidget_add <- tkentry(fr_ans_add,width="50", textvariable = textansfile_add, bg = "white")
    box.input_add <- tkbutton(fr_ans_add, text = "...",  command = function() tclvalue(textansfile_add) <- tkgetOpenFile(initialfile = tclvalue(textansfile_add), filetypes = "{{Text Files} {.txt .csv}}"))
    tkgrid(tklabel(fr_ans_add, text = "", height = 0, font = fontIntro_para))
    tkgrid(tklabel(fr_ans_add, text="                  true m/z information file:   "),textinputWidget_add, box.input_add, tklabel(fr_ans_add,text="    "), sticky = "w")
    
    tkgrid(tklabel(fr_ans_add, text = "", height = 0, font = fontIntro_para))
    
    
    fr_time_tol_add <- tkframe(fr_tar_add)
    tkgrid(fr_time_tol_add, sticky = "w")
    labeltime_add <- tklabel(fr_time_tol_add, text = "                  time tolerance: ")
    time.val_add = tclVar(1)
    
    prof.all_add <- tkradiobutton(fr_time_tol_add, variable = time.val_add, value = 1)
    
    texttolrt_add <- tclVar(5)
    texttolrtWidget_add <- tkentry(fr_time_tol_add, width = 4, textvariable = texttolrt_add, bg = "white")
    labeltolrt_add <- tklabel(fr_time_tol_add, text = " sec ")
    
    prof.custom_add <- tkradiobutton(fr_time_tol_add, variable = time.val_add, value = 2,command=function(){	tkconfigure(texttolrtWidget_add, state = "disable")})
    labeltime.custom_add <- tklabel(fr_time_tol_add, text = "user provided")
    
    prof.auto_add <- tkradiobutton(fr_time_tol_add, variable = time.val_add, value = 3,command=function(){	tkconfigure(texttolrtWidget_add, state = "disable")})
    labeltime.auto_add <- tklabel(fr_time_tol_add, text = "auto detect")
    
    
    tkgrid(labeltime_add,prof.all_add,texttolrtWidget_add,labeltolrt_add, prof.custom_add, labeltime.custom_add, prof.auto_add, labeltime.auto_add, sticky = "w")
    
    fr_mz_tol_add <- tkframe(fr_tar_add)
    tkgrid(fr_mz_tol_add, sticky = "w")
    labeltolmz_add <- tklabel(fr_mz_tol_add, text = "                  m/z tolerance: ")
    tk2tip(labeltolmz_add, "m/z tolerance in ppm (parts per million)")
    texttolmz_add <- tclVar(1000)
    texttolmzWidget_add <- tkentry(fr_mz_tol_add, width = 4, textvariable = texttolmz_add, bg = "white")
    
    tkgrid(labeltolmz_add, texttolmzWidget_add,   tklabel(fr_mz_tol_add, text = " ppm    "), sticky = "w")
    
    
    
    contiframe = tkframe(import_add)
    tkpack(contiframe)
    onOK <- function(){
      

      #check MSn
      if(tclvalue(textadddatafile)==""){
        tkmessageBox(title = "Error", message = "Please provide the input folder for additional MSn data.", icon = "error", type = "ok")
        cat("Please provide the input folder for additional MSn data.")
        stop("Please provide the input folder for additional MSn data.")
      }
      
      params_add <- list()
      if(tclvalue(textmslevel_add)==""){
        tkmessageBox(title = "Error", message = "Please input the mslevel.", icon = "error", type = "ok")
        cat("Please input the mslevel.")
        stop("Please input the mslevel.")
      }else{
        if(tclvalue(textansfile_add)==""){
          tkmessageBox(title = "Error", message = "Please input the true m/z information file.", icon = "error", type = "ok")
          cat("Please input the true m/z information file.")
          stop("Please input the true m/z information file.")
        }else{
          target_table_add <- read.table(tclvalue(textansfile_add), sep = ",", header = T, quote = "\"", as.is = T, fill = T,stringsAsFactors = F)
          colnames(target_table_add)[colnames(target_table_add)%in%"daughter_ion"] <- "mz"
          if(!all(c("Name","mz")%in%colnames(target_table_add))){
            tkmessageBox(title = "Error", message = "Name, m/z, or daughter ion (m/z) is required.", icon = "error", type = "ok")
            cat("Name, m/z, or daughter ion (m/z) is required.")
            stop("Name, m/z, or daughter ion (m/z) is required.")
          }else{
            colnames(target_table_add)[colnames(target_table_add)%in%"daughter_ion"] <- "mz"
            target_mz_add <- NULL
            target_mz_add <- sapply(1:nrow(target_table_add), function(x)as.numeric(unlist(strsplit(as.character(target_table_add$mz[x]), ";"))))
            if(sum(is.na(target_mz_add))!=0){
              tkmessageBox(title = "Error", message = "m/z should be numeric or should not be empty.", icon = "error", type = "ok")
              cat("m/z should be numeric or should not be empty.")
              stop("m/z should be numeric or should not be empty.")
            }
          }
        }
      }
      
      
      
      if(as.numeric(tclvalue(time.val_add))==2){
        if(!"tol_time.sec"%in%colnames(target_table_add)){
          tkmessageBox(title = "Error", message = "Please provide time tolerance information in the true m/z information file.", icon = "error", type = "ok")
          cat("Please provide time tolerance information in the true m/z information file.")
          stop("Please provide time tolerance information in the true m/z information file.")
        }
        
      }
      tkdestroy(import_add)
      outpath = paste(tclvalue(textoutput), "/Peak Analysis (Targeted)", sep = "")
      dir.create(outpath, showWarnings = F)
      tkdestroy(dlg)
      
      xcmsFiles = dir(tclvalue(textmzdatainput), full.names = T, pattern = ".mzXML")
      xcmsFilename = dir(tclvalue(textmzdatainput),full.names = F, pattern = ".mzXML")
      xcmsFilename = gsub(".mzXML","",xcmsFilename)
      
      #========
      
      xcmsFiles_add = dir(tclvalue(textadddatafile), full.names = T, pattern = ".mzXML")
      xcmsFilename_add = dir(tclvalue(textadddatafile),full.names = F, pattern = ".mzXML")
      xcmsFilename_add = gsub(".mzXML","",xcmsFilename_add)
      #=====
      file1 <- sapply(1:length(xcmsFilename), function(x)strsplit(xcmsFilename[x],"_")[[1]][1])
      file2 <- sapply(1:length(xcmsFilename_add), function(x)strsplit(xcmsFilename_add[x],"_")[[1]][1])
      
      if(length(intersect(file1,file2))==0){
        tkmessageBox(title = "Error", message = "Please name the file according to the rules.", icon = "error", type = "ok")
        cat("Please name the file according to the rules.")
        stop("Please name the file according to the rules.")
      }
      
      xcmsFiles <- sort(xcmsFiles[file1%in%intersect(file1,file2)])
      xcmsFilename <- sort(xcmsFilename[file1%in%intersect(file1,file2)])
      
      xcmsFiles_add <- sort(xcmsFiles_add[file2%in%intersect(file1,file2)])
      xcmsFilename_add <- sort(xcmsFilename_add[file2%in%intersect(file1,file2)])
      
      
      
      #tolerance for time & m/z

      target_mz <- as.list(target_mz)
      names(target_mz) <- target_table$Name
      
      if(!("Ret_Time.sec" %in% colnames(target_table))){
        target_table$Ret_Time.sec <- NA
      }
      if(!("parent_ion" %in% colnames(target_table))){
        target_table$parent_ion <- NA
      }
      

      
      #tolerance m/z
      
      tol_mz <- as.numeric(tclvalue(texttolmz))*1e-6
      
      #tolerance for time
      target_table$Ret_Time.sec <- as.numeric(target_table$Ret_Time.sec)
      
      if(as.numeric(tclvalue(time.val))==2){
        target_table[,"tol_time.sec"] <- as.numeric(target_table[,"tol_time.sec"])
        target_table[,"time_l"] <- target_table[,"Ret_Time.sec"]-target_table[,"tol_time.sec"]
        target_table[,"time_u"] <- target_table[,"Ret_Time.sec"]+target_table[,"tol_time.sec"]
      }else{
        tol_time <- as.numeric(tclvalue(texttolrt))
        target_table[,"time_l"] <- target_table[,"Ret_Time.sec"]-tol_time
        target_table[,"time_u"] <- target_table[,"Ret_Time.sec"]+tol_time 
      }
      
      
      ## parameters setting
      params <- list()
      params$profmethod  <- switch(as.numeric(tclvalue(prof.val)), "bin", "binlin", "binlinbase", "intlin")
      params$prostep <- as.numeric(tclvalue(textprofstep))
      params$mslevel <- switch(tclvalue(textmslevel), "n" = NULL, as.numeric(tclvalue(textmslevel)))
      params$scanrange <- switch(tclvalue(textscanrange), "n" = NULL, as.numeric(tclvalue(textscanrange)))
      params$includeMSn <- FALSE
      params$includeMSn <- !is.null(params$mslevel) && params$mslevel > 1
      
      ## 
      #========
      
      pb <<- tkProgressBar("Peak Analysis (Targeted) - Please wait for processing", "0% done", 0, 100, 0, width = 500)
      cat("Peak Analysis (Targeted) - Please wait for processing 0 ")
      
      
      
      ncpu <- as.numeric(tclvalue(textnslave))
      
      if (ncpu==1|is.na(ncpu)==T){
        out <- sapply(1:length(xcmsFiles), function(x) {

          info <- sprintf("%d%%", round(100*x/length(xcmsFiles)/2))
          setTkProgressBar(pb, value = round(100*x/length(xcmsFiles)/2), sprintf("Peak Analysis (Targeted) - Please wait for processing (%s done)", info), paste(xcmsFilename[x], info, sep = " "))
          if(round(100*x/length(xcmsFiles)/2)<100){
            cat(round(100*x/length(xcmsFiles)/2), " ", sep = "")
          }else{
            cat(round(100*x/length(xcmsFiles)/2), " \n", sep = "")
          }
          targeted_analysis(datafilename = xcmsFiles[x], params = params ,target = target_table, mz_list = target_mz, outpath = outpath, tol_mz = tol_mz)
        })
      }else{
        cl <- makeCluster(ncpu, methods = FALSE)
        clusterExport(cl, c("xcmsFiles","params","target_table","target_mz","outpath","tol_mz","targeted_analysis"), envir=environment())
        clusterEvalQ(cl, {
          library(xcms) 
          library(dplyr)
          library(png)
        })
        out <- parSapply(cl, X= 1:length(xcmsFiles), function(x){
          targeted_analysis(datafilename = xcmsFiles[x], params = params ,target = target_table, mz_list = target_mz, outpath = outpath, tol_mz = tol_mz)
          
        } )
        stopCluster(cl)
      }
      

      
      
      colnames(out) <- xcmsFilename
      l <- c(sapply(1:length(target_mz),function(x)length(target_mz[[x]])))
      
      
      idx <- c()
      for(i in 1:nrow(target_table)){
        tmp <- 1:l[i]
        if(i!=1){
          tmp <- tmp + 4*sum(l[1:(i-1)])
        }
        idx <- c(idx,tmp)
      }
      target_table <- target_table[,colnames(target_table)!="tol_time.sec"]
      target_out <- data.frame(Peak_Index=1:sum(l),target_table[rep(1:nrow(target_table),l),1:4])
      target_out$mz <- unlist(target_mz)
      if(all(is.na(target_out$parent_ion))){
        target_out <- target_out[,colnames(target_out)!="parent_ion"]
      }
      
      est_mz <- out[idx,]
      peak_ab <- out[idx+rep(l,l),]　
      rt <- out[idx+rep(l*2,l),]
      sn <- out[idx+rep(l*3,l),]
      
      target_out$Ret_Time_est.sec <- if(is.null(ncol(rt))){rt}else{rowMeans(rt,na.rm = T)}
      target_out$mz_est <- if(is.null(ncol(rt))){est_mz}else{rowMeans(est_mz,na.rm = T)}
      
      
      rt_est_for_MSn <- cbind(target_out,rt)
      colnames(rt_est_for_MSn) <- c(colnames(target_out),xcmsFilename)
      write.csv(rt_est_for_MSn ,paste0(outpath,"/S",length(xcmsFiles),"_retention_time_MS",params$mslevel,".csv"),row.names = F)
      

      out_sn <- cbind(target_out,sn)
      colnames(out_sn) <- c(colnames(target_out),xcmsFilename)
      write.csv(out_sn,paste0(outpath,"/S",length(xcmsFiles),"_sn_MS",params$mslevel,".csv"),row.names = F)
      
      out_mz <- cbind(target_out,est_mz)
      colnames(out_mz) <- c(colnames(target_out),xcmsFilename)
      write.csv(out_mz,paste0(outpath,"/S",length(xcmsFiles),"_mz_MS",params$mslevel,".csv"),row.names = F)
      
      out_peak <- cbind(target_out,peak_ab)
      colnames(out_peak) <- c(colnames(target_out),xcmsFilename)
      write.csv(out_peak,paste0(outpath,"/S",length(xcmsFiles),"_peak_abundance_MS",params$mslevel,".csv"),row.names = F)
      
      out_SMART <- cbind(target_out[,c("Peak_Index","Name","mz_est","Ret_Time_est.sec")],peak_ab)
      colnames(out_SMART) <- c("Peak_Index","Name","mz_est","Ret_Time_est.sec",xcmsFilename)
      write.csv(out_SMART,paste0(outpath,"/S",length(xcmsFiles),"_peak_abundance_MS",params$mslevel,"_forSMART.csv"),row.names = F)
      
      if(!is.null(ncol(peak_ab))){
        tmp <- unique(target_out$Name)
        for(v in 1:length(tmp)){
          
          sub_peak <- peak_ab[which(target_out$Name==tmp[v]),,drop=F]
          peak_ab[which(target_out$Name==tmp[v]),] <- t(t(sub_peak)/colMaxs(sub_peak,na.rm=T))*100
        }
      }else{
        tmp <- unique(target_out$Name)
        for(v in 1:length(tmp)){
          
          sub_peak <- peak_ab[which(target_out$Name==tmp[v])]
          peak_ab[which(target_out$Name==tmp[v])] <- t(t(sub_peak)/max(sub_peak,na.rm=T))*100
        }
      }
      
      if(!all(peak_ab==100,na.rm = T)){
        write.csv(cbind(target_out,peak_ab),paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_relative_abundance_MS",params$mslevel,".csv"),row.names = F)
      }
      
      ## MSn data ====
      
      
      ## parameters setting
      params_add$profmethod  <- switch(as.numeric(tclvalue(prof.val_add)), "bin", "binlin", "binlinbase", "intlin")
      params_add$prostep <- as.numeric(tclvalue(textprofstep_add))
      params_add$mslevel <- switch(tclvalue(textmslevel_add), "n" = NULL, as.numeric(tclvalue(textmslevel_add)))
      params_add$scanrange <- switch(tclvalue(textscanrange_add), "n" = NULL, as.numeric(tclvalue(textscanrange_add)))
      params_add$includeMSn <- FALSE
      params_add$includeMSn <- !is.null(params_add$mslevel) && params_add$mslevel > 1
      
      
      target_mz_add <- as.list(target_mz_add)
      names(target_mz_add) <- target_table_add$Name
      
      if(!("Ret_Time.sec" %in% colnames(target_table_add))){
        target_table_add$Ret_Time.sec <- NA
      }
      
      rt_est_for_MSn <- rt_est_for_MSn[match(rt_est_for_MSn$Name,target_out$Name),]
      
      
      if(!("parent_ion" %in% colnames(target_table_add))){
        target_table_add$parent_ion <- NA
      }
      
      #tolerance for m/z
      
      tol_mz_add <- as.numeric(tclvalue(texttolmz_add))*1e-6
      
      #tolerance for time
      target_add_table_ls <- list()
      
      for(z in 1:length(xcmsFilename)){
        tmp <- target_table_add
        tmp$Ret_Time.sec <- rt_est_for_MSn[,xcmsFilename[z]]
        tmp$Ret_Time.sec <- as.numeric(tmp$Ret_Time.sec)
        if(as.numeric(tclvalue(time.val_add))==2){
          target_table_add[,"tol_time.sec"] <- as.numeric(target_table_add[,"tol_time.sec"])
          tmp[,"time_l"] <- tmp[,"Ret_Time.sec"]-target_table_add[,"tol_time.sec"]
          tmp[,"time_u"] <- tmp[,"Ret_Time.sec"]+target_table_add[,"tol_time.sec"]
        }else{
          tol_time_add <- as.numeric(tclvalue(texttolrt_add))
          tmp[,"time_l"] <- tmp[,"Ret_Time.sec"]-tol_time_add
          tmp[,"time_u"] <- tmp[,"Ret_Time.sec"]+tol_time_add 
          
        }
        
        target_add_table_ls[[z]] <- tmp
      }
        
      # target_table_add$Ret_Time.sec <- as.numeric(target_table_add$Ret_Time.sec)
      # target_table_add[,"time_l"] <- target_table_add[,"Ret_Time.sec"]-tol_time_add
      # target_table_add[,"time_u"] <- target_table_add[,"Ret_Time.sec"]+tol_time_add 
      
      
      #=====
      # type <- as.numeric(tclvalue(add_data))
      # ncpu <- as.numeric(tclvalue(textnslave))
      
      if (ncpu==1|is.na(ncpu)==T){
        
        out <- sapply(1:length(xcmsFiles_add), function(x) {

          info <- sprintf("%d%%", round(50+100*x/length(xcmsFiles_add)/2))
          setTkProgressBar(pb, value = round(50+100*x/length(xcmsFiles_add)/2), sprintf("Peak Analysis (Targeted) - Please wait for processing (%s done)", info), paste(xcmsFilename_add[x], info, sep = " "))
          if(round(50+100*x/length(xcmsFiles_add)/2)<100){
            cat(round(50+100*x/length(xcmsFiles_add)/2), " ", sep = "")
          }else{
            cat(round(50+100*x/length(xcmsFiles_add)/2), " \n", sep = "")
          }
          targeted_analysis(datafilename = xcmsFiles_add[x], params = params_add ,target = target_add_table_ls[[x]], mz_list = target_mz_add, outpath = outpath, tol_mz = tol_mz_add)
        })
        

      }else{
        cl <- makeCluster(ncpu, methods = FALSE)
        clusterExport(cl, c("xcmsFiles_add","params_add","target_add_table_ls","target_mz_add","outpath","tol_mz_add"), envir=environment())
        clusterEvalQ(cl, {
          library(xcms) 
          library(dplyr)
          library(png)
        })
        out <- parSapply(cl, X= 1:length(xcmsFiles_add), function(x) targeted_analysis(datafilename = xcmsFiles_add[x], params = params_add ,target = target_add_table_ls[[x]], mz_list = target_mz_add, outpath = outpath, tol_mz = tol_mz_add))
        stopCluster(cl)
      }
      
      colnames(out) <- xcmsFilename_add
      l <- c(sapply(1:length(target_mz_add),function(x)length(target_mz_add[[x]])))
      
      setTkProgressBar(pb, value = 100, "Peak Analysis (Targeted) - Please wait for processing (100% done)", "Finished 100%")
      Sys.sleep(1)
      close(pb)
      
      
      idx <- c()
      for(i in 1:nrow(target_table_add)){
        tmp <- 1:l[i]
        if(i!=1){
          tmp <- tmp + 4*sum(l[1:(i-1)])
        }
        idx <- c(idx,tmp)
      }
      target_table_add <- target_table_add[,colnames(target_table_add)!="tol_time.sec"]
      target_out_add <- data.frame(Peak_Index=1:sum(l),target_table_add[rep(1:nrow(target_table_add),l),1:4])
      target_out_add$mz <- unlist(target_mz_add)
      if(all(is.na(target_out_add$parent_ion))){
        target_out_add <- target_out_add[,colnames(target_out_add)!="parent_ion"]
      }
      
      est_mz <- out[idx,]
      peak_ab <- out[idx+rep(l,l),]　
      rt <- out[idx+rep(l*2,l),]
      sn <- out[idx+rep(l*3,l),]
      
      target_out_add$Ret_Time_est.sec <- if(is.null(ncol(rt))){rt}else{rowMeans(rt,na.rm = T)}
      target_out_add$mz_est <- if(is.null(ncol(rt))){est_mz}else{rowMeans(est_mz,na.rm = T)}
      
      
      out_rt <- cbind(target_out_add,rt)
      colnames(out_rt) <- c(colnames(target_out_add),xcmsFilename_add)
      write.csv(out_rt,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_retention_time_MS",params_add$mslevel,".csv"),row.names = F)
      
      out_sn <- cbind(target_out_add,sn)
      colnames(out_sn) <- c(colnames(target_out_add),xcmsFilename_add)
      
      write.csv(out_sn,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_sn_MS",params_add$mslevel,".csv"),row.names = F)
      
      out_mz <- cbind(target_out_add,est_mz)
      colnames(out_mz) <- c(colnames(target_out_add),xcmsFilename_add)
      write.csv(out_mz,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_mz_MS",params_add$mslevel,".csv"),row.names = F)
      
      out_peak <- cbind(target_out_add,peak_ab)
      colnames(out_peak) <- c(colnames(target_out_add),xcmsFilename_add)
      write.csv(out_peak,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_peak_abundance_MS",params_add$mslevel,".csv"),row.names = F)
      
      out_SMART <- cbind(target_out_add[,c("Peak_Index","Name","mz_est","Ret_Time_est.sec")],peak_ab)
      colnames(out_SMART) <- c("Peak_Index","Name","mz_est","Ret_Time_est.sec",xcmsFilename_add)
      write.csv(out_SMART,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_peak_abundance_MS",params_add$mslevel,"_forSMART.csv"),row.names = F)
      
      if(!is.null(ncol(peak_ab))){
        tmp <- unique(target_out_add$Name)
        for(v in 1:length(tmp)){
          
          sub_peak <- peak_ab[which(target_out_add$Name==tmp[v]),,drop=F]
          peak_ab[which(target_out_add$Name==tmp[v]),] <- t(t(sub_peak)/colMaxs(sub_peak,na.rm=T))*100
        }
      }else{
        tmp <- unique(target_out_add$Name)
        for(v in 1:length(tmp)){
          
          sub_peak <- peak_ab[which(target_out_add$Name==tmp[v])]
          peak_ab[which(target_out_add$Name==tmp[v])] <- t(t(sub_peak)/max(sub_peak,na.rm=T))*100
        }
      }
      
      if(!all(peak_ab==100,na.rm = T)){
        write.csv(cbind(target_out_add,peak_ab),paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_relative_abundance_MS",params_add$mslevel,".csv"),row.names = F)
      }
      
      
      textAbuninput <<- tclVar(paste0("Peak Analysis (Targeted)/S",length(xcmsFiles_add),"_peak_abundance_MS",params_add$mslevel,"_forSMART.csv"))
      
      text_zero <<- tclVar("0")
      text_missing <<- tclVar("NA")
      
      
      tkmessageBox(title = "Peak Analysis", message = "Peak Analysis (Targeted) is done.", icon = "info", type = "ok")
      cat("Peak Analysis (Targeted) is done.\n")
      
      tkentryconfigure(peakMenu, 1, state = "active")
      tkentryconfigure(QCsubMenu, 0, state = "active")
      
      tkentryconfigure(batchsubMenu, 0, state = "active")
      tkentryconfigure(batchsubMenu, 1, state = "active")
      tkentryconfigure(statMenu, 1, state = "active")
      tkentryconfigure(statMenu, 2, state = "active")
      
      
      
    }
    conti.button <- tkbutton(contiframe, text = "   OK   ",command = onOK)
    tkgrid(conti.button)
    tkgrid(tklabel(contiframe, text = "", height = 0, font = fontIntro_para))
    
  }
  
  
  #========
  
  onOK <- function(){
    
    if(tclvalue(textmslevel)==""){
      tkmessageBox(title = "Error", message = "Please input the mslevel.", icon = "error", type = "ok")
      cat("Please input the mslevel.")
      stop("Please input the mslevel.")
    }else{
      if(tclvalue(textansfile)==""){
        tkmessageBox(title = "Error", message = "Please input the true m/z information file.", icon = "error", type = "ok")
        cat("Please input the true m/z information file.")
        stop("Please input the true m/z information file.")
      }else{
        target_table <- read.table(tclvalue(textansfile), sep = ",", header = T, quote = "\"", as.is = T, fill = T,stringsAsFactors = F)
        colnames(target_table)[colnames(target_table)%in%"daughter_ion"] <- "mz"
        if(!all(c("Name","mz")%in%colnames(target_table))){
          tkmessageBox(title = "Error", message = "Name, m/z, or daughter ion (m/z) is required.", icon = "error", type = "ok")
          cat("Name, m/z, or daughter ion (m/z) is required.")
          stop("Name, m/z, or daughter ion (m/z) is required.")
        }else{
          colnames(target_table)[colnames(target_table)%in%"daughter_ion"] <- "mz"
          target_mz <- NULL
          target_mz <- sapply(1:nrow(target_table), function(x)as.numeric(unlist(strsplit(as.character(target_table$mz[x]), ";"))))
          if(sum(is.na(target_mz))!=0){
            tkmessageBox(title = "Error", message = "m/z should be numeric or should not be empty.", icon = "error", type = "ok")
            cat("m/z should be numeric or should not be empty.")
            stop("m/z should be numeric or should not be empty.")
          }
        }
      }
    }
    

    
    
    target_mz <- as.list(target_mz)
    names(target_mz) <- target_table$Name
    
    if(!("Ret_Time.sec" %in% colnames(target_table))){
      target_table$Ret_Time.sec <- NA
    }
    if(!("parent_ion" %in% colnames(target_table))){
      target_table$parent_ion <- NA
    }
    
    #tolerance for time & m/z
    tol_time <- as.numeric(tclvalue(texttolrt))
    tol_mz <- as.numeric(tclvalue(texttolmz))*1e-6
    
    target_table$Ret_Time.sec <- as.numeric(target_table$Ret_Time.sec)
    
    if("tol_time.sec"%in%colnames(target_table)){
      target_table[,"tol_time.sec"] <- as.numeric(target_table[,"tol_time.sec"])
      target_table[is.na(target_table[,"tol_time.sec"]),"tol_time.sec"] <- tol_time
      target_table[,"time_l"] <- target_table[,"Ret_Time.sec"]-target_table[,"tol_time.sec"]
      target_table[,"time_u"] <- target_table[,"Ret_Time.sec"]+target_table[,"tol_time.sec"]
    }else{
      target_table[,"time_l"] <- target_table[,"Ret_Time.sec"]-tol_time
      target_table[,"time_u"] <- target_table[,"Ret_Time.sec"]+tol_time 
    }
    
    
    
    
    params <- list()
    params$profmethod  <- switch(as.numeric(tclvalue(prof.val)), "bin", "binlin", "binlinbase", "intlin")
    params$prostep <- as.numeric(tclvalue(textprofstep))
    params$mslevel <- switch(tclvalue(textmslevel), "n" = NULL, as.numeric(tclvalue(textmslevel)))
    params$scanrange <- switch(tclvalue(textscanrange), "n" = NULL, as.numeric(tclvalue(textscanrange)))
    params$includeMSn <- FALSE
    params$includeMSn <- !is.null(params$mslevel) && params$mslevel > 1
    
    
    
    #========
    outpath = paste(tclvalue(textoutput), "/Peak Analysis (Targeted)", sep = "")
    dir.create(outpath, showWarnings = F)
    tkdestroy(dlg)
    
    xcmsFiles = dir(tclvalue(textmzdatainput), full.names = T, pattern = ".mzXML")
    xcmsFilename = dir(tclvalue(textmzdatainput),full.names = F, pattern = ".mzXML")
    xcmsFilename = gsub(".mzXML","",xcmsFilename)
    
    #=====
    pb <<- tkProgressBar("Peak Analysis (Targeted) - Please wait for processing", "0% done", 0, 100, 0, width = 500)
    cat("Peak Analysis (Targeted) - Please wait for processing 0 ")
    
    ncpu <- as.numeric(tclvalue(textnslave))
    
    if (ncpu==1|is.na(ncpu)==T){
      
      out <- sapply(1:length(xcmsFiles), function(x) {
        info <- sprintf("%d%%", round(100*x/length(xcmsFiles)))
        setTkProgressBar(pb, value = round(100*x/length(xcmsFiles)), sprintf("Peak Analysis (Targeted) - Please wait for processing (%s done)", info), paste(xcmsFilename[x], info, sep = " "))
        if(round(100*x/length(xcmsFiles))<100){
          cat(round(100*x/length(xcmsFiles)), " ", sep = "")
        }else{
          cat(round(100*x/length(xcmsFiles)), " \n", sep = "")
        }
        targeted_analysis(datafilename = xcmsFiles[x], params = params ,target = target_table, mz_list = target_mz, outpath = outpath, tol_mz = tol_mz)
      })
      
    }else{
      cl <- makeCluster(ncpu, methods = FALSE)
      clusterExport(cl, c("xcmsFiles","params","target_table","target_mz","outpath","tol_mz"), envir=environment())
      clusterEvalQ(cl, {
        library(xcms) 
        library(dplyr)
        library(png)
      })
      out <- parSapply(cl, X= 1:length(xcmsFiles), function(x) targeted_analysis(datafilename = xcmsFiles[x], params = params ,target = target_table, mz_list = target_mz, outpath = outpath, tol_mz = tol_mz))
      stopCluster(cl)
    }
    
    setTkProgressBar(pb, value = 100, "Peak Analysis (Targeted) - Please wait for processing (100% done)", "Finished 100%")
    Sys.sleep(1)
    close(pb)
    
    colnames(out) <- xcmsFilename
    l <- c(sapply(1:length(target_mz),function(x)length(target_mz[[x]])))
    
    
    idx <- c()
    for(i in 1:nrow(target_table)){
      tmp <- 1:l[i]
      if(i!=1){
        tmp <- tmp + 4*sum(l[1:(i-1)])
      }
      idx <- c(idx,tmp)
    }
    target_table <- target_table[,colnames(target_table)!="tol_time.sec"]
    target_out <- data.frame(Peak_Index=1:sum(l),target_table[rep(1:nrow(target_table),l),1:4])
    target_out$mz <- unlist(target_mz)
    if(all(is.na(target_out$parent_ion))){
      target_out <- target_out[,-3]
    }
    
    est_mz <- out[idx,]
    peak_ab <- out[idx+rep(l,l),]　
    rt <- out[idx+rep(l*2,l),]
    sn <- out[idx+rep(l*3,l),]
    
    target_out$Ret_Time_est.sec <- if(is.null(ncol(rt))){rt}else{rowMeans(rt,na.rm = T)}
    target_out$mz_est <- if(is.null(ncol(rt))){est_mz}else{rowMeans(est_mz,na.rm = T)}
    


    out_rt <- cbind(target_out,rt) 
    colnames(out_rt) <- c(colnames(target_out),xcmsFilename)
    
    write.csv(out_rt,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_retention_time_MS",params$mslevel,".csv"),row.names = F)
    
    out_sn <- cbind(target_out,sn)
    colnames(out_sn) <- c(colnames(target_out),xcmsFilename)
    
    write.csv(out_sn,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_sn_MS",params$mslevel,".csv"),row.names = F)
    
    out_mz <- cbind(target_out,est_mz)
    colnames(out_mz) <- c(colnames(target_out),xcmsFilename)
    
    write.csv(out_mz,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_mz_MS",params$mslevel,".csv"),row.names = F)
    
    out_peak <- cbind(target_out,peak_ab)
    colnames(out_peak) <- c(colnames(target_out),xcmsFilename)
    
    write.csv(out_peak,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_peak_abundance_MS",params$mslevel,".csv"),row.names = F)
    
    out_SMART <- cbind(target_out[,c("Peak_Index","Name","mz_est","Ret_Time_est.sec")],peak_ab)
    colnames(out_SMART) <- c("Peak_Index","Name","mz_est","Ret_Time_est.sec",xcmsFilename)
    
    write.csv(out_SMART,paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_peak_abundance_MS",params$mslevel,"_forSMART.csv"),row.names = F)
    
    if(!is.null(ncol(peak_ab))){
      tmp <- unique(target_out$Name)
      for(v in 1:length(tmp)){
        sub_peak <- peak_ab[which(target_out$Name==tmp[v]),,drop=F]
        peak_ab[which(target_out$Name==tmp[v]),] <- t(t(sub_peak)/colMaxs(sub_peak,na.rm=T))*100
      }
    }else{
      tmp <- unique(target_out$Name)
      for(v in 1:length(tmp)){
        sub_peak <- peak_ab[which(target_out$Name==tmp[v])]
        peak_ab[which(target_out$Name==tmp[v])] <- t(t(sub_peak)/max(sub_peak,na.rm=T))*100
      }
    }
    
    if(!all(peak_ab==100,na.rm = T)){
      write.csv(cbind(target_out,peak_ab),paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_nofilledPeak_relative_abundance_MS",params$mslevel,".csv"),row.names = F)
    }
    
    textAbuninput <<- tclVar(paste0("Peak Analysis (Targeted)/S",length(xcmsFiles),"_nofilledPeak_MS",params$mslevel,"_forSMART.csv"))
    
    text_zero <<- tclVar("0")
    text_missing <<- tclVar("NA")
    
    tkmessageBox(title = "Peak Analysis", message = "Peak Analysis (Targeted) is done.", icon = "info", type = "ok")
    cat("Peak Analysisn (Targeted) is done.\n")
    
    tkentryconfigure(peakMenu, 1, state = "active")
    tkentryconfigure(QCsubMenu, 0, state = "active")
    
    tkentryconfigure(batchsubMenu, 0, state = "active")
    tkentryconfigure(batchsubMenu, 1, state = "active")
    tkentryconfigure(statMenu, 1, state = "active")
    tkentryconfigure(statMenu, 2, state = "active")
    
    
    
  }
  onRun <- function(){
    if(as.numeric(tclvalue(add_data))==2){
      eval(onOK())
    }else{
      eval(Import_MSn())
    }
  }
  onCancel <- function(){
    tkdestroy(dlg)
    tkfocus(tt)
  }
  
  fr <- tkframe(dlg)
  tkpack(fr, side = "top")
  OK.but     <-tkbutton(fr,text="     OK     ",command=onRun)
  Cancel.but <-tkbutton(fr,text="   Cancel   ",command=onCancel)
  tkgrid(tklabel(fr,text="               "), OK.but,tklabel(fr,text="                                                         "), Cancel.but, tklabel(fr,text="               "))
  tkgrid(tklabel(fr,text="    ", height = 0, font = fontIntro_para))
  
  tkfocus(dlg)
  tkbind(dlg, "<Destroy>", function() {tkgrab.release(dlg);tkfocus(tt)})
  
  
  tkwait.window(dlg)
}
