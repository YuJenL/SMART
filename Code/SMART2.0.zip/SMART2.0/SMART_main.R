rm(list = ls())
gc()
library(tcltk)
setwd("G:/SMART2/Code/SMART2.0")

getwd()

load("dbMetabo.RData")
load("function_ls.RData")
load("hsaSPIA_reversible(cumulative_sum).RData")
load("KEGG_pathway_class.Rdata")

file <- list.files(pattern = ".R")
file <- file[!grepl("SMART|Rdata|RData",file)]

file

sapply(file, function(x)source(x))


#msconvert C:/Users/yujen/AppData/Local/Apps

