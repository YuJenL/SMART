Concentration_calculation <- function(){
  dlg <- tktoplevel(width = 800); if(isIcon) tk2ico.set(dlg,icon)
  tkwm.title(dlg, "Concentration Calibration - Concentration Calculation")
  
  fr_step <- tkframe(dlg, width = 800)
  tkgrid(tklabel(fr_step, text = "   Step1: Import Peak Abundance Table",foreground="black"),
         tklabel(fr_step, text = "  -> Step2: Import Model Infomation",foreground="gray"))
  tkgrid(fr_step, sticky = "w")
  
  fr_input <- tkframe(dlg, width = 800)
  
  fr_import <- tkframe(dlg)
  
  
  textCalipred <<- tclVar()
  textinputWidget <- tkentry(fr_input,width="70", textvariable = textCalipred, bg = "white")
  box.input <- tkbutton(fr_input, text = "...",  command = function() tclvalue(textCalipred) <- tkgetOpenFile(initialfile = tclvalue(textCalipred), filetypes = "{{Text Files} {.txt .csv}}"))
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  inputlabel <- tklabel(fr_input, text="   Input file: ")
  tkgrid(inputlabel,textinputWidget, box.input, tklabel(fr_input,text="    "), sticky = "w")
  tkgrid(tklabel(fr_input, text="",height = 0, font = fontIntro_para))
  tkgrid(fr_input,sticky = "w")
  

  
  
  text_missing <<- tclVar("NA")
  missing_lab <- tklabel(fr_input, text = "   Missing data:       ")
  missing_widget <- tkentry(fr_input, textvariable = text_missing, bg = "white",width=5)
  tkgrid(missing_lab, missing_widget, sticky = "w")
  
  onCancel <- function()
  {
    tkdestroy(dlg)
    tkfocus(tt)
  }
  
  
  
  
  fr <- tkframe(dlg)
  tkgrid(fr)
  contin.but     <- tkbutton(fr,text="  Continue  ",command=function(...){
    if(file.exists(tclvalue(textCalipred)) ){
      
      
      tkdestroy(dlg)
      checking <- tktoplevel(); if(isIcon) tk2ico.set(checking,icon)
      tktitle(checking) = "Column Information"
      input_idx_head = tkframe(checking)
      tkgrid(tklabel(input_idx_head, text = "   Please provide column information:"), sticky = "w")
      tkgrid(tklabel(input_idx_head, text = "", font = fontIntro_para, height = 0), sticky = "w")
      tkgrid(input_idx_head, sticky = "w")
      
      input_idx = tkframe(checking)
      
      PI.lab = tklabel(input_idx, text = "   Column index of peak index: ")
      tk2tip(PI.lab, "Please input column index of peak index if you have.")
      index.PI <<- tclVar("NA")
      PI_entry = tkentry(input_idx, width = "5", textvariable = index.PI, bg = "white")	
      tkgrid(PI.lab, PI_entry, sticky = "w")
      
      name.lab = tklabel(input_idx, text = "   Column index of name: ")
      tk2tip(name.lab, "Please input column index of name if you have.")
      index.name <<- tclVar("NA")
      name_entry = tkentry(input_idx, width = "5", textvariable = index.name, bg = "white")	
      tkgrid(name.lab, name_entry, sticky = "w")
      
      
      mass.lab <- tklabel(input_idx, text = "   Column index of mass: ")
      index.mass <<- tclVar("")
      mass_entry = tkentry(input_idx, width = "5", textvariable = index.mass, bg = "white")
      tkgrid(mass.lab, mass_entry, sticky = "w")
      
      
      RT.lab = tklabel(input_idx, text = "   Column index of retention time: ")
      index.RT <<- tclVar("")
      RT_entry = tkentry(input_idx, width = "5", textvariable = index.RT, bg = "white")
      RT_unit = c("min", "sec")
      RT_text = tclVar("sec")
      RTunit.lab = tklabel(input_idx, text = "  unit: ")
      RTcomboBox <- ttkcombobox(input_idx, state = "readonly", values = RT_unit, width = 4, textvariable = RT_text)
      tkgrid(RT.lab, RT_entry, RTunit.lab, RTcomboBox, tklabel(input_idx, text = "   "), sticky = "w")
      
      
      first.lab = tklabel(input_idx, text = "   Column index of first sample: ")
      index.first <<- tclVar("")
      first_entry = tkentry(input_idx, width = "5" ,textvariable = index.first, bg = "white")
      tkgrid(first.lab, first_entry, sticky = "w")
      
      tkgrid(tklabel(input_idx, text = "", height = 0, font = fontIntro_para))
      tkgrid(input_idx)
      
      contiframe = tkframe(checking)
      
      conti.button <- tkbutton(contiframe, text = "   Import   ", command = function(){
        RT.unit <<- tclvalue(RT_text)
        
        if(tclvalue(index.PI)=="NA"){
          tkmessageBox(title = "Error", message = "Please provide the column index of peak index.", icon = "error", type = "ok")
          cat("Please provide the column index of peak index.")
          stop("Please provide the column index of peak index.")
        }
        
        tkdestroy(checking)
        
        
        align_table_in <- read.table(tclvalue(textCalipred), header = T, quote = "\"", fill = T, sep = ifelse(grepl(".txt", tclvalue(textCalipred)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))))
        if(as.character(tclvalue(index.PI))=="NA"|as.character(tclvalue(index.name))=="NA"){
          
          align_table =  align_table_in[,as.numeric(c(tclvalue(index.mass), tclvalue(index.RT), seq.int(as.numeric(tclvalue(index.first)), ncol(align_table_in))))]
          if(as.character(tclvalue(index.PI))=="NA"){
            align_table$Peak_Index <- 1:nrow(align_table_in)
          }else{
            align_table$Peak_Index <- align_table_in[,as.numeric(tclvalue(index.PI))]
          }
          if(as.character(tclvalue(index.name))=="NA"){
            align_table$Name <- align_table$Peak_Index
          }else{
            align_table$Name <-align_table_in[,as.numeric(tclvalue(index.name))]
          }
          
          align_table <- align_table[,c(which(colnames(align_table)=="Peak_Index"),
                                        which(colnames(align_table)=="Name"),
                                        setdiff(1:ncol(align_table),c(which(colnames(align_table)=="Peak_Index"),which(colnames(align_table)=="Name"))))]
          
        }else{
          align_table = align_table_in[,as.numeric(c(tclvalue(index.PI),tclvalue(index.name), tclvalue(index.mass), tclvalue(index.RT), seq.int(as.numeric(tclvalue(index.first)), ncol(align_table_in))))]
        }
        nRow <- nrow(align_table)
        nCol <- ncol(align_table)
        align_table <- peakabunCheck(align_table,5)
        
        
        if(RT.unit == "min") align_table[,4] = 60*align_table[,4]
        colnames(align_table) = c("Peak_Index","Name", "mz", "Ret_time.sec", gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", colnames(align_table)[-c(1:4)]))
        
        
        assign("cali_pred", align_table, envir = .GlobalEnv)
        
        
        # tkfocus(tt)
        
        
        
        tkmessageBox(title = "Data Import", message = sprintf("Data import is done.\n%d out of %d non-informative replicate sample(s) are excluded.\n%d out of %d non-informative peak(s) are excluded.",nCol-ncol(align_table),nCol-4,nRow-nrow(align_table),nRow), icon = "info", type = "ok")
        cat(sprintf("Data import is done.\n%d out of %d non-informative replicate sample(s) are excluded.\n%d out of %d non-informative peak(s) are excluded.\n",nCol-ncol(align_table),nCol-4,nRow-nrow(align_table),nRow))
        
        ## model input
        model_info <- tktoplevel(width=800); if(isIcon) tk2ico.set(model_info,icon)
        tkwm.title(model_info,"Concentration Calibration - Concentration Calculation")
        
        fr_step <- tkframe(model_info, width = 800)
        tkgrid(tklabel(fr_step, text = "   Step1: Import Peak Abundance Table",foreground="gray"),
               tklabel(fr_step, text = "  -> Step2: Import Model Infomation",foreground="black"))
        tkgrid(fr_step, sticky = "w")
        
        fr_datatype <- tkframe(model_info)
        datatype <- tclVar("0")
        type_smart2 <- tkradiobutton(fr_datatype, variable = datatype, value = "1", command = function(){
          
          tkconfigure(inputlabel, text = "   Input folder:      ")
          tkconfigure(box.input, command = function() tclvalue(textCaliresult) <- tkchooseDirectory(initialdir = as.character(tclvalue(textCaliresult))))
          tkconfigure(OK.but, text = "  Run  ")
          tkgrid(fr_para,sticky="w")
          tkgrid(fr_para_choice,sticky="w")
          tkgrid(fr)

        })
        
        #
        type_user <- tkradiobutton(fr_datatype, variable = datatype, value = "2", command = function(){
          tkconfigure(box.input, state = "normal")
          tkconfigure(textinputWidget, state = "normal")
          # tkconfigure(OK.but, state = "normal")
          tkconfigure(inputlabel, text = "   Input file:           ")
          tkconfigure(box.input, command = function() tclvalue(textCaliresult) <- tkgetOpenFile(initialfile = as.character(tclvalue(textCaliresult)), filetypes = "{{Text Files} {.txt .csv}}"))
    
          
          tkgrid(fr)
          tkgrid.remove(fr_para)
          tkgrid.remove(fr_para_choice)
          tkconfigure(OK.but, text = "  Continue  ")
          
        })
        
        
        tkgrid(tklabel(fr_datatype,text="", font = fontIntro_para, height = 0))
        tkgrid(tklabel(fr_datatype, text = "   Data type:          "), type_smart2, tklabel(fr_datatype, text = "SMART2.0 format  ", state=ifelse(osIsWin,"normal","disabled")), type_user, tklabel(fr_datatype, text = "User"), sticky = "w")
        tkgrid(fr_datatype, sticky = "w")
        
        fr_input <- tkframe(model_info, width = 800)
        
        fr_import <- tkframe(model_info)
        
        
        textCaliresult <<- tclVar()
        textinputWidget <- tkentry(fr_input,width="70", textvariable = textCaliresult, bg = "white")
        box.input <- tkbutton(fr_input, text = "...",  command = function() tclvalue(textCaliresult) <- tkgetOpenFile(initialfile = tclvalue(textCaliresult), filetypes = "{{Text Files} {.txt .csv}}"))
        tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
        inputlabel <- tklabel(fr_input, text="   Input file: ")
        tkgrid(inputlabel,textinputWidget, box.input, tklabel(fr_input,text="    "), sticky = "w")
        tkgrid(tklabel(fr_input, text="",height = 0, font = fontIntro_para))
        tkgrid(fr_input,sticky = "w")
        
        ## 
        fr_para <- tkframe(model_info)
        tkgrid(tklabel(fr_para, text = "   preferred Model Setting:"))
        tkgrid(fr_para, sticky = "w")
        
        fr_para_choice <- tkframe(model_info)
        tkgrid(fr_para_choice, sticky = "w")
        
        ## model
        fr_mod <- tkframe(fr_para_choice)
        tkgrid(fr_mod, sticky = "w")
        
        labelmod <- tklabel(fr_mod,text = "      Model: ")
        
        mod_l.val = tclVar(1)
        modlinear = tkcheckbutton(fr_mod, variable = mod_l.val)
        labelmod.linear <- tklabel(fr_mod, text = "Linear")
        
        mod_q.val = tclVar(1)
        modquadr = tkcheckbutton(fr_mod, variable = mod_q.val)
        labelmod.quadr <- tklabel(fr_mod, text = "Quadratic")
        
        tkgrid(labelmod, modlinear, labelmod.linear, 
               modquadr,labelmod.quadr, sticky = "w")
        
        
        ## weighting
        fr_wt <- tkframe(fr_para_choice)
        tkgrid(fr_wt, sticky = "w")
        
        labelweight <- tklabel(fr_wt,text = "      Weighting: ")
        
        weight_1.val = tclVar(1)
        modweight.1 = tkcheckbutton(fr_wt, variable = weight_1.val)
        labelweight.1 <- tklabel(fr_wt, text = "unweighted")
        
        weight_x.val = tclVar(1)
        modweight.over1 = tkcheckbutton(fr_wt, variable = weight_x.val)
        labelweight.over1 <- tklabel(fr_wt, text = "1/x")
        
        weight_x2.val = tclVar(1)
        modweight.over2 = tkcheckbutton(fr_wt, variable = weight_x2.val)
        labelweight.over2 <- tklabel(fr_wt, text = "1/x^2")
        
        
        tkgrid(labelweight,modweight.1,labelweight.1,
               modweight.over1, labelweight.over1,
               modweight.over2, labelweight.over2, sticky = "w")
        
        
        
        
        # outlier
        fr_outlier <- tkframe(fr_para_choice)
        tkgrid(fr_outlier, sticky = "w")
        
        labeloutlier <- tklabel(fr_outlier, text="      Outlier Dectection: ")
        
        cI.val = tclVar(1)
        outlier_CI <- tkcheckbutton(fr_outlier, variable = cI.val) 
        
        cook.val = tclVar(1)
        outlier_cook = tkcheckbutton(fr_outlier, variable = cook.val)
        
        
        dev.val = tclVar(1)
        outlier_dev <- tkcheckbutton(fr_outlier, variable = dev.val) 
        
        tkgrid(labeloutlier,outlier_cook,tklabel(fr_outlier, text = "Cook's Distance"),
               outlier_CI, tklabel(fr_outlier, text = "Confidence Interval"),
               outlier_dev, tklabel(fr_outlier, text = "Deviation"), sticky = "w")
        
        
        
        onSmart2 <- function(){
          m <- c("lm","qm")
          w <- c("1","x","x2")
          dtp <- c("all","cook","conf","bias")
          
          if(sum(as.numeric(c(tclvalue(mod_l.val),tclvalue(mod_q.val))))==0|sum(as.numeric(c(tclvalue(weight_1.val),tclvalue(weight_x.val),tclvalue(weight_x2.val))))==0){
            tkmessageBox(title = "Error", message = "Please select the model or the weighting method.", icon = "error", type = "ok")
            cat("Please select the model or the weighting method.")
            stop("Please select the model or the weighting method.")
          }
          
          tkdestroy(model_info)
          # tkconfigure(tt,cursor="watch")
          
          m <- m[as.numeric(c(tclvalue(mod_l.val),tclvalue(mod_q.val)))==1]
          w <- w[as.numeric(c(tclvalue(weight_1.val),tclvalue(weight_x.val),tclvalue(weight_x2.val)))==1]
          dtp <- dtp[as.numeric(1,tclvalue(cook.val),tclvalue(cI.val),tclvalue(dev.val))==1]
          
          
          load(list.files(tclvalue(textCaliresult),pattern = ".RData",full.names = T))
          
          outpath_pred <- strsplit(list.files(tclvalue(textCaliresult),pattern = ".RData",full.names = T),"/")[[1]]
          outpath_pred <- paste(c(outpath_pred[-length(outpath_pred)],"Conc.Calculation"),collapse ="/")
          dir.create(outpath_pred)
          assign("outpath_pred", outpath_pred, envir = .GlobalEnv)
          
          df <- df[match(peak_info$Peak_Index,cali_pred$Peak_Index),]
          cali_pred <- cali_pred[match(peak_info$Peak_Index,cali_pred$Peak_Index),]
          
          mod <- c("linear","quadratic")
          names(mod) <- c("lm","qm")
          mw <- c("unweighted","weights=1/x","weights=1/x2")
          names(mw) <- c("1","x","x2")
          mo <- c("","Cook's distance","Confidence Interval","Bias")
          names(mo) <- c("all","cook","conf","bias")
          
          result <- c()
          model_bst <- list()
          model_bst_name <- c()
          
          for(x in which(!is.na(cali_pred$Peak_Index))){
            model <- model_fit[[x]][["model"]][paste(rep(m,each=length(w)*length(dtp)),
                                                     rep(w,each=length(m)*length(dtp)),
                                                     rep(dtp,length(w)*length(m)),sep = "_")]
            
            data_pt <- model_fit[[x]][["data_pt"]][paste(rep(m,each=length(w)*length(dtp)),
                                              rep(w,each=length(m)*length(dtp)),
                                              rep(dtp,length(w)*length(m)),sep = "_")]
            
            r2 <- sapply(1:length(model),function(x)ifelse(is.null(model[[x]]),0,R2(model[[x]])[2]))
            names(r2) <- names(model)
            
            conc <- as.numeric(sapply(1:ncol(df), function(x)strsplit(colnames(df)[x],"_")[[1]][2]))
            data_fit <- data.frame(conc=data_pt[[which.max(r2)]],y=unlist(df[x,which(conc%in%data_pt[[which.max(r2)]])]))
            
            conc_pred <- t(sapply(5:ncol(cali_pred), function(y)tryCatch(unlist(invest(model[[which.max(r2)]], y0 = cali_pred[x,y], interval = "inversion",weight=1,lower=-100000,upper=100000)[1:3]), error=function(err) c(NA,NA,NA))))
            
            result <- rbind(result,as.vector(t(conc_pred)))
            model_bst_name[x] <- names(which.max(r2))
            model_bst[[x]] <- model[[which.max(r2)]]
            
            if(!is.null( model[[which.max(r2)]])){
              tiff(paste0(outpath_pred,"/Conc.Calculation_PID",x,"_S",ncol(cali_pred)-4,"_P",nrow(cali_pred),".tiff"), width=1440*2, height=1080*2, compression="lzw", res=300*2)
              par(mar=c(2,2,4,2),oma=c(2,2,2,2))
              plot(data_fit$conc,data_fit$y,pch=16,xlab="",ylab="",xpd=NA,bty="n",yaxt="n",xaxt="n",cex=1)
              box(which = "plot", bty = "l",lwd=2)
              axis(side = 1, lwd = 2,cex.axis=0.7,font=2)
              axis(side = 2, lwd = 2,cex.axis=0.7,font=2,las=2)
              
              
              
              
              loc <- par("usr")
              text(loc[1], loc[4]*1.05, "Intensity", pos = 2, xpd = NA,font=2,cex=0.9)
              
              mtext(side=1,line=3 ,"Concentration",font=2,cex=0.8)
              
              
              mtext(side=3, line=3.5, cex=1,paste0("Peak Index ",peak_info$Peak_Index[x],", ",peak_info$Name[x],", m/z = ",peak_info$mz[x]),font=2,xpd=NA)
              mtext(side=3, line=1.5, cex=0.8, mw[strsplit(names(which.max(r2)),"_")[[1]][2]],font=2,xpd=NA)
              mtext(side=3, line=2.5, cex=0.8, mo[strsplit(names(which.max(r2)),"_")[[1]][3]],font=2,xpd=NA)
              
              beta <- round(coef(model[[which.max(r2)]]),2)
              if(length(beta)==2){
                expr_beta = bquote(bold(Y == .(beta[1])~"+"~.(beta[2])~"X"))
                curve(beta[1]+beta[2]*x,conc, add = TRUE, lwd = 2, col = "red")
              }else{
                expr_beta = bquote(bold(Y == .(beta[1])~"+"~.(beta[2])~"X"~"+"~.(beta[3])~X^2))
                curve(beta[1]+beta[2]*x+beta[3]*x^2,conc, add = TRUE, lwd = 2, col = "red")
              }
              mtext(side=3, line=0, cex=0.8, expr_beta,font=2)
              points(conc_pred[,1],cali_pred[x,-c(1:4)],pch=16,col="blue",cex=1)
              
              legend("topright", inset = c(- 0.2, 0),                   
                     legend = c("Standard","Test"),
                     pch = c(16,16),
                     col = c("black","blue"),xpd=NA,cex=0.5)
              
              dev.off()
            }
          }
          
          
          
          
          result_est <- cbind(cali_pred[,1:4],result[,seq(1,3*(ncol(cali_pred)-4),3)])
          colnames(result_est) <- colnames(cali_pred)
          write.table(result_est, file = paste(outpath_pred, "/Conc.Calculation_S",ncol(result_est)-4,"_P",nrow(result_est), ".csv", sep = ""), sep = ",", col.names = T, row.names = F, quote = 1)
          
          
          
          
          
          
          colnames(result) <- rep(colnames(cali_pred)[-c(1:4)],each=3)
          best_model <- data.frame(model=mod[sapply(1:length(model_bst_name), function(x)strsplit(model_bst_name[x],"_")[[1]][1])],
                                   weights=mw[sapply(1:length(model_bst_name), function(x)strsplit(model_bst_name[x],"_")[[1]][2])],
                                   outlier_detection=mo[sapply(1:length(model_bst_name), function(x)strsplit(model_bst_name[x],"_")[[1]][3])])
          result_all <- cbind(cali_pred[,1:4],best_model)
          result_all <- cbind(result_all,result)
          
          
          result_all <- rbind(c(rep("",7),rep(c("estimate","lower","upper"),ncol(result_est)-4)),result_all)
          write.table(result_all, file = paste(outpath_pred, "/Conc.Calculation_CI_S",ncol(result_est)-4,"_P",nrow(result_est), ".csv", sep = ""), sep = ",", col.names = T, row.names = F, quote = 1)
          
          model_bst_theta <-  t(sapply(1:length(model_bst),function(x){
            beta = coef(model_bst[[x]])
            if(is.null(beta)){beta <- c(NA,NA)}
            if(length(beta)==2){beta <- c(beta,theta3=NA)}
            
            beta
          }))
          bst_model_out <- cbind(cali_pred[,1:4],best_model)
          bst_model_out <- cbind(bst_model_out,model_bst_theta)
          write.table(bst_model_out, file = paste(outpath_pred, "/best_model.csv", sep = ""), sep = ",", col.names = T, row.names = F, quote = 1,na = "")
         
          
          tkmessageBox(title = "Concentration Calibration - Concentration Calculation", message = "Concentration Calibration - Concentration Calculation is done.", icon = "info", type = "ok")
          cat("Concentration Calibration - Concentration Calculation is done.\n")
        }
        onUser <- function(){
          ## user
          tkdestroy(model_info)
          
          checking <- tktoplevel(); if(isIcon) tk2ico.set(checking,icon)
          tktitle(checking) = "Column Information"
          input_idx_head = tkframe(checking)
          tkgrid(tklabel(input_idx_head, text = "   Please provide column information:      "), sticky = "w")
          tkgrid(tklabel(input_idx_head, text = "", font = fontIntro_para, height = 0), sticky = "w")
          tkgrid(input_idx_head, sticky = "w")
          
          fr_user <- tkframe(checking)
          tkgrid(tklabel(fr_user, text = "   Column Information:"))
          
          
          input_idx = tkframe(checking)
          tkgrid(input_idx,sticky="W")
          
          PI.lab = tklabel(input_idx, text = "      Column index of peak index: ")
          tk2tip(PI.lab, "Please input column index of peak index if you have.")
          index.PI <<- tclVar(" ")
          PI_entry = tkentry(input_idx, width = "5", textvariable = index.PI, bg = "white")	
          tkgrid(PI.lab, PI_entry, sticky = "w")
          
          name.lab = tklabel(input_idx, text = "      Column index of name: ")
          tk2tip(name.lab, "Please input column index of name if you have.")
          index.name <<- tclVar(" ")
          name_entry = tkentry(input_idx, width = "5", textvariable = index.name, bg = "white")	
          tkgrid(name.lab, name_entry, sticky = "w")
          
          theta1.lab = tklabel(input_idx, text = "      Column index of theta1: ")
          index.theta1 <<- tclVar(" ")
          theta1_entry = tkentry(input_idx, width = "5", textvariable = index.theta1, bg = "white")	
          tkgrid(theta1.lab, theta1_entry, sticky = "w")
          
          theta2.lab = tklabel(input_idx, text = "      Column index of theta2: ")
          index.theta2 <<- tclVar(" ")
          theta2_entry = tkentry(input_idx, width = "5", textvariable = index.theta2, bg = "white")	
          tkgrid(theta2.lab, theta2_entry, sticky = "w")
          
          theta3.lab = tklabel(input_idx, text = "      Column index of theta3: ")
          index.theta3 <<- tclVar("NA")
          theta3_entry = tkentry(input_idx, width = "5", textvariable = index.theta3, bg = "white")	
          tkgrid(theta3.lab, theta3_entry, sticky = "w")
          
          text_missing <<- tclVar("NA")
          missing_lab <- tklabel(input_idx, text = "      Missing data:       ")
          missing_widget <- tkentry(input_idx, textvariable = text_missing, bg = "white", width = "5")
          tkgrid(missing_lab, missing_widget, sticky = "w")
          
         
          
          tkgrid(tklabel(input_idx, text = "", height = 0, font = fontIntro_para))
          tkgrid(input_idx)
          
          contiframe = tkframe(checking)
          conti.button <- tkbutton(contiframe, text = "   Import   ", command = function(){
            
            if(tclvalue(index.PI)=="NA"){
              tkmessageBox(title = "Error", message = "Please provide the column index of peak index.", icon = "error", type = "ok")
              cat("Please provide the column index of peak index.")
              stop("Please provide the column index of peak index.")
            }
            
            if(tclvalue(index.theta1)=="NA"|tclvalue(index.theta2)=="NA"){
              tkmessageBox(title = "Error", message = "Please provide the column index of theta1 or theta2 index.", icon = "error", type = "ok")
              cat("Please provide the column index of theta1 or theta2 index.")
              stop("Please provide the column index of theta1 or theta2 index.")
            }
            tkdestroy(checking)
            
            outpath_pred <- strsplit(tclvalue(textCaliresult),"/")[[1]]
            outpath_pred <- paste(c(outpath_pred[-length(outpath_pred)],"Predition"),collapse ="/")
            dir.create(outpath_pred)
            assign("outpath_pred", outpath_pred, envir = .GlobalEnv)
            
            cali_model_in <- read.table(tclvalue(textCaliresult), header = T, quote = "\"", fill = T, sep = ifelse(grepl(".txt", tclvalue(textCaliresult)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))))
            cali_model <- cali_model_in[,as.numeric(c(tclvalue(index.PI),tclvalue(index.theta1),tclvalue(index.theta2)))]
            if(tclvalue(index.theta3)=="NA"){
              cali_model$theta3 <- 0
            }else{
              cali_model$theta3 <- cali_model_in[,as.numeric(tclvalue(index.theta3))]
            }
            
            cali_pred <- cali_pred[match(cali_model$Peak_Index,cali_pred$Peak_Index),]
            
            out_pred <- t(sapply(1:nrow(cali_model), function(t){
              f <- function(x,a)cali_model$theta1[t]+cali_model$theta2[t]*x+cali_model$theta3[t]*x^2-a
              sapply(5:ncol(cali_pred), function(y)tryCatch(uniroot(f, lower = -100000, upper = 100000,a=cali_pred[t,y])$root, error=function(err) NA))
            }))
            
            out_pred <- cbind(cali_pred[,1:4],t(out_pred))
            colnames(out_pred) <- c("Peak_Index","Name","mz","Ret_time.sec",colnames(cali_pred)[-c(1:4)])
            
            write.table(out_pred, file = paste(outpath_pred, "/Conc.Calculation_S",ncol(out_pred)-4,"_P",nrow(out_pred), ".csv", sep = ""), sep = ",", col.names = T, row.names = F, quote = 1,na="")
            
            
            tkmessageBox(title = "Concentration Calibration - Concentration Calculation", message = "Concentration Calibration - Concentration Calculation is done.", icon = "info", type = "ok")
            cat("Concentration Calibration - Concentration Calculation is done.\n")
            
          })
          
          tkgrid(conti.button)
          tkgrid(tklabel(contiframe, text = "", height = 0, font = fontIntro_para))
          tkgrid(contiframe)
          
        }
        
        onRun <- function(){
          if(tclvalue(datatype)=="1"){
            eval(onSmart2())
          }else{
            eval(onUser())
          }
        }
        
        onCancel <- function()
        {
          
          tkdestroy(model_info)
          tkfocus(tt)
        }
        
        fr_but <- tkframe(model_info)
        tkgrid(fr_but)
        
        fr <- tkframe(fr_but)
        tkgrid(tklabel(fr,text="", font = fontIntro_para, height = 0))
        OK.but     <- tkbutton(fr,text="  Run  ",command=onRun)
        Cancel.but <-tkbutton(fr,text="  Cancel  ",command=onCancel)
        tkgrid(tklabel(fr,text="   "), OK.but,tklabel(fr,text="                                                         "), Cancel.but, tklabel(fr,text="   "))
        tkgrid(tklabel(fr,text="    ", font = fontIntro_para, height = 0))
        
        tkgrid(fr)
       
      })
      tkgrid(conti.button)
      tkgrid(tklabel(contiframe, text = "", height = 0, font = fontIntro_para))
      tkgrid(contiframe)
      
    }else{
      tkmessageBox(title = "Error", message = "File is not found.\nPlease input the correct directories.", icon = "error", type = "ok")
      cat("Data Import(Error) - File is not found. Please input the correct directories.\n")
      tkfocus(dlg)
    }
    
    
    
  })
  Cancel.but <-tkbutton(fr,text="   Cancel   ",command=onCancel)
  tkgrid(tklabel(fr,text="               "), contin.but,tklabel(fr,text="                                                         "), Cancel.but, tklabel(fr,text="               "))
  tkgrid(tklabel(fr,text="    ", height = 0, font = fontIntro_para))
  
  tkbind(dlg, "<Destroy>", function() {tkgrab.release(dlg);tkfocus(tt)})
  
  
  tkwait.window(dlg)
}

