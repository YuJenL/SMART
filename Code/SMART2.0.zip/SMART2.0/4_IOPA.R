#Ibind functions
der_erf=function(x) {2/(pi^0.5)*exp(-x^2)}
der_norm=function(x) {1/(2*2^0.5)*der_erf(x/(2^0.5))}
#Important!!! Since: der_qnorm(1-exp(y)) was exchanged to der_qnorm(exp(y)) in test_f, qnorm(x) -> qnorm(x,lower.tail=FALSE)
der_qnorm=function(x) {1/(der_norm(qnorm(x,lower.tail=FALSE)))}

test_f=function(x,y,r,w=NULL){
  rr=(1-r^2)^0.5
  if(is.null(w)){
    temp_qnorm_x=qnorm(exp(x),lower.tail=FALSE)
    temp_qnorm_y=qnorm(exp(y),lower.tail=FALSE)
    if(is.na(temp_qnorm_y) | is.na(temp_qnorm_x) | is.infinite(temp_qnorm_y) | is.infinite(temp_qnorm_x)){
      return(0)
    }
    return(abs(-der_norm((temp_qnorm_y-r*temp_qnorm_x)/rr)*(-der_qnorm(exp(y))/rr))*exp(x)*exp(y))
  }else{
    temp_qnorm_x=qnorm(exp(x/w),lower.tail=FALSE)
    temp_qnorm_y=qnorm(exp(y/(1-w)),lower.tail=FALSE)
    if(is.na(temp_qnorm_y) | is.na(temp_qnorm_x) | is.infinite(temp_qnorm_y) | is.infinite(temp_qnorm_x)){
      return(0)
    }
    return(abs(-der_norm((temp_qnorm_y-r*temp_qnorm_x)/rr)*(-der_qnorm(exp(y/(1-w)))/rr))*exp(x/w)*exp(y/(1-w))*(1/w)*(1/(1-w)))
  }
}
test_f=Vectorize(test_f)

fisher=function(x,y){
  return(x*y-x*y*log(x*y))
}

integral_method=function(p1, p2, r=NULL, method="int", w=NULL, max_exp=17, rel_error=1e-5){
  if(is.null(r)){
    sell=(!is.na(p1))&(!is.na(p2))
    r=cor(p1[sell],p2[sell])
    if(is.na(r)){stop("please enter correlation r")}
  }
  test_f=Vectorize(test_f)
  
  if(r==1) stop("correlation r must be less than 1")
  
  if(method=="int"){
    int_f=function(xx){
      if(is.na(p1[xx])|is.na(p2[xx])){
        return(NA)
      }else if((p1[xx]*p2[xx])<=10^(-max_exp)){
        return(0)
      }
      else{
        return(1-integrate(function(y) {
          sapply(y, function(y) {
            integrate(function(x) {
              sapply(x, function(x) test_f(x,y,r))
            }, log(p1[xx])+log(p2[xx])-y, 0,rel.tol=rel_error)$value
          })
        }, log(p1[xx])+log(p2[xx]), 0,rel.tol=rel_error)$value)
      }
    }
    temp=unlist(lapply(1:length(p1), function(xx) {
      if(xx%in%round(quantile(1:length(p1),(1:10)/10))){
        cat("\n")
        cat(paste("Progress",round(xx/length(p1)*100,2)))
      }
      return(int_f(xx))
    }))
    temp=ifelse(temp<0,0,temp)
  }else if(method=="fisher"){
    temp=fisher(p1,p2)
  }else if(method=="decor"){
    rr=(1-r^2)^0.5
    temp=fisher(p1,1-pnorm((qnorm(1-p2)-r*qnorm(1-p1))/rr))
  }else if(method=="int_weighted"){
    temp=unlist(lapply(1:length(p1), function(xx)
      1-integrate(function(y) {
        sapply(y, function(y) {
          integrate(function(x) {
            sapply(x, function(x) test_f(x,y,r,w=w))
          }, w*log(p1[xx])+(1-w)*log(p2[xx])-y, 0)$value
        })
      }, w*log(p1[xx])+(1-w)*log(p2[xx]), 0)$value))
    temp=ifelse(temp<0,0,temp)
  }
  MM=1
  
  while(any(temp==0,na.rm=T)&(MM<=5)){
    #print(paste(temp,sep=""))
    cat("\n")
    cat(paste("RS times = ",MM,sep=""))
    rel_error=(1e-5)*10^(-(MM*2))
    p1=p1[temp%in%0]
    p2=p2[temp%in%0]
    temp[temp%in%0]=unlist(lapply(1:length(p1), function(xx) {return(int_f(xx))}))
    temp=ifelse(temp<0,0,temp)
    MM=MM+1
  }
  return(temp)
}

fisher.sum <- function(p,zero.sub=0.00001,na.rm=FALSE) {
  if(any(p>1, na.rm=TRUE)||any(p<0, na.rm=TRUE))
    stop("You provided bad p-values")
  stopifnot(zero.sub>=0 & zero.sub<=1 || length(zero.sub)!=1)
  p[p==0] <- zero.sub
  if (na.rm)
    p <- p[!is.na(p)]
  S = -2*sum(log(p))
  res <- data.frame(S=S,num.p=length(p))
  return(res)
}

fisher.method <- function(pvals,method=c("fisher"),p.corr=c("bonferroni","BH",
                                                            "none"),zero.sub=0.00001,na.rm=FALSE,mc.cores=NULL) {
  stopifnot(method %in% c("fisher"))
  stopifnot(p.corr %in% c("none","bonferroni","BH"))
  stopifnot(all(pvals>=0, na.rm=TRUE) & all(pvals<=1, na.rm=TRUE))
  stopifnot(zero.sub>=0 & zero.sub<=1 || length(zero.sub)!=1)
  if(is.null(dim(pvals)))
    stop("pvals must have a dim attribute")
  p.corr <- ifelse(length(p.corr)!=1, "BH", p.corr)
  ##substitute p-values of 0
  pvals[pvals == 0] <- zero.sub
  if(is.null(mc.cores)) {
    fisher.sums <- data.frame(do.call(rbind,apply(pvals,1,fisher.sum,
                                                  zero.sub=zero.sub,na.rm=na.rm)))
  } 
  else {
    fisher.sums <- parallel::mclapply(1:nrow(pvals), function(i) {
      fisher.sum(pvals[i,],zero.sub=zero.sub,na.rm=na.rm)
    }, mc.cores=mc.cores)
    fisher.sums <- data.frame(do.call(rbind,fisher.sums))
  }
  
  rownames(fisher.sums) <- rownames(pvals)
  fisher.sums$p.value <- 1-pchisq(fisher.sums$S,df=2*fisher.sums$num.p)
  fisher.sums$p.adj <- switch(p.corr,
                              bonferroni = p.adjust(fisher.sums$p.value,"bonferroni"),
                              BH = p.adjust(fisher.sums$p.value,"BH"),
                              none = fisher.sums$p.value
  )
  return(fisher.sums)
}

aggregate_data=function(All_gene){
  temp=NULL
  colname=colnames(All_gene)
  log_FC_data=All_gene[,c(1,2)]
  P_data=All_gene[,c(1,3)]
  post_log_FC=aggregate(log_FC_data[,2] ~ log_FC_data[,1], FUN = mean, log_FC_data)
  post_P=aggregate(P_data[,2] ~ P_data[,1], FUN = function(x) fisher.method(matrix(x,nrow=1))$p.value, P_data)
  
  temp=cbind(post_log_FC,post_P[,2])
  colnames(temp)=colname
  return(temp)
}

spia_mod=function (All_gene, log_FC_cutoff_l = 0, log_FC_cutoff_u = 0, P_cutoff = 0.05, organism = "hsa", data.dir = NULL, data_name=NULL,
                   pathids = NULL, nB = 2000, plots = TRUE, p_labels = 10, verbose = TRUE, output_dir=NULL, table_file_name=NULL,
                   beta = NULL, combine = "fisher", rel_error = 1e-5) 
{	
  #sel = (All_gene[,1] > log_FC_cutoff)&(All_gene[,2] < P_cutoff)
  #de = All_gene[sel,1]
  #names(de) = rownames(All_gene)[sel]
  #all = rownames(All_gene)
  #sel = (All_gene[,2] > log_FC_cutoff)&(All_gene[,3] < P_cutoff)
  sel = ((All_gene[,2] <= log_FC_cutoff_l)|(All_gene[,2] >= log_FC_cutoff_u))&(All_gene[,3] < P_cutoff)
  de = All_gene[sel,2]
  names(de) = All_gene[sel,1]
  all = All_gene[,1]
  if (is.null(de) | is.null(all)) {
    stop("de and all arguments can not be NULL!")
  }
  rel <- c("activation", "compound", "binding/association", 
           "expression", "inhibition", "activation_phosphorylation", 
           "phosphorylation", "inhibition_phosphorylation", "inhibition_dephosphorylation", 
           "dissociation", "dephosphorylation", "activation_dephosphorylation", 
           "state change", "activation_indirect effect", "inhibition_ubiquination", 
           "ubiquination", "expression_indirect effect", "inhibition_indirect effect", 
           "repression", "dissociation_phosphorylation", "indirect effect_phosphorylation", 
           "activation_binding/association", "indirect effect", 
           "activation_compound", "activation_ubiquination")
  if (is.null(beta)) {
    beta = c(1, 1, 0, 1, -1, 1, 0, -1, -1, 0, 0, 1, 0, 1, 
             -1, 0, 1, -1, -1, 0, 0, 1, 0, 1, 1)
    names(beta) <- rel
  }else {
    if (!all(names(beta) %in% rel) | length(names(beta)) != 
        length(rel)) {
      stop(paste("beta must be a numeric vector of length", 
                 length(rel), "with the following names:", "\n", 
                 paste(rel, collapse = ",")))
    }
  }
  .myDataEnv <- new.env(parent = emptyenv())
  datload <- paste(organism, "SPIA", sep = "")
  if(!is.null(data_name)) datload=data_name
  if (is.null(data.dir)) {
    if (!paste(datload, ".RData", sep = "") %in% dir(system.file("extdata", 
                                                                 package = "SPIA"))) {
      cat("The KEGG pathway data for your organism is not present in the extdata folder of the SPIA package!!!")
      cat("\n")
      cat("Please generate one first using makeSPIAdata and specify its location using data.dir argument or copy it in the extdata folder of the SPIA package!")
    }
    else {
      load(file = paste(system.file("extdata", package = "SPIA"), 
                        paste("/", organism, "SPIA", sep = ""), ".RData", 
                        sep = ""), envir = .myDataEnv)
    }
  }
  if (!is.null(data.dir)) {
    if (!paste(datload, ".RData", sep = "") %in% dir(data.dir)) {
      cat(paste(data.dir, " does not contin a file called ", 
                paste(datload, ".RData", sep = "")))
    }
    else {
      print("dir_data_ok")
      load(file = paste(data.dir, paste(datload, ".RData", sep = ""), sep = ""), envir = .myDataEnv)
    }
  }
  datpT = .myDataEnv[["path.info"]]
  if (!is.null(pathids)) {
    if (all(pathids %in% names(datpT))) {
      datpT = datpT[pathids]
    }
    else {
      stop(paste("pathids must be a subset of these pathway ids: ", 
                 paste(names(datpT), collapse = " "), sep = " "))
    }
  }
  #print(datpT$"00330"$compound[c("C00334","C00555","2628","217","C00884","57571","55748"),c("C00334","C00555","2628","217","C00884","57571","55748")])
  datp <- list()
  path.names <- NULL
  #hasR <- NULL
  for (jj in 1:length(datpT)) {
    sizem <- dim(datpT[[jj]]$activation)[1]
    s <- 0
    con <- 0
    for (bb in 1:length(rel)) {
      con = con + datpT[[jj]][[rel[bb]]] * abs(sign(beta[rel[bb]]))
      s = s + datpT[[jj]][[rel[bb]]] * beta[rel[bb]]
    }
    z = matrix(rep(apply(con, 2, sum), dim(con)[1]), dim(con)[1], dim(con)[1], byrow = TRUE)
    z[z == 0] <- 1
    datp[[jj]] <- s/z
    path.names <- c(path.names, datpT[[jj]]$title)
    #hasR <- c(hasR, datpT[[jj]]$NumberOfReactions >= 1)#####aware!!!!!!!!!!!!
  }
  names(datp) <- names(datpT)
  names(path.names) <- names(datpT)
  tor <- lapply(datp, function(d) {sum(abs(d))}) == 0 | is.na(path.names)
  datp <- datp[!tor]
  path.names <- path.names[!tor]
  IDsNotP <- names(de)[!names(de) %in% all]
  if (length(IDsNotP)/length(de) > 0.01) {
    stop("More than 1% of your de genes have IDs are not present in the reference array!. Are you sure you use the right reference array?")
  }
  if (!length(IDsNotP) == 0) {
    cat("The following IDs are missing from all vector...:\n")
    cat(paste(IDsNotP, collapse = ","))
    cat("\nThey were added to your universe...")
    all <- c(all, IDsNotP)
  }
  if (length(intersect(names(de), all)) != length(de)) {
    stop("de must be a vector of log2 fold changes. The names of de should be included in the refference array!")
  }
  ph <- pb <- pcomb <- nGP <- pSize <- smPFS <- tA <- tAraw <- KEGGLINK <- NULL
  tA_normalized=NULL
  sum_de=NULL
  c_ph = g_ph = c_size = g_size = c_nde = g_nde = NULL
  set.seed(1)
  
  print(length(names(datp)))
  for (i in 1:length(names(datp))) {
    
    path <- names(datp)[i]
    M <- datp[[path]]
    #print(rownames(M))
    diag(M) <- diag(M) - 1
    X <- de[rownames(M)]
    noMy <- sum(!is.na(X))
    nGP[i] <- noMy
    c_nde[i] = sum((!is.na(de[rownames(M)])) & (substr(rownames(M),1,1)=="C"))
    g_nde[i] = sum((!is.na(de[rownames(M)])) & (substr(rownames(M),1,1)!="C"))
    okg <- intersect(rownames(M), all)
    ok <- rownames(M) %in% all
    pSize[i] <- length(okg)
    c_size[i] = sum(substr(okg,1,1)=="C")
    g_size[i] = sum(substr(okg,1,1)!="C")
    if ((noMy) > 0 & (abs(det(M)) > 1e-07)) {
      gnns <- paste(names(X)[!is.na(X)], collapse = "+")
      KEGGLINK[i] <- paste("http://www.genome.jp/dbget-bin/show_pathway?", 
                           organism, names(datp)[i], "+", gnns, sep = "")
      X[is.na(X)] <- 0
      pfs <- solve(M, -X)
      smPFS[i] <- sum(pfs - X)
      tAraw[i] <- smPFS[i]
      ph[i] <- phyper(q = noMy - 1, m = pSize[i], n = length(all) - 
                        pSize[i], k = length(de), lower.tail = FALSE)
      #print(c(c_nde - 1,c_size[i],sum(substr(all,1,1)=="C") - c_size[i],sum(substr(names(de),1,1)=="C")))
      c_ph[i] =phyper(q = c_nde[i] - 1, m = c_size[i], n = sum(substr(all,1,1)=="C") - 
                        c_size[i], k = sum(substr(names(de),1,1)=="C"), lower.tail = FALSE)
      g_ph[i] =phyper(q = g_nde[i] - 1, m = g_size[i], n = sum(substr(all,1,1)!="C") - 
                        g_size[i], k = sum(substr(names(de),1,1)!="C"), lower.tail = FALSE)
      pfstmp <- NULL
      for (k in 1:nB) {
        x <- rep(0, length(X))
        names(x) <- rownames(M)
        x[ok][sample(1:sum(ok), noMy)] <- as.vector(sample(de, 
                                                           noMy))
        tt <- solve(M, -x)
        pfstmp <- c(pfstmp, sum(tt - x))
      }
      mnn <- median(pfstmp)
      pfstmp <- pfstmp - mnn
      ob <- smPFS[i] - mnn
      tA[i] <- ob
      if (ob > 0) {
        pb[i] <- sum(pfstmp >= ob)/length(pfstmp) * 2
        if (pb[i] <= 0) {
          pb[i] <- 1/nB/100
        }
        if (pb[i] > 1) {
          pb[i] <- 1
        }
      }
      if (ob < 0) {
        pb[i] <- sum(pfstmp <= ob)/length(pfstmp) * 2
        if (pb[i] <= 0) {
          pb[i] <- 1/nB/100
        }
        if (pb[i] > 1) {
          pb[i] <- 1
        }
      }
      if (ob == 0) {
        if (all(pfstmp == 0)) {
          pb[i] <- NA
        }
        else {
          pb[i] <- 1
        }
      }
      pcomb[i] <- combfunc(pb[i], ph[i], combine)
      sum_de[i]=norm(datp[[path]])*norm(solve(M))*sum(abs(X))
      tA_normalized[i]=tAraw[i]/sum_de[i]
    }else {
      pb[i] <- ph[i] <- smPFS[i] <- pcomb[i] <- tAraw[i] <- tA[i] <- KEGGLINK[i] <- tA_normalized[i] <- sum_de[i] <- NA
      g_ph[i] = c_ph[i] = NA
    }
    if (verbose) {
      cat("\n")
      cat(paste("Done pathway ", i, " : ", substr(path.names[names(datp)[i]], 
                                                  1, 30), "..", sep = ""))
    }
  }
  
  cat("\nPost analysis and graph plotting")
  phFdr = p.adjust(ph, "fdr")
  phfwer = p.adjust(ph, "bonferroni")
  pbFdr = p.adjust(pb, "fdr")
  pbfwer = p.adjust(pb, "bonferroni")
  pcombFDR = p.adjust(pcomb, "fdr")
  pcombfwer = p.adjust(pcomb, "bonferroni")
  Name = path.names[names(datp)]
  Status = ifelse(tA > 0, "Activated", "Inhibited")
  res <- data.frame(Name, ID = names(datp),
					G_size = g_size, deG_n = g_nde, G_pORA = g_ph,
					C_size = c_size, deC_n = c_nde, C_pORA = c_ph,
					P_size = pSize,  deP_n = nGP,   pORA = ph, pORA_Bonf = phfwer, pORA_FDR = phFdr, raw_eSPIA=tAraw,
					eSPIA = tA, eSPIA_nor = tA_normalized, peSPIA = pb, peSPIA_Bonf = pbfwer, peSPIA_FDR = pbFdr,				
					pFisher = pcomb, pFisher_Bonf = pcombfwer, pFisher_FDR = pcombFDR,
					
					Status, KEGGLINK, stringsAsFactors = FALSE)
  res <- res[order(res$pFisher_FDR, res$pFisher), ]
  write.table(res, file=table_file_name,sep=",",quote=T,row.name=F)
  if(all(is.na(pb)|is.na(ph))){
	cat("\nIOPA's analysis shows no significant pathways, likely due to the small number of markers after filtering.\nConsider relaxing the inclusion criteria.")
	return(res)
  }
  if(length(which(!is.na(pb)&!is.na(ph)))==1){
	cat("\nCorrelation can't be calculated for Pbine.")
	return(res)
  }
  r=cor(pb, ph, use="pairwise.complete.obs")
  cat(paste0("\nr = ",r))
  if(is.na(r)) {
	cat("\nIOPA's analysis shows no significant pathways, likely due to the small number of markers after filtering.\nConsider relaxing the inclusion criteria.")
  }else{
	  p_Ibind=integral_method(pb, ph, method = "int", r = r, rel_error=rel_error)
	  p_Ibind_FDR=p.adjust(p_Ibind, "fdr")
	  p_Ibind_fwer=p.adjust(p_Ibind, "bonferroni")
	  phFdr = p.adjust(ph, "fdr")
	  phfwer = p.adjust(ph, "bonferroni")
	  pbFdr = p.adjust(pb, "fdr")
	  pbfwer = p.adjust(pb, "bonferroni")
	  pcombFDR = p.adjust(pcomb, "fdr")
	  pcombfwer = p.adjust(pcomb, "bonferroni")
	  Name = path.names[names(datp)]
	  Status = ifelse(tA > 0, "Activated", "Inhibited")
	  res <- data.frame(Name, ID = names(datp),
						G_size = g_size, deG_n = g_nde, G_pORA = g_ph,
						C_size = c_size, deC_n = c_nde, C_pORA = c_ph,
						P_size = pSize,  deP_n = nGP,   pORA = ph, pORA_Bonf = phfwer, pORA_FDR = phFdr, raw_eSPIA=tAraw,
						eSPIA = tA, eSPIA_nor = tA_normalized, peSPIA = pb, peSPIA_Bonf = pbfwer, peSPIA_FDR = pbFdr,
						
						pFisher = pcomb, pFisher_Bonf = pcombfwer, pFisher_FDR = pcombFDR,
						pPbine = p_Ibind, pPbine_Bonf = p_Ibind_fwer, pPbine_FDR = p_Ibind_FDR, 
						
						Status, KEGGLINK, stringsAsFactors = FALSE)
	  res <- res[order(res$pPbine_FDR, res$pPbine), ]
	  write.table(res, file=table_file_name,sep=",",quote=T,row.name=F)
	  if (plots) {
		load(paste(data.dir,"KEGG_pathway_class.Rdata",sep=""))#p_list
		da = res
		da$ID = as.numeric(da$ID)
		da = da[!is.na(da$pPbine_FDR),]
		da = da[!is.na(match(da$ID,p_list$V3)),]
		#p_list = read.csv(paste(data.dir,"KEGG_pathway_class_20221003.csv",sep=""),header=F)
		
		p_list=p_list[!((p_list$V3=="")|(is.na(p_list$V3))),]
		p_group_upper_index=which(!p_list$V1=="")
		p_group_lower_index=c((p_group_upper_index[-1]-1),nrow(p_list))
		p_group_name=p_list$V1[p_group_upper_index]
		
		group_info=sapply(match(da$ID,p_list$V3),function(x) which((x>=p_group_upper_index)&(x<=p_group_lower_index)))
		
		Figpath=output_dir
		COLOR_12=c("red","#9c5902","#B2B200","#59B200","#245e22","blue",     
				   "#00B2B2","#ff9a26","#171ee6","#5900B2","#d431a3","#B20059" )
		p_range_FDR=-log10(da$pPbine_FDR)
		ylim_FDR=ceiling(max(p_range_FDR[!p_range_FDR==Inf],na.rm=T))
		p_range_FDR[p_range_FDR==Inf]=ylim_FDR
		
		p_range=-log10(da$pPbine)
		ylim=ceiling(max(p_range[!p_range==Inf],na.rm=T))
		p_range[p_range==Inf]=ylim
		
		add.alpha <- function(col, alpha=1){
		  if(missing(col)) stop("Please provide a vector of colours.")
		  apply(sapply(col, col2rgb)/255, 2, 
				function(x) rgb(x[1], x[2], x[3], alpha=alpha))  
		}
		
		roundrect=function (x = 0.5, y = 0.5, width = 1, height = 1, p=0.05,border="white",col="red",lwd=2,n=100,plot_w=NULL,plot_h=NULL){
		  tmp3 <- cnvrt.coords( c(1,0), c(1,0), input='fig')
		  if(is.null(plot_w)) plot_w=tmp3$usr$x[1]-tmp3$usr$x[2]
		  if(is.null(plot_h)) plot_h=tmp3$usr$y[1]-tmp3$usr$y[2]
		  graph_multi=2.4 #graph_w/praph_h
		  hw=width/2
		  hh=height/2
		  multi=1/plot_h*plot_w
		  gap_x=height*p*multi/graph_multi
		  gap_y=height*p
		  c1_x=x+hw-gap_x+gap_x*cos(seq(0,90,length.out=n)/180*pi)
		  c1_y=y+hh-gap_y+gap_y*sin(seq(0,90,length.out=n)/180*pi)
		  c2_x=x-hw+gap_x+gap_x*cos(seq(90,180,length.out=n)/180*pi)
		  c2_y=y+hh-gap_y+gap_y*sin(seq(90,180,length.out=n)/180*pi)
		  c3_x=x-hw+gap_x+gap_x*cos(seq(180,270,length.out=n)/180*pi)
		  c3_y=y-hh+gap_y+gap_y*sin(seq(180,270,length.out=n)/180*pi)
		  c4_x=x+hw-gap_x+gap_x*cos(seq(270,360,length.out=n)/180*pi)
		  c4_y=y-hh+gap_y+gap_y*sin(seq(270,360,length.out=n)/180*pi)
		  polygon(c(c1_x,c2_x,c3_x,c4_x),c(c1_y,c2_y,c3_y,c4_y),col=col,lwd=lwd,border=border)
		}
		
		#graphing
		if(T){#manhattan plot
			man_plot=function(FDR=T, p_range=NULL, ylim=NULL){
			  if(FDR){
				tiff(paste(Figpath,"Pathway analysis_manhattan_pFDR",".tiff", sep=""), width=2400*3, height=1000*3, compression="lzw", res=100*3)
			  }else{
				tiff(paste(Figpath,"Pathway analysis_manhattan",".tiff", sep=""), width=2400*3, height=1000*3, compression="lzw", res=100*3)
			  }
			  par(mar=c(10, 1, 5, 1),xpd=T)
			  CEX=1.5
			  plot(1:nrow(p_list), lwd=10, ylim=c(0,ylim), axes=F, ylab="", xlab="", cex.lab=CEX+0.5, type="n", cex.main=2)
			  tmp3 <- cnvrt.coords( c(0.052), c(0.96,0), input='fig')
			  if(FDR){
				text(tmp3$usr$x[1], y=tmp3$usr$y[1], "-log10(pFDR)", adj=c(0.5,1), col="black", cex=CEX+1) #y axis label
			  }else{
				text(tmp3$usr$x[1], y=tmp3$usr$y[1], "-log10(p)", adj=c(0.5,1), col="black", cex=CEX+1) #y axis label
			  }
			  #background
			  for(i in 1:6){
				#rect(p_group_upper_index[i],0,p_group_lower_index[i],ylim, col=add.alpha(COLOR_12[i*2],alpha=0.3),border="white",lwd=0.5)
				roundrect(x = (p_group_upper_index[i]+p_group_lower_index[i])/2, y = ylim/2, 
						  width = (p_group_lower_index[i]-p_group_upper_index[i]), height = ylim, p=0.03,border="white",col=add.alpha(COLOR_12[i*2],alpha=0.3),
						  lwd=0.5,n=100)
			  }
			  lines(x=c(1,nrow(p_list)),y=c(-log10(0.05),-log10(0.05)),col="red",lty="dashed",lwd=2) # line of FDR threshold
			  for(i in 1:nrow(da)){
				points(match(da$ID[i],p_list$V3),p_range[i],col=COLOR_12[group_info[i]*2],pch=16,cex=1.5)
			  }
			  axis(2,lwd = 2,cex.axis=CEX+1,mgp=c(0,-3,-4)) #y axis
			  
			  # 6 classes legend
			  hori_h=0.27
			  vert_h=0.05
			  n_col=3
			  for(i in 1:length(p_group_name)){
				tmp3 <- cnvrt.coords( c(0.11+((i-1)%%n_col)*hori_h), c(1.025-vert_h-((i-1)%/%n_col)*vert_h,0), input='fig')
				text(tmp3$usr$x[1],tmp3$usr$y[1],p_group_name[i],col=COLOR_12[i*2],cex=2,adj=c(0,1),font=2)###cex=2.1
			  }
			  
			  ## x lab pos adj
			  sel=which(p_range>-log10(0.05))
			  if(length(sel)==0){
				cat("\nNo significant pathway identified by either ORA or eSPIA.")
			  }else{
				  major_mu_yy=match(da$ID[sel],p_list$V3)
				  x_order=order(major_mu_yy)
				  major_mu_yy=major_mu_yy[x_order]
				  ori_major_mu_yy=major_mu_yy
				  ori_center=(max(ori_major_mu_yy)+min(ori_major_mu_yy))/2
				  x_lab=shorten_string(p_list$V5, 25)[match(da$ID[sel],p_list$V3)][x_order]
				  COLOR=COLOR_12[group_info[sel][x_order]*2]
				  y_pvalue=p_range[sel][x_order]
				  if(T){
					min_h=4.5
					max_wid=(max(ori_major_mu_yy)-min(ori_major_mu_yy))*1.01
					if(all((major_mu_yy[-1]-major_mu_yy[-length(major_mu_yy)])>min_h)){	
					}else{
					  while(!all((major_mu_yy[-1]-major_mu_yy[-length(major_mu_yy)])>min_h)){
						sel=(major_mu_yy[-1]-major_mu_yy[-length(major_mu_yy)])<=min_h
						temp=rep(0,length(major_mu_yy))
						temp[c(FALSE,sel)]=0.2
						temp=cumsum(temp)
						major_mu_yy=major_mu_yy+temp
						major_mu_yy=major_mu_yy-((max(major_mu_yy)+min(major_mu_yy))/2-ori_center)
						while((max(major_mu_yy)-min(major_mu_yy))>max_wid){
						  dif=c(0,(major_mu_yy[-1]-major_mu_yy[-length(major_mu_yy)]))
						  off_set=rep(0,length(major_mu_yy))
						  sell=dif>min_h
						  off_set[sell]=-dif[sell]*0.01
						  odd_set=cumsum(off_set)
						  major_mu_yy=major_mu_yy+odd_set
						  major_mu_yy=major_mu_yy-((max(major_mu_yy)+min(major_mu_yy))/2-ori_center)
						}
					  }
					}
				  }
				  
				  tmp3 <- cnvrt.coords( c(0,0), c(0.22,0), input='fig')
				  text(major_mu_yy,tmp3$usr$y[1]-0.02*ylim,x_lab,srt=-60,adj=c(0,0.5),col=COLOR,cex=1.1)
				  temp=sapply(1:length(major_mu_yy),function(x) lines(c(ori_major_mu_yy[x],major_mu_yy[x]),c(0,tmp3$usr$y[1]-0.02*ylim),col=COLOR[x]))
				  temp=sapply(1:length(major_mu_yy),function(x) lines(c(ori_major_mu_yy[x],ori_major_mu_yy[x]),c(0,y_pvalue[x]),col=COLOR[x]))
				  
				  ##y lab pos adj
				  path_lab_cex=1.3
				  wd=max(strwidth(shorten_string(p_list$V5, 25),cex=path_lab_cex))
				  hd=max(strheight(shorten_string(p_list$V5, 25),cex=path_lab_cex))
				  poss_x=match(da$ID[1:p_labels],p_list$V3)
				  poss_y=p_range[1:p_labels]
				  wd=strwidth(shorten_string(p_list$V5[match(da$ID[1],p_list$V3)], 25),cex=path_lab_cex+0.25)
				  hd=strheight(shorten_string(p_list$V5[match(da$ID[1],p_list$V3)], 25),cex=path_lab_cex+0.25)*2
				  if(T){
					finalx=poss_x[1]+wd/2
					finaly=poss_y[1]-hd/2
					final_pos=1
					for(i in 2:10){
					  temp_x=poss_x[i]
					  temp_y=poss_y[i]
					  temp_var_x=0
					  temp_var_y=0
					  temp_final_x=temp_x
					  temp_final_y=temp_y
					  wd=strwidth(shorten_string(p_list$V5[match(da$ID[i],p_list$V3)], 25),cex=path_lab_cex+0.25)
					  hd=strheight(shorten_string(p_list$V5[match(da$ID[i],p_list$V3)], 25),cex=path_lab_cex+0.25)*2
					  for(j in 1:8){
						if(j==1) {
						  if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>0)) {
							temp_var_x=var(c(finalx,temp_x-wd/2))
							temp_final_x=temp_x-wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y+hd/2))) {
							temp_var_y=var(c(finaly,temp_y+hd/2))
							temp_final_y=temp_y+hd/2
						  }
						}
						if(j==3) {
						  if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<nrow(p_list))){ 
							temp_var_x=var(c(finalx,temp_x+wd/2))
							temp_final_x=temp_x+wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y+hd/2))){
							temp_var_y=var(c(finaly,temp_y+hd/2))
							temp_final_y=temp_y+hd/2
						  }
						}
						if(j==4) {
						  if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>0)){
							temp_var_x=var(c(finalx,temp_x-wd/2))
							temp_final_x=temp_x-wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y))){ 
							temp_var_y=var(c(finaly,temp_y))
							temp_final_y=temp_y
						  }
						}
						if(j==5) {
						  if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<nrow(p_list))){ 
							temp_var_x=var(c(finalx,temp_x+wd/2))
							temp_final_x=temp_x+wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y))){ 
							temp_var_y=var(c(finaly,temp_y))
							temp_final_y=temp_y
						  }
						}
						if(j==6) {
						  if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>0)){ 
							temp_var_x=var(c(finalx,temp_x-wd/2))
							temp_final_x=temp_x-wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y-hd/2))){ 
							temp_var_y=var(c(finaly,temp_y-hd/2))
							temp_final_y=temp_y-hd/2
						  }
						}
						if(j==8) {
						  if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<nrow(p_list))){
							temp_var_x=var(c(finalx,temp_x+wd/2))
							temp_final_x=temp_x+wd/2
						  }
						  if(temp_var_y<var(c(finaly,temp_y-hd/2))){ 
							temp_var_y=var(c(finaly,temp_y-hd/2))
							temp_final_y=temp_y-hd/2
						  }
						}
					  }
					  finalx=c(finalx,temp_final_x)
					  finaly=c(finaly,temp_final_y)
					}
				  }
				  
				  text(finalx,finaly,shorten_string(p_list$V5, 25)[match(da$ID[1:10],p_list$V3)],
					   adj=c(0.5,0.5), cex=path_lab_cex, col=COLOR_12[group_info[1:10]*2], font=2)
			  }
			  dev.off()
			}
			man_plot(FDR=T, p_range=p_range_FDR, ylim=ylim_FDR)
			man_plot(FDR=F, p_range=p_range, ylim=ylim)
		}
		
		if(T){#volcano plot
		  Vol_plot=function(normalize = T, label_n = p_labels, p_range=p_range_FDR, ylim=ylim_FDR){
			if(normalize){
			  ta_range=da$eSPIA_nor
			  tiff(paste(Figpath,"Pathway analysis_volcano_normalized",".tiff", sep=""), width=1600*3, height=900*3, compression="lzw", res=100*3)
			  xlabel_text="Normalized eSPIA"
			}else{
			  ta_range=da$eSPIA
			  tiff(paste(Figpath,"Pathway analysis_volcano",".tiff", sep=""), width=1600*3, height=900*3, compression="lzw", res=100*3)
			  xlabel_text="eSPIA"
			}
			par(mar=c(5, 3, 5, 1),xpd=T)
			CEX=1.5
			x_min=floor(min(ta_range,na.rm=T))
			x_max=ceiling(max(ta_range,na.rm=T))
			x_range=c(x_min,x_max)
			
			plot(1:nrow(p_list), lwd=10, ylim=c(0,ylim),xlim=x_range, axes=F, 
				 ylab="", xlab=xlabel_text, cex.lab=CEX+1, type="n", cex.main=2)
			
			tmp3 <- cnvrt.coords( c(0.052), c(0.96,0), input='fig')
			text(tmp3$usr$x[1], y=tmp3$usr$y[1], "-log10(pFDR)", adj=c(0.5,1), col="black", cex=CEX) #y axis label
			
			qt1=quantile(ta_range,0.25,na.rm=T)
			qt3=quantile(ta_range,0.75,na.rm=T)
			
			lines(x=x_range, y=c(-log10(0.05),-log10(0.05)),col="red",lty="dashed",lwd=2) # line of FDR threshold
			lines(x=c(qt1,qt1), y=c(0,ylim),col="red",lty="dashed",lwd=2) # line of ta threshold
			lines(x=c(qt3,qt3), y=c(0,ylim),col="red",lty="dashed",lwd=2) # line of ta threshold
			
			hori_h=c(0,0.20,0.30)
			hori_h=cumsum(hori_h)
			vert_h=0.05
			n_col=3
			
			for(i in 1:length(p_group_name)){
			  tmp3 <- cnvrt.coords( c(0.12+hori_h[((i-1)%%n_col)+1]), c(1.025-vert_h-((i-1)%/%n_col)*vert_h,0), input='fig')
			  text(tmp3$usr$x[1],tmp3$usr$y[1],p_group_name[i],col=COLOR_12[i*2],cex=1.6,adj=c(0,1),font=2)###cex=2.1
			}
			
			#for(i in 1:nrow(da)){
			#  points(ta_range[i],p_range[i],col=COLOR_12[group_info[i]*2],pch=16,cex=1.5)
			#}
			
			##y lab pos adj
			path_lab_cex=1.6
			wd=max(strwidth(shorten_string(p_list$V5, 25),cex=path_lab_cex))
			hd=max(strheight(shorten_string(p_list$V5, 25),cex=path_lab_cex))
			n=label_n
			poss_x=ta_range
			sel=((poss_x>qt3)|(poss_x<(qt1)))&(p_range>-log10(0.05))
			
			if(length(which(sel))<n){
			  sel=which(sel)
			}else{
			  sel=which(sel)[1:n]
			}
			for(i in 1:nrow(da)){
				if(i%in%sel){
					points(ta_range[i],p_range[i],col=COLOR_12[group_info[i]*2],pch=16,cex=1.5)
				}else{
					points(ta_range[i],p_range[i],col=COLOR_12[group_info[i]*2],pch=1,cex=1.5,lwd=2.5)
				}
			}
			if(length(sel)==0){
				#cat("\nNo significant pathway founded")
			}else{
				roundrect(x = (qt1+x_min)/2, y = (-log10(0.05)+ylim)/2, 
					  width = (qt1-x_min), height = (ylim+log10(0.05)), p=0.04,border="white",col=add.alpha("red",alpha=0.2),
					  lwd=0.5,n=100)
				roundrect(x = (qt3+x_max)/2, y = (-log10(0.05)+ylim)/2, 
					  width = (x_max-qt3), height = (ylim+log10(0.05)), p=0.04,border="white",col=add.alpha("red",alpha=0.2),
					  lwd=0.5,n=100)
			
				poss_x=poss_x[sel]
				poss_y=p_range[sel]
				path_name=da$ID[sel]
				path_col=COLOR_12[group_info[sel]*2]
				wd=strwidth(shorten_string(p_list$V5[match(da$ID[1],p_list$V3)], 25),cex=path_lab_cex+0.25)
				hd=strheight(shorten_string(p_list$V5[match(da$ID[1],p_list$V3)], 25),cex=path_lab_cex+0.25)*2
				if(T){
				  finalx=poss_x[1]-wd/2
				  finaly=poss_y[1]-hd/2
				  final_pos=1
				  for(i in 2:length(poss_x)){
					temp_x=poss_x[i]
					temp_y=poss_y[i]
					temp_var_x=0
					temp_var_y=0
					temp_final_x=temp_x
					temp_final_y=temp_y
					wd=strwidth(shorten_string(p_list$V5[match(path_name[i],p_list$V3)], 25),cex=path_lab_cex+0.25)
					hd=strheight(shorten_string(p_list$V5[match(path_name[i],p_list$V3)], 25),cex=path_lab_cex+0.25)*2
					for(j in 1:8){
					  if(j==1) {
						if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>x_min)) {
						  temp_var_x=var(c(finalx,temp_x-wd/2))
						  temp_final_x=temp_x-wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y+hd/2))) {
						  temp_var_y=var(c(finaly,temp_y+hd/2))
						  temp_final_y=temp_y+hd/2
						}
					  }
					  if(j==3) {
						if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<x_max)){ 
						  temp_var_x=var(c(finalx,temp_x+wd/2))
						  temp_final_x=temp_x+wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y+hd/2))){
						  temp_var_y=var(c(finaly,temp_y+hd/2))
						  temp_final_y=temp_y+hd/2
						}
					  }
					  if(j==4) {
						if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>x_min)){
						  temp_var_x=var(c(finalx,temp_x-wd/2))
						  temp_final_x=temp_x-wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y))){ 
						  temp_var_y=var(c(finaly,temp_y))
						  temp_final_y=temp_y
						}
					  }
					  if(j==5) {
						if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<x_max)){ 
						  temp_var_x=var(c(finalx,temp_x+wd/2))
						  temp_final_x=temp_x+wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y))){ 
						  temp_var_y=var(c(finaly,temp_y))
						  temp_final_y=temp_y
						}
					  }
					  if(j==6) {
						if((temp_var_x<var(c(finalx,temp_x-wd/2)))&((temp_x-wd)>x_min)){ 
						  temp_var_x=var(c(finalx,temp_x-wd/2))
						  temp_final_x=temp_x-wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y-hd/2))){ 
						  temp_var_y=var(c(finaly,temp_y-hd/2))
						  temp_final_y=temp_y-hd/2
						}
					  }
					  if(j==8) {
						if((temp_var_x<var(c(finalx,temp_x+wd/2)))&((temp_x+wd/2)<x_max)){
						  temp_var_x=var(c(finalx,temp_x+wd/2))
						  temp_final_x=temp_x+wd/2
						}
						if(temp_var_y<var(c(finaly,temp_y-hd/2))){ 
						  temp_var_y=var(c(finaly,temp_y-hd/2))
						  temp_final_y=temp_y-hd/2
						}
					  }
					}
					finalx=c(finalx,temp_final_x)
					finaly=c(finaly,temp_final_y)
				  }
				}
				
				textplot(c(poss_x,poss_x),c(poss_y,poss_y),
					c(rep("a",length(shorten_string(p_list$V5, 25)[match(path_name,p_list$V3)])),
						shorten_string(p_list$V5, 25)[match(path_name,p_list$V3)]),
					new=FALSE,xlim=x_range,ylim=c(0,ylim),
					show.lines=FALSE,
					cex=path_lab_cex, font=2, col=c(alpha(path_col,0),path_col))
				#text(finalx,finaly,shorten_string(p_list$V5, 25)[match(path_name,p_list$V3)],
				#	adj=c(0.5,0.5), cex=path_lab_cex, col=path_col, font=2)
			}
			axis(2,lwd = 2,cex.axis=CEX+1,mgp=c(3,0,-1))
			axis(1,lwd = 2,cex.axis=CEX+1,mgp=c(0.4,1.5,0.21))
			
			dev.off()
		  }
		  Vol_plot(normalize=TRUE, label_n=p_labels)
		  Vol_plot(normalize=FALSE, label_n=p_labels)
		}
	  }
	  #res <- res[!is.na(res$pORA), ]
	  rownames(res) <- NULL
	  res
  }
}

IOPA <- function(){
  dlg <- tktoplevel(width = 800); if(isIcon) tk2ico.set(dlg,icon)
  tkwm.title(dlg, "Integrative Omics Pathway Analysis")
  
  textIOPAinput <- tclVar("")
  fr_input <- tkframe(dlg)
  textinputWidget <- tkentry(fr_input,width="70", textvariable = textIOPAinput, bg = "white")
  box.input <- tkbutton(fr_input, text = "...",  command = function() tclvalue(textIOPAinput) <- tkgetOpenFile(initialfile = tclvalue(textIOPAinput), filetypes = "{{Text Files} {.txt .csv}}"))
  
  
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  tkgrid(tklabel(fr_input, text="   Input file:              "),textinputWidget, box.input, tklabel(fr_input,text="    "), sticky = "w")
  
  
  
  textIOPAoutput <- tclVar("")
  textouputWidget <- tkentry(fr_input,width="70", textvariable = textIOPAoutput, bg = "white")
  box.output <- tkbutton(fr_input, text = "...",  command = function() tclvalue(textIOPAoutput) <- tkchooseDirectory(initialdir = as.character(tclvalue(textIOPAoutput))))
  tkconfigure(box.output, state = "normal")
  tkgrid(tklabel(fr_input,text="   Output folder:    "), textouputWidget, box.output, tklabel(fr_input,text="    "), sticky = "w")
  
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  tkgrid(fr_input, sticky = "w")
  
  fr_para <- tkframe(dlg)
  tkgrid(tklabel(fr_para, text = "   Parameter setting:"))
  tkgrid(fr_para, sticky = "w")
  
  fr_IC <- tkframe(dlg)
  tkgrid(fr_IC, sticky = "w")
  
  
  
  fr_IC_para <- tkframe(fr_IC)
  tkgrid(fr_IC_para, sticky = "w")
  
  fr_pvfc <- tkframe(fr_IC_para)
  pvfc_choice <- tclVar("1")
  
  pvfc_yes <- tkradiobutton(fr_pvfc, variable = pvfc_choice, value = "1", command = function(...){
    tkconfigure(pvfc1, state = "normal")
    if(tclvalue(pv.val)=="1"){
      tkconfigure(pvstart.entry, state = "normal")
    }else{
      tkconfigure(pvstart.entry, state = "disable")
    }
    tkconfigure(pvfc2, state = "normal")
    if(tclvalue(fc.val)=="1"){
      tkconfigure(fcstart.entry, state = "normal")
      tkconfigure(fcend.entry, state = "normal")
    }else{
      tkconfigure(fcstart.entry, state = "disable")
      tkconfigure(fcend.entry, state = "disable")
    }
  })
  
  pvfc_no <- tkradiobutton(fr_pvfc, variable = pvfc_choice, value = "2", command = function(...){
    tkconfigure(pvfc1, state = "disable")
    tkconfigure(pvstart.entry, state = "disable")
    tkconfigure(pvfc2, state = "disable")
    tkconfigure(fcstart.entry, state = "disable")
    tkconfigure(fcend.entry, state = "disable")
  })
  
  pv.val <- tclVar("1")
  pvfc1 <- tkcheckbutton(fr_pvfc, variable = pv.val, command = function(...){
    if(tclvalue(pv.val)=="1"){
      tclvalue(pvfc_choice) = 1
      tkconfigure(pvstart.entry, state = "normal")
    }else{
      tkconfigure(pvstart.entry, state = "disable")
    }
  })
  pvstart <- tclVar("0.05")
  pvstart.entry <- tkentry(fr_pvfc, width = 5, textvariable = pvstart, bg = "white")
  
  fc.val <- tclVar("0")
  pvfc2 <- tkcheckbutton(fr_pvfc, variable = fc.val, command = function(...){
    if(tclvalue(fc.val)=="1"){
      tclvalue(pvfc_choice) = 1
      tkconfigure(fcstart.entry, state = "normal")
      tkconfigure(fcend.entry, state = "normal")
    }else{
      tkconfigure(fcstart.entry, state = "disable")
      tkconfigure(fcend.entry, state = "disable")
    }
  })
  
  fcstart <- tclVar("-0.005")
  fcstart.entry <- tkentry(fr_pvfc, width = 5, textvariable = fcstart, bg = "white")
  fcend <- tclVar("0.005")
  fcend.entry <- tkentry(fr_pvfc, width = 5, textvariable = fcend, bg = "white")
  tkconfigure(fcstart.entry, state = "disable")
  tkconfigure(fcend.entry, state = "disable")
  
  tkgrid(tklabel(fr_pvfc, text = "         Inclusion criteria: "), pvfc_yes, tklabel(fr_pvfc, text = "Yes "),tklabel(fr_pvfc, text = "("), pvfc1, tklabel(fr_pvfc, text = "p-value < "), pvstart.entry, tklabel(fr_pvfc, text = "(0~1) and"),  tklabel(fr_pvfc, text = " "), pvfc2,  fcstart.entry, tklabel(fr_pvfc, text = "<= logFC <="), fcend.entry,tklabel(fr_pvfc, text = ")"))
  
  
  tkgrid(tklabel(fr_pvfc, text = "   "), pvfc_no, tklabel(fr_pvfc, text = "No"))
  tkgrid(fr_pvfc, sticky = "w")
  
  fr_rel_err <- tkframe(fr_IC_para)
  rel_errthr <- tclVar("1e-10")
  rel_errthr.entry <- tkentry(fr_rel_err, width = 5, textvariable = rel_errthr, bg = "white")
  tkgrid(tklabel(fr_rel_err, text = "         Pbine:   Relative accuracy <= "), rel_errthr.entry)
  
  tkgrid(fr_rel_err, sticky = "w")
  
  onOK <- function(){
    tkdestroy(dlg)
    
    outpath = paste(tclvalue(textIOPAoutput), "/IOPA", sep = "")
    dir.create(outpath, showWarnings = F)
    
    All_G_M <- read.csv(tclvalue(textIOPAinput))
    All_G_M_new=All_G_M[!is.na(All_G_M$ID),]
    All_G_M_new=aggregate_data(All_G_M_new)
    
    IPA_0005_005 <- spia_mod(All_G_M_new, log_FC_cutoff_l = as.numeric(tclvalue(fcstart)), log_FC_cutoff_u = as.numeric(tclvalue(fcend)), P_cutoff = as.numeric(tclvalue(pvstart)),
                             p_labels = 10, rel_error = as.numeric(tclvalue(rel_errthr)),
                             data.dir = paste0(getwd(),"/"),
                             data_name="hsaSPIA_reversible(cumulative_sum)",
                             output_dir=paste0(outpath,"/"),
							 table_file_name=paste0(outpath,"/IOPA_fcl",gsub(".","",as.numeric(tclvalue(fcstart))),"_fcu",gsub(".","",as.numeric(tclvalue(fcend))),"_pv",gsub(".","",as.numeric(tclvalue(pvstart))),"err",as.numeric(tclvalue(rel_errthr)),".csv")
    )
    
    #write.table(IPA_0005_005,file=table_file_name,sep=",",quote=T,row.name=F)
    
    tkmessageBox(title = "Peak Alignment and Annotation", message = "Statistical Analysis - Integrative Omics Pathway Analysis is done.", icon = "info", type = "ok")
    cat("Statistical Analysis - Integrative Omics Pathway Analysis is done.\n")
    
  }
  
  
  onCancel <- function()
  {
    
    
    tkdestroy(dlg)
    tkfocus(tt)
  }
  
  tkgrid(tklabel(dlg, text = ""))
  fr <- tkframe(dlg)
  OK.but     <-tkbutton(fr,text="    Run    ",command=onOK)
  Cancel.but <-tkbutton(fr,text="   Cancel   ",command=onCancel)
  tkgrid(tklabel(fr,text="               "), OK.but,tklabel(fr,text="                                      "), Cancel.but, tklabel(fr,text="               "))
  tkgrid(fr)
  tkgrid(tklabel(dlg, text = "", height = 0, font = fontIntro_para))
  
  tkfocus(dlg)
  tkbind(dlg, "<Destroy>", function() {tkgrab.release(dlg);tkfocus(tt)})
  
  
  tkwait.window(dlg)
}








