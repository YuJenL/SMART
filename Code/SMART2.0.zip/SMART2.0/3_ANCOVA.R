ANCOVA <- function(){
  dlg <- tktoplevel(); if(isIcon) tk2ico.set(dlg,icon)
  tkwm.title(dlg, "Analysis of Covariance (ANCOVA)")
  
  fr_input <- tkframe(dlg)
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  tkgrid(tklabel(fr_input, text = paste("Input file: ", tclvalue(textAbuninput), "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
  tkgrid(tklabel(fr_input, text = paste("Output folder: ", tclvalue(textoutput), "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
  
  tkgrid(tklabel(fr_input, text = ""))
  fr_input.1 <- tkframe(fr_input)
  tkgrid(fr_input.1, sticky = "w")
  if(!exists("textCovaInput")) textCovaInput <<- tclVar("")
  textCovaInputWidget <- tkentry(fr_input.1,width="60", textvariable = textCovaInput, bg = "white")
  box.cova <- tkbutton(fr_input.1, text = "...",  command = function() tclvalue(textCovaInput) <- tkgetOpenFile(initialfile = as.character(tclvalue(textCovaInput)), filetypes = "{{Text Files} {.txt .csv}}"))
  cova_label <- tklabel(fr_input.1,text="   Covariates file (optional):       ")
  tk2tip(cova_label, "confounding variable")
  tkgrid(cova_label, textCovaInputWidget, box.cova, tklabel(fr_input.1,text="    "), sticky = "w")
  
  if(!exists("textBatchInput")) textBatchInput <<- tclVar("")
  textbatchWidget <- tkentry(fr_input.1,width="60", textvariable = textBatchInput, bg = "white")
  box.batch <- tkbutton(fr_input.1, text = "...",  command = function() tclvalue(textBatchInput) <- tkgetOpenFile(initialfile = as.character(tclvalue(textBatchInput)), filetypes = "{{Text Files} {.txt .csv}}"))
  batch_label <- tklabel(fr_input.1,text="   Batch effects file (optional):      ")
  tk2tip(batch_label, "from Batch Effect Detection")
  tkgrid(batch_label, textbatchWidget, box.batch, tklabel(fr_input.1,text="    "), sticky = "w")
  
  if(!exists("textFactorInput")) textFactorInput <<- tclVar("")
  textFactorWidget <- tkentry(fr_input.1,width="60", textvariable = textFactorInput, bg = "white")
  box.factor <- tkbutton(fr_input.1, text = "...",  command = function() tclvalue(textFactorInput) <- tkgetOpenFile(initialfile = as.character(tclvalue(textFactorInput)), filetypes = "{{Text Files} {.txt .csv}}"))
  fac_label <- tklabel(fr_input.1,text="   Factor file (required): ")
  tk2tip(fac_label, "variable of interest")
  tkgrid(fac_label, textFactorWidget, box.factor, tklabel(fr_input.1,text="    "), sticky = "w")
  
  textctrl <- tclVar("")
  tkgrid(tklabel(fr_input.1,text="   Label for the control group:    "), tkentry(fr_input.1,width="9", textvariable = textctrl, bg = "white"), tklabel(fr_input.1,text="    "), sticky = "w")
  
  tkgrid(tklabel(fr_input, text = ""))
  fr_input.2 <- tkframe(fr_input)
  fr_input.2.1 <- tkframe(fr_input.2)
  fr_input.2.2 <- tkframe(fr_input.2, relief="ridge", borderwidth=2)
  tkgrid(fr_input.2, sticky = "w")
  tkgrid(fr_input.2.1, fr_input.2.2, sticky = "w")
  
  tkgrid(fr_input.2.1, sticky = "w")
  permute.val <- tclVar(0)
  permute.check <- tkcheckbutton(fr_input.2.1, variable = permute.val, command = function(){
    if(tclvalue(permute.val) == "1"){
      tkconfigure(permutetime.entry, state = "normal")
      tkconfigure(permutecut.entry, state = "normal")
      tkconfigure(permutetime.label, state = "normal")
      tkconfigure(permutecut.label, state = "normal")
      tkconfigure(textcpuWidget, state = "normal")
      tkconfigure(labelcpu, state = "normal")
      tkmessageBox(title = "Warning", message = "Permutation test is time-consuming.", icon = "warning", type = "ok")
      cat("ANCOVA (Warning) - Permutation test is time-consuming.\n")
    }else{
      tkconfigure(permutetime.entry, state = "disable")
      tkconfigure(permutecut.entry, state = "disable")
      tkconfigure(permutetime.label, state = "disable")
      tkconfigure(permutecut.label, state = "disable")
      tkconfigure(textcpuWidget, state = "disabled")
      tkconfigure(labelcpu, state = "disable")
    }
  })
  
  permute.label <- tklabel(fr_input.2.1, text = "Run permutation test:")
  
  permutetime.label <- tklabel(fr_input.2.2, text = " Number of permutations:")
  permute.times <- tclVar(10000)
  permutetime.entry <- tkentry(fr_input.2.2, width = 9, textvariable = permute.times, validatecommand = "string is integer %P", validate = "all", bg = "white")
  
  permutecut.label <- tklabel(fr_input.2.2, text = " Cut-off of nominal p-value: ")
  permutecut.val <- tclVar(0.05)
  permutecut.entry <- tkentry(fr_input.2.2, width = 5, textvariable = permutecut.val, validatecommand = "string is double %P", validate = "all", bg = "white")
  
  labelcpu <- tklabel(fr_input.2.2, text = " Number of cores: ")
  tk2tip(labelcpu, "number of cores to be used for permutation test.")
  textcpu <- tclVar(1)
  textcpuWidget <- ttkcombobox(fr_input.2.2, state = "readonly", values = 1:as.numeric(Sys.getenv('NUMBER_OF_PROCESSORS')), width = 4, textvariable = textcpu)
  
  tkgrid(tklabel(fr_input.2.1,text=" "), permute.check, permute.label, sticky = "w")
  tkgrid(tklabel(fr_input.2.1,text=" "), sticky = "w")
  tkgrid(tklabel(fr_input.2.1,text=" "), sticky = "w")
  tkgrid(tklabel(fr_input.2.2,text=" "), permutetime.label, permutetime.entry, sticky = "w")
  tkgrid(tklabel(fr_input.2.2,text=" "), permutecut.label, permutecut.entry, tklabel(fr_input.2.2,text=" "), sticky = "w")
  tkgrid(tklabel(fr_input.2.2,text=" "), labelcpu, textcpuWidget, sticky  = "w")
  
  tkconfigure(permutetime.entry, state = "disable")
  tkconfigure(permutecut.entry, state = "disable")
  tkconfigure(permutetime.label, state = "disable")
  tkconfigure(permutecut.label, state = "disable")
  tkconfigure(textcpuWidget, state = "disabled")
  tkconfigure(labelcpu, state = "disable")
  
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  tkgrid(fr_input, sticky = "w")
  
  onOK <- function(){
    check_file_exists <- setNames(c(file.exists(tclvalue(textFactorInput)), tclvalue(textBatchInput)==""|file.exists(tclvalue(textBatchInput)), tclvalue(textCovaInput)==""|file.exists(tclvalue(textCovaInput))), c("Factor", "Batch effect", "Covariates"))
    if(all(check_file_exists)){
      tkconfigure(dlg, cursor = "watch")
      outpath <- paste(tclvalue(textoutput), "/ANCOVA", sep = ""); dir.create(outpath, showWarnings = F)
      
      ctrl_label <- tclvalue(textctrl)
      ncpu <- as.numeric(tclvalue(textcpu))
      tkconfigure(dlg, cursor = "arrow")
      
      check_file_exists <- setNames(file.exists(c(tclvalue(textFactorInput), tclvalue(textBatchInput), tclvalue(textCovaInput))), c("factor", "batch effect", "covariates"))
      batch_effect <- Covariate <- NULL
      
      
      peakabun <- read.table(tclvalue(textAbuninput), header = T, fill = T, sep = ifelse(grepl(".txt", tclvalue(textAbuninput)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))), quote = "\"")  
      peak_index <- peakabun[,c(1:3)]
      peakabun <- peakabun[,-c(1:3)]
      colnames(peakabun) <- gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", colnames(peakabun))
      
      check_rep <- any(table(gsub("_.*", "", colnames(peakabun)[-(1:3)]))>1) 
      check_id_match <- setNames(rep(TRUE, 3), c("factor", "batch effect", "covariates"))
      
      
      Factor <- read.table(tclvalue(textFactorInput), header = T, sep = ifelse(grepl(".txt", tclvalue(textFactorInput)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))), quote = "\"", row.names=1)  
      rownames(Factor) <- gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", rownames(Factor))
      
      check_id_match[1] <- !anyNA(match(gsub("_[0-9]", "", colnames(peakabun)), rownames(Factor)))
      
      
      if(check_file_exists[2]){
        batch_effect <- read.table(tclvalue(textBatchInput), header = T, sep = ifelse(grepl(".txt", tclvalue(textBatchInput)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))), quote = "\"", row.names=1)
        rownames(batch_effect) <- gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", rownames(batch_effect))
        
        check_id_match[2] <- !anyNA(match(colnames(peakabun), rownames(batch_effect)))
      }
      
      
      if(check_file_exists[3]){
        Covariate <- read.table(tclvalue(textCovaInput), header = T, quote = "\"", fill = T, sep = ifelse(grepl(".txt", tclvalue(textCovaInput)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))),row.names=1)  
        cova_type <- colnames(Covariate)
        cova_type <- toupper(substring(cova_type, 1, 1))
        rownames(Covariate) <- gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", rownames(Covariate))
        
        check_id_match[3] <- !anyNA(match(gsub("_[0-9]", "", colnames(peakabun)), rownames(Covariate)))
      }
      
      
      if(all(check_id_match)){
        tkdestroy(dlg)
        tkconfigure(tt,cursor="watch")
        
        peakabun <- t(peakabun)
        
        DInd <- gsub("_.*", "", rownames(peakabun))
        DRep <- gsub("(.*?)_(.*?)", "\\2", rownames(peakabun))
        
        Factor <- Factor[match(gsub("_[0-9]", "", rownames(peakabun)), rownames(Factor)), , drop=FALSE]
        if(ctrl_label!=""){ 
          Factor[,1] <- factor(Factor[,1])
          Factor_label <- setdiff(levels(Factor[,1]), ctrl_label)
        } else { 
          Factor_label <- colnames(Factor)
        }
        
        if(check_file_exists[2]){
          batch_effect <- batch_effect[match(rownames(peakabun), rownames(batch_effect)), , drop=FALSE]
          if(grepl("latent_group_", tclvalue(textBatchInput))) batch_effect[,1] <- factor(batch_effect[,1])
        }
        
        if(check_file_exists[3]){
          Covariate <- Covariate[match(gsub("_[0-9]", "", rownames(peakabun)), rownames(Covariate)), , drop=FALSE]
          for(x in 1:ncol(Covariate)){
            if(cova_type[x]=="D"){
              Covariate[,x] <- factor(Covariate[,x])
            }
          }
          colnames(Covariate) <- substring(colnames(Covariate), 2, nchar(colnames(Covariate)))
        }
        
        assign("peakabun", peakabun, envir = .GlobalEnv)
        assign("Factor", Factor, envir = .GlobalEnv)
        assign("batch_effect", batch_effect, envir = .GlobalEnv)
        assign("Covariate", Covariate, envir = .GlobalEnv)
        
        
        
        VIF_table <<- NULL
        vif_next <<- cov_next <<- mod_next <<- FALSE
        if(check_file_exists[2]){
          vif_check <- tktoplevel(); if(isIcon) tk2ico.set(vif_check,icon)
          tkwm.title(vif_check, "Analysis of Covariance - Variance Inflation Factor (VIF)")
          tkgrid(fr_head <- tkframe(vif_check))
          tkgrid(tklabel(fr_head, text = paste("Collinearity Check - VIF", sep = ""), font = fontHeading))
          tkgrid(fr_vif <- tkframe(vif_check))
          
          tclarray <- tclArray()
          VIF_table <- c(ifelse(ctrl_label!="", "Group_comparison", "Quantitative_trait") , "Batch_effect", ifelse(ctrl_label!="", "Group", "Quan"), colnames(Covariate))
          
          for(grp in Factor_label){
            case_idx <- if(ctrl_label!="") which(Factor[,1] %in% c(grp, ctrl_label)) else 1:nrow(Factor)
            
            tmpData <- if(check_file_exists[3]) cbind(Factor[case_idx, 1, drop=FALSE], Covariate[case_idx, , drop=FALSE])
            else Factor[case_idx, 1, drop=FALSE]
            
            tmp <- t(sapply(1:ncol(batch_effect),function(x){
              sapply(1:ncol(tmpData),function(y){
                tmp <- vif(lm(peakabun[case_idx, 1] ~ tmpData[, y] + batch_effect[case_idx, x]))
                ifelse(class(tmp)=="matrix", round(tmp[2,3], 1), round(tmp[2], 1))
              })
            })) 
            
            VIF_table <- rbind(VIF_table, cbind(ifelse(ctrl_label!="",paste0(grp, "vs.", ctrl_label), grp), colnames(batch_effect), tmp))
          }
          
          for (i in (1:nrow(VIF_table)))
            for (j in (1:ncol(VIF_table)))
              tclarray[[i-1,j-1]] <- as.tclObj(VIF_table[i,j], drop=T)
          vscr <- tkscrollbar(fr_vif, repeatinterval = 20, orient="vertical", command = function(...) tkyview(table1,...))
          hscr <- tkscrollbar(fr_vif, repeatinterval = 1, orient="horizontal", command = function(...) tkxview(table1,...))
          table1 <- tkwidget(fr_vif,"table",variable=tclarray,rows=nrow(VIF_table),cols=ncol(VIF_table),titlerows=1,titlecols = 2, selectmode="extended",colwidth=20,background="white", yscrollcommand=function(...) tkset(vscr, ...), xscrollcommand = function(...) tkset(hscr, ...))
          tkgrid(table1, vscr); tkgrid.configure(vscr, sticky="nsw")
          tkgrid(hscr, sticky="new")
          tkconfigure(table1,selectmode="extended",rowseparator="\"\n\"",colseparator="\"\t\"")
          tkconfigure(table1,resizeborders="none", state = "disable")
          
          tkgrid(fr_vif2 <- tkframe(vif_check), sticky = "w")
          tkgrid(tklabel(fr_vif2, text = "", height = 0, font = fontIntro_para))
          vif_threshold <- tclVar("10")
          tkgrid(tklabel(fr_vif2,text="       The VIF upper bound:    "), tkentry(fr_vif2, width="7", textvariable = vif_threshold, bg = "white"), sticky = "w")
          
          tkgrid(fr_next <- tkframe(vif_check))
          tkgrid(tkbutton(fr_next, text = "  Next  ", command = function(...){
            tkdestroy(vif_check)
            tkconfigure(tt,cursor="watch")
            
            vif_threshold <- as.numeric(tclvalue(vif_threshold))
            write.table(VIF_table, file = paste(outpath, "/VIF_threshold_", vif_threshold, ".csv", sep = ""), sep = ",", col.names = F, row.names = F, quote = F)
            
            VIF_table <<- matrix(as.numeric(VIF_table[-1,-(1:2)]), nrow = nrow(VIF_table)-1, ncol = ncol(VIF_table)-2, dimnames = list(gsub(paste0("vs.",ctrl_label), "", VIF_table[-1, 1]), VIF_table[1, -(1:2)]))
            VIF_table <<- (VIF_table <= vif_threshold)*1
            
            assign("VIF_table", VIF_table, envir = .GlobalEnv)
            vif_next <<- TRUE
          }))
          tkgrid(tklabel(vif_check, text = ""))
          tkwait.window(vif_check)
        } else {
          vif_next <<- TRUE
        }
        
        
        ancova_cov <<- matrix(0, 1, length(Factor_label), dimnames = list(NULL, Factor_label))
        ancova_cov_idx <<- NULL
        cov_next <<- mod_next <<- FALSE
        if(check_file_exists[3] & vif_next){
          ancova_cov <- outer(colnames(Covariate), Factor_label, function(x, y) sprintf("%s (%s%s)", x, y, ifelse(ctrl_label!="", paste(" vs.",ctrl_label), "")))
          dimnames(ancova_cov) <- list(colnames(Covariate), Factor_label)
          ancova_var_idx <<- 1:length(ancova_cov)
          
          cova_select <- tktoplevel(); if(isIcon) tk2ico.set(cova_select,icon)
          tkwm.title(cova_select, "Analysis of Covariance - Covariate Selection")
          choose_frame <- tkframe(cova_select)
          var_frame <- tkframe(choose_frame)
          var_vscr <- tkscrollbar(var_frame, repeatinterval = 5, orient="vertical", command = function(...) tkyview(var_tl,...))
          var_hscr <- tkscrollbar(var_frame, repeatinterval = 1, orient="horizontal", command = function(...) tkxview(var_tl,...))
          var_tl <- tklistbox(var_frame, height = 15, selectmode = "extended", xscrollcommand = function(...) tkset(var_hscr,...), yscrollcommand = function(...) tkset(var_vscr,...), background = "white")
          tkgrid(tklabel(var_frame, text = "Variable"))
          tkgrid(var_tl, var_vscr)
          tkgrid(var_hscr, sticky="new")
          tkgrid.configure(var_vscr, rowspan = 4, sticky = "nsw")
          for(x in ancova_var_idx){
            tkinsert(var_tl, "end", ancova_cov[x])
          }
          cova_frame <- tkframe(choose_frame)
          cova_vscr <- tkscrollbar(cova_frame, repeatinterval = 5, orient="vertical", command = function(...) tkyview(cova_tl,...))
          cova_hscr <- tkscrollbar(cova_frame, repeatinterval = 1, orient="horizontal", command = function(...) tkxview(cova_tl,...))
          cova_tl <- tklistbox(cova_frame, height = 15, selectmode = "extended", xscrollcommand = function(...) tkset(cova_hscr, ...), yscrollcommand = function(...) tkset(cova_vscr, ...), background = "white")
          tkgrid(tklabel(cova_frame, text = "Covariate"))
          tkgrid(cova_tl, cova_vscr)
          tkgrid(cova_hscr, sticky="new")
          tkgrid.configure(cova_vscr, rowspan = 4, sticky = "nsw")
          in_out <- tkframe(choose_frame)
          tkpack(tkbutton(in_out, text = "  >>  ", command = function(...){
            if(length(as.integer(tkcurselection(var_tl)))!=0){
              varIndex <- as.integer(tkcurselection(var_tl))
              for(x in 1:length(varIndex)){
                tkdelete(var_tl, varIndex[x]-x+1)
              }
              ancova_cov_idx <<- sort(c(ancova_cov_idx, ancova_var_idx[varIndex+1]))
              for(x in varIndex){
                tkinsert(cova_tl, which(ancova_cov_idx==ancova_var_idx[x+1])-1, ancova_cov[ancova_var_idx[x+1]])
              }
              ancova_var_idx <<- ancova_var_idx[-(varIndex+1)]
            }
            
          }))
          tkpack(tklabel(in_out, text = "     "))
          tkpack(tkbutton(in_out, text = "  <<  ", command = function(...){
            if(length(as.integer(tkcurselection(cova_tl)))!=0){
              covIndex <- as.integer(tkcurselection(cova_tl))
              for(x in 1:length(covIndex)){
                tkdelete(cova_tl, covIndex[x]-x+1)
              }
              ancova_var_idx <<- sort(c(ancova_var_idx, ancova_cov_idx[covIndex+1]))
              for(x in covIndex){
                tkinsert(var_tl, which(ancova_var_idx==ancova_cov_idx[x+1])-1, ancova_cov[ancova_cov_idx[x+1]])
              }
              ancova_cov_idx <<- ancova_cov_idx[-(covIndex+1)]
            }
            
          }))
          
          tkgrid(var_frame, in_out, cova_frame, padx = 10)
          tkgrid(tklabel(choose_frame, text = "", height = 0, font = fontIntro_para))
          tkgrid(choose_frame)
          
          tkgrid(fr_next <- tkframe(cova_select))
          tkgrid(but.covSel <- tkbutton(fr_next, text = "  Next  ", state="normal", command = function(...){
            
            tkdestroy(cova_select)
            tkconfigure(tt,cursor="watch")
            if(sum(ancova_cov_idx)){
              ancova_cov[-ancova_cov_idx] <<- 0
              ancova_cov[ancova_cov_idx] <<- 1
            } else {
              ancova_cov[,] <<- 0
            }
            write.table(cbind(c("Cov", rownames(ancova_cov)), rbind(colnames(ancova_cov), ancova_cov)), file = paste(outpath, "/covariate_select.csv", sep = ""), sep = ",", col.names = F, row.names = F, quote = F)
            
            assign("ancova_cov", ancova_cov, envir = .GlobalEnv)
            cov_next <<- TRUE
          }))
          tkgrid(tklabel(cova_select, text = ""))
          tkwait.window(cova_select)
        } else {
          cov_next <<- TRUE
        }
        
        
        if(vif_next & cov_next){
          mod_next <<- FALSE
          mod.x <<- setNames(vector('list', length(Factor_label)), Factor_label) 
          mod.f <<- setNames(vector('list', length(Factor_label)), Factor_label) 
          for(grp in Factor_label){
            mod.x[[grp]] <<- list(b = NULL, c = NULL)
            if(check_file_exists[3]) mod.x[[grp]][["c"]] <<- rownames(ancova_cov)[ancova_cov[, grp]==1]
            if(check_file_exists[2]) mod.x[[grp]][["b"]] <<- colnames(batch_effect)[apply(VIF_table[rownames(VIF_table)%in%grp, c(ifelse(ctrl_label!="", "Group", "Quan"), mod.x[[grp]][["c"]]), drop = FALSE], 1, function(x) all(x==1))]
          }
          assign("mod.x", mod.x, envir = .GlobalEnv)
          
          nested_ancova <- tktoplevel(); if(isIcon) tk2ico.set(nested_ancova,icon)
          tkwm.title(nested_ancova, "Analysis of Covariance - Model")
          tkgrid(fr_head <- tkframe(nested_ancova), sticky = "w")
          tkgrid(tklabel(fr_head, text = "Please input an ANCOVA model."))
          tkgrid(fr_input <- tkframe(nested_ancova), sticky = "w")
          
          tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
          traitname <- ifelse(ctrl_label!="", "Group", "Quan")
          for(grp in Factor_label){
            tkgrid(fr_input.1 <- tkframe(nested_ancova), sticky = "w")
            tkgrid(fr_input.2 <- tkframe(nested_ancova), sticky = "w")
            tkgrid(tklabel(fr_input.1, text = sprintf("  Candidate predictors: %s%s%s%s", traitname, ifelse(check_rep, ", Rep", ""), ifelse(length(mod.x[[grp]][["b"]])!=0, sprintf(", Batch effect (%s)", paste(mod.x[[grp]][["b"]], collapse=", ")), ""), ifelse(length(mod.x[[grp]][["c"]])!=0, sprintf(", Covariates (%s)", paste(mod.x[[grp]][["c"]], collapse=", ")), ""))))
            
            assign(paste0("f_", grp), tkentry(fr_input.2, width = "80", textvariable = tclVar(ifelse(check_rep, paste(traitname, "Rep", sep=":"), "")), bg = "white", state = ifelse(length(mod.x[[grp]][["c"]])!=0 | check_rep, "normal", "disable")))
            tkgrid(tklabel(fr_input.2, text = sprintf("    %s%s%s: %s %s", grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label, traitname, ifelse(length(mod.x[[grp]][["b"]])!=0, "+ Batch effect + ", "+ "))), get(paste0("f_", grp)))
          }
          
          tkgrid(tklabel(nested_ancova, text = "", height = 0, font = fontIntro_para))
          tkgrid(fr_note <- tkframe(nested_ancova), sticky = "w")
          tkgrid(tklabel(fr_note, text = "", height = 0, font = fontIntro_para))
          tkgrid(tklabel(fr_note, text = "     Note: Notation ''A:B'' indicates that variable B nested in variable A.", justify = "left"))
          tkgrid(tklabel(fr_note, text = "     "))
          tkgrid(tkbutton(nested_ancova, text = "  Next  ", command = function(...){
            for(grp in Factor_label){
              mod.f[[grp]] <- gsub("\\+$", "", gsub("\\+{2,}", "\\+", paste(traitname, paste(mod.x[[grp]][["b"]], collapse = "+"), tclvalue(tkget(get(paste0("f_", grp)))), sep = "+")))
            }
            assign("mod.f", mod.f, envir = .GlobalEnv)
            mod_next <<- TRUE
            
            tkdestroy(nested_ancova)
            tkconfigure(tt,cursor="watch")
          }))
          tkgrid(tklabel(nested_ancova, text = ""))
          tkwait.window(nested_ancova)
        }
        
        if(mod_next){
          prg_all <- 0
          pb <- tkProgressBar("ANCOVA - Please wait for ANCOVA processing", "0% done", 0, 100, 0, width = 500)
          cat("ANCOVA - Please wait for ANCOVA processing 0 ")
          for(grp in Factor_label){
            fa <- which(Factor_label%in%grp)
            case_idx <- if(ctrl_label!="") which(Factor[,1] %in% c(grp, ctrl_label)) else 1:nrow(Factor)
            
            temp_fac <- Factor[case_idx, ifelse(ctrl_label!="", 1, grp)]
            temp_all <- if(check_file_exists[2] & check_file_exists[3]) data.frame(Covariate[case_idx, , drop = FALSE], batch_effect[case_idx, , drop = FALSE], Rep = DRep[case_idx])
            else if (check_file_exists[2] & !check_file_exists[3]) data.frame(batch_effect[case_idx, , drop = FALSE], Rep = DRep[case_idx])
            else if (!check_file_exists[2] & check_file_exists[3]) data.frame(Covariate[case_idx, , drop = FALSE], Rep = DRep[case_idx])
            else data.frame(Rep = DRep[case_idx])
            
            options(contrasts = c("contr.helmert", "contr.poly"))
            ancova <- apply(peakabun[case_idx,], 2, function(x){
              try(aov(as.formula(sprintf("x ~ %s", gsub("Group|Quan", "temp_fac", mod.f[[grp]]))), data = temp_all), silent=T)
              
            })
            
            ancova.p <- sapply(ancova, function(x){
              tmp <- if(is(x, "aov")) try(Anova(x, type = "III", singular.ok = T)[, "Pr(>F)"], silent = T)
              
              if(!is.numeric(tmp)) tmp <- NA
              
              tmp
            })
            ancova.p <- switch(as.character(inherits(ancova.p, c("list"))), "FALSE" = t(ancova.p), "TRUE" = do.call("rbind", ancova.p))
            
            colnames(ancova.p) <- c("(Intercept)", gsub("temp_fac", sprintf("%s%s%s", grp, ifelse(ctrl_label!="", "_", ""), ctrl_label), colnames(attributes(ancova[[which.min(!is.na(ancova.p[, 1]))]]$terms)$factors)), "")
            
            options(contrasts = c("contr.SAS", "contr.poly"))
            if(ctrl_label!="") contrasts(temp_fac) = contrasts(temp_fac)[c(which(levels(temp_fac)!=ctrl_label), which(levels(temp_fac)==ctrl_label)),]
            reg <- apply(peakabun[case_idx,], 2, function(x){
              try(lm(as.formula(sprintf("x ~ %s", gsub("Group|Quan", "1", mod.f[[grp]]))), data = temp_all, na.action = na.exclude), silent=T)
              
              
            })
            prg_grp <- round(100*1/3)
            prg_all <- round(100*(fa-1)/length(Factor_label) + prg_grp/length(Factor_label))
            setTkProgressBar(pb, value = prg_all, sprintf("ANCOVA - Please wait for ANCOVA processing (%d%% done)", prg_all), sprintf("%s%s%s %d%%", grp, ifelse(ctrl_label!="", " - ", ""), ctrl_label, prg_grp))
            
            
            reg.b <- sapply(reg, function(x){
              if(is(x, "lm")) x$coefficients else NA
            })
            reg.b <- switch(as.character(inherits(reg.b, c("list"))), "FALSE" = t(reg.b), "TRUE" = do.call("rbind", reg.b))
            
            reg.r <- sapply(reg, function(x){
              if(is(x, "lm")) resid(x, na.action = na.exclude) else NA
            })
            reg.r <- switch(as.character(inherits(reg.r, c("list"))), "FALSE" = t(reg.r), "TRUE" = do.call("rbind", reg.r))
            
            
            prg_grp <- round(100*2/3)
            prg_all <- round(100*(fa-1)/length(Factor_label) + prg_grp/length(Factor_label))
            setTkProgressBar(pb, value = prg_all, sprintf("ANCOVA - Please wait for ANCOVA processing (%d%% done)", prg_all), sprintf("%s%s%s %d%%", grp, ifelse(ctrl_label!="", " - ", ""), ctrl_label, prg_grp))
            
            write.table(cbind(peak_index, ancova.p[, -ncol(ancova.p)]), file = sprintf("%s/pv_%s%s%s_details.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label), col.names = T, row.names = F, quote = 1, sep = ",")
            write.table(cbind(peak_index, p.adjust(ancova.p[,2], "BH")), file = sprintf("%s/pFDR_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!=""," vs. ",""), ctrl_label), col.names = c(colnames(peak_index), paste0(grp, ifelse(ctrl_label!="","_",""), ctrl_label)), row.names = F, quote = 1, sep = ",")
            write.table(cbind(peak_index, reg.b[,2]), file = sprintf("%s/coef_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!=""," vs. ",""), ctrl_label), col.names = c(colnames(peak_index), paste0(grp, ifelse(ctrl_label!="","_",""), ctrl_label)), row.names = F, quote = 1, sep = ",")
            write.table(cbind(peak_index, reg.r), file = sprintf("%s/resi_%s%s%s_forPLS.csv", outpath, grp, ifelse(ctrl_label!=""," vs. ",""), ctrl_label), col.names = c(colnames(peak_index), rownames(peakabun[case_idx,])), row.names = F, quote = 1, sep = ",")
            
            
            if(tclvalue(permute.val)=="1"){
              peak_sig <- which(ancova.p[, 2]<as.numeric(tclvalue(permutecut.val)))
              if(length(peak_sig)>0){
                pvalue_sig <- ancova.p[peak_sig, 2]
                peakabun_sig <- as.data.frame(peakabun[case_idx, peak_sig])
                
                cl <- makeCluster(ncpu, type="SOCK")
                clusterExport(cl, c("temp_fac", "peakabun_sig", "pvalue_sig", "temp_all", "mod.f", "grp", "osIsWin"), envir=environment())
                
                registerDoSNOW(cl)
                pvalue_permute <- foreach(i=1:as.numeric(tclvalue(permute.times)), .combine='+', .packages=c("car", "utils", "tcltk")) %dopar% {
                  
                  pb2 <- tkProgressBar(sprintf("ANCOVA-Parallel task (permutation %d)",i), "0% done", 0, 100, 0, width = 500)
                  temp_fac_perm <- sample(temp_fac)
                  
                  
                  
                  ancova_perm.p <- apply(peakabun_sig, 2, function(x) {
                    tmp <- try(Anova(aov(as.formula(sprintf("x ~ %s", gsub("Group|Quan", "temp_fac_perm", mod.f[[grp]]))), data = temp_all), type = "III", singular.ok = T)[2, "Pr(>F)"], silent=T)
                    
                    as.numeric(tmp)
                  })
                  for(j in 1:100) setTkProgressBar(pb2, value = j, sprintf("ANCOVA-Parallel task (permutation %d)", i), "")
                  close(pb2)
                  
                  ancova_perm.p<pvalue_sig
                }
                stopCluster(cl)
                
                empvalue <- (pvalue_permute+1)/(as.numeric(tclvalue(permute.times))+1)
                empvalue <- cbind(empvalue, p.adjust(c(empvalue, rep(max(empvalue, as.numeric(tclvalue(permutecut.val))), nrow(peak_index)-length(empvalue))), method = "BH")[1:length(empvalue)])
                write.table(cbind(peak_index[peak_sig,], empvalue), file = sprintf("%s/epv_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!=""," vs. ",""), ctrl_label), col.names = c(colnames(peak_index), paste0(sprintf("%s%s%s",grp,ifelse(ctrl_label!="","_",""),ctrl_label),c("(epv)","(epFDR)"))), row.names = F, quote = 1, sep = ",")
                write.table(cbind(peak_index, reg.r)[peak_sig,][empvalue[, 2]<.05,], file = sprintf("%s/resi_epFDRsig_%s%s%s_forPLS.csv", outpath, grp, ifelse(ctrl_label!=""," vs. ",""), ctrl_label), col.names = c(colnames(peak_index), rownames(peakabun[case_idx,])), row.names = F, quote = 1, sep = ",")
              } else {
                tkmessageBox(title = "Warning", message = "No significant peaks", icon = "warning", type = "ok")
              }
            }
            
            prg_grp <- round(100*3/3)
            prg_all <- round(100*(fa-1)/length(Factor_label) + prg_grp/length(Factor_label))
            setTkProgressBar(pb, value = prg_all, sprintf("ANCOVA - Please wait for ANCOVA processing (%d%% done)", prg_all), sprintf("%s%s%s %d%%", grp, ifelse(ctrl_label!="", " - ", ""), ctrl_label, prg_grp))
            cat(round(100*fa/length(Factor_label)), ifelse(round(100*fa/length(Factor_label))<100, " ", "\n"), sep = "")
            Sys.sleep(0.1)
          }
          
          setTkProgressBar(pb, value = 100, "ANCOVA - Please wait for ANCOVA processing (100% done)", "Finished 100%")
          Sys.sleep(1)
          close(pb)
          tkconfigure(tt,cursor="arrow")
          
          toppeak <- tktoplevel(); if(isIcon) tk2ico.set(toppeak,icon)
          tkwm.title(toppeak, "Top peaks")
          fr_top <- tkframe(toppeak)
          tkgrid(fr_top)
          top.lab <- tklabel(fr_top, text = "    How many top peaks do you want to paint red?  ")
          top.num <- tclVar("50")
          top.entry <- tkentry(fr_top, width = 6, textvariable = top.num, bg = "white",validatecommand="string is integer %P", validate = "all")
          
          tkgrid(top.lab, top.entry, tklabel(fr_top, text = paste("(1 ~ ", ncol(peakabun), ")     ", sep = "")))
          tkgrid(tklabel(toppeak, text = "", height = 0, font = fontIntro_para))
          fr_toppeak <- tkframe(toppeak)
          tkgrid(fr_toppeak)
          plot.but <- tkbutton(fr_toppeak, text = "  Plot  ", command = function(...){
            tkconfigure(tt,cursor="watch")
            top.num <- as.numeric(tclvalue(top.num))
            if(!top.num%in%seq.int(1, ncol(peakabun))) top.num = 50
            for(grp in Factor_label){
              pfdr <- read.table(sprintf("%s/pFDR_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label), sep = ",", header = T, quote = "\"")
              pvalue <- read.table(sprintf("%s/pv_%s%s%s_details.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label), sep = ",", header = T, quote = "\"")
              beta_temp <- read.table(sprintf("%s/coef_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label), sep = ",", header = T, quote = "\"")
              
              for(pp in c("pfdr","pvalue")){
                p <- get(pp)
                
                png(filename = sprintf("%s/Volcanoplot_%s%s%s_%s_%d.png", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label, switch(pp, pfdr="pFDR", pvalue="pv"), top.num), width = 1440, height = 800)
                i <- switch(pp, pfdr=4, pvalue=5)
                par(mar = c(5, 4, 1, 3))
                pch <- rep(21, nrow(p))
                pch[which(-log10(p[,i])>=-log10(0.05))] <- 24
                bg <- rep("white", nrow(p))
                bg[which(-log10(p[,i])>=-log10(0.05))] <- "green3"
                bg[order(-log10(p[,i]), decreasing = T)[1:top.num]] <- "red"
                plot(beta_temp[, 4], -log10(p[,i]), xlab = "", ylab = "", cex = 1, pch = pch, bg = bg)
                text(beta_temp[order(-log10(p[,i]), decreasing = T)[1:top.num], 4], -log10(p[order(-log10(p[,i]), decreasing = T)[1:top.num],i]), label = peak_index[order(-log10(p[,i]), decreasing = T)[1:top.num],1], cex = 1, pos = 1, adj = 0.2)
                abline(h = -log10(0.05), col = "green3")
                par(xpd = NA)
                text(par("usr")[1], -log10(0.05), col = "green3", label = substitute(paste(plain(-log[10]), "(0.05) (", test, " significant peaks)"), list(test = sum(p[,i]<0.05,na.rm=T))), font = 4, cex = 1.5, adj = c(0,-0.1))
                par(xpd = F)
                mtext("Fold Change (coefficient)", line = 2, side = 1, col="black", padj = 1, cex = 1.5)
                mtext(bquote(-log[10](.(switch(pp, pfdr="pFDR", pvalue="pv")))), line = 3.5, side = 2, col="black", padj = 1, cex = 1.5)
                legend(x = "topleft", legend = c(sprintf("%s<0.05", switch(pp, pfdr="pFDR", pvalue="pv")), paste0("top", top.num)), pch = 24, bty = "o", box.col = "black", cex = 1, pt.bg = c("green3", "red"), bg = rgb(1, 1, 1, alpha = 0.7))
                dev.off()
              }
              
              if(tclvalue(permute.val)=="1" & file.exists(sprintf("%s/epv_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label))){
                beta_temp <- beta_temp[which(pvalue[, 5]<as.numeric(tclvalue(permutecut.val))),]
                peak_index_temp <- peak_index[which(pvalue[, 5]<as.numeric(tclvalue(permutecut.val))),]
                p <- read.table(sprintf("%s/epv_%s%s%s.csv", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label), sep = ",", header = T, quote = "\"")
                
                for(pp in c("pfdr","pvalue")){
                  png(filename = sprintf("%s/Volcanoplot_%s%s%s_%s_%d.png", outpath, grp, ifelse(ctrl_label!="", " vs. ", ""), ctrl_label, switch(pp, pfdr="epFDR", pvalue="epv"), top.num), width = 1440, height = 800)
                  i <- switch(pp, pfdr=5, pvalue=4)
                  par(mar = c(5, 4, 1, 3))
                  pch <- rep(21, nrow(p))
                  pch[which(-log10(p[,i])>=-log10(0.05))] <- 24
                  bg <- rep("white", nrow(p))
                  bg[which(-log10(p[,i])>=-log10(0.05))] <- "green3"
                  bg[order(-log10(p[,i]), decreasing = T)[1:min(top.num, nrow(p))]] <- "red"
                  plot(beta_temp[, 4], -log10(p[,i]), xlab = "", ylab = "", cex = 1, pch = pch, bg = bg)
                  text(beta_temp[order(-log10(p[,i]), decreasing = T)[1:min(top.num, nrow(p))], 4], -log10(p[order(-log10(p[,i]), decreasing = T)[1:min(top.num, nrow(p))], i]), label = peak_index_temp[order(-log10(p[,i]), decreasing = T)[1:min(top.num, nrow(p))], 1], cex = 1, pos = 1, adj = 0.2)
                  abline(h = -log10(0.05), col = "green3")
                  par(xpd = NA)
                  text(par("usr")[1], -log10(0.05), col = "green3", label = substitute(paste(plain(-log[10]), "(0.05) (", test, " significant peaks)"), list(test = sum(p[,i]<0.05,na.rm=T))), font = 4, cex = 1.5, adj = c(0,-0.1))
                  par(xpd = F)
                  mtext("Fold Change (coefficient)", line = 2, side = 1, col="black", padj = 1, cex = 1.5)
                  mtext(bquote(-log[10](.(switch(pp, pfdr="epFDR", pvalue="epv")))), line = 3.5, side = 2, col="black", padj = 1, cex = 1.5)
                  legend(x = "topleft", legend = c(sprintf("%s<0.05", switch(pp, pfdr="pFDR", pvalue="pv")), paste0("top", min(top.num, nrow(p)))), pch = 24, bty = "o", box.col = "black", cex = 1, pt.bg = c("green3", "red"), bg = rgb(1, 1, 1, alpha = 0.7))
                  dev.off()
                }
              }
            }
            tkmessageBox(title = "Analysis of Covariance", message = "Graphs are saved.", icon = "info", type = "ok")
            cat("ANCOVA - Graphs are saved.\n", sep = "")
            tkconfigure(tt,cursor="arrow")
          })
          close.but <- tkbutton(fr_toppeak, text = "  Close  ", command = function(...){
            tkdestroy(toppeak)
            tkmessageBox(title="Analysis of Covariance", message = "ANCOVA is done.", icon = "info", type = "ok")
            cat("ANCOVA - ANCOVA is done.\n", sep = "")
          })
          tkgrid(plot.but, tklabel(fr_toppeak, text = "                              "), close.but)
          tkgrid(tklabel(toppeak, text = "", height = 0, font = fontIntro_para))
        }
      } else {
        tkmessageBox(title = "Error", message = sprintf("Sample IDs are unmatched.\nPlease input the adequate file%s (%s).",ifelse(sum(!check_id_match)>1,"s",""),paste(names(check_id_match)[!check_id_match], collapse = ", ")), icon = "error", type = "ok")
        cat("ANCOVA(Error) - ", sprintf("Sample IDs are unmatched. Please input the adequate file%s (%s).",ifelse(sum(!check_id_match)>1,"s",""),paste(names(check_id_match)[!check_id_match], collapse = ", ")), "\n")
        tkfocus(dlg)
      }
    } else {
      tkmessageBox(title = "Error", message = sprintf("Input file%s (%s) %s not found.\nPlease input the correct file path%s.",ifelse(sum(!check_file_exists)>1,"s",""),paste(names(check_file_exists)[!check_file_exists],collapse=", "),ifelse(sum(!check_file_exists)>1,"are","is"),ifelse(sum(!check_file_exists)>1,"s","")), icon = "error", type = "ok")
      cat("ANCOVA(Error) - ", sprintf("Input file%s (%s) %s not found. Please input the correct file path%s.",ifelse(sum(!check_file_exists)>1,"s",""),paste(names(check_file_exists)[!check_file_exists],collapse=", "),ifelse(sum(!check_file_exists)>1,"are","is"),ifelse(sum(!check_file_exists)>1,"s","")), "\n")
      tkfocus(dlg)
    }
  }
  
  onCancel <- function(){
    tkdestroy(dlg)
    tkfocus(tt)
  }
  
  tkgrid(tklabel(dlg, text = ""))
  fr <- tkframe(dlg)
  OK.but     <- tkbutton(fr,text="     OK     ",command=onOK,state="normal")
  Cancel.but <- tkbutton(fr,text="   Cancel   ",command=onCancel)
  tkgrid(tklabel(fr,text="               "), OK.but,tklabel(fr,text="                                      "), Cancel.but, tklabel(fr,text="               "))
  tkgrid(fr)
  tkgrid(tklabel(dlg, text = "", height = 0, font = fontIntro_para))
  
  tkfocus(dlg)
  tkbind(dlg, "<Destroy>", function() {tkgrab.release(dlg);tkfocus(tt)})
  tkwait.window(dlg)
}