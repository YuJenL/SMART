R2 <- function(fit=fit){
  pred <- predict(fit)
  n <- length(pred)
  res <- resid(fit)
  w <- weights(fit)
  if (is.null(w)) w <- rep(1, n)
  rss <- sum(w * res ^ 2)
  resp <- pred + res
  center <- weighted.mean(resp, w)
  r.df <- summary(fit)$df[2]
  int.df <- 1
  tss <- sum(w * (resp - center)^2)
  r.sq <- 1 - rss/tss
  adj.r.sq <- 1 - (1 - r.sq) * (n - int.df) / r.df
  out <- list(pseudo.R.squared = r.sq,
              adj.R.squared = adj.r.sq)
  c(r.sq=r.sq,adj.r.sq=adj.r.sq)
}

cookD <- function(fit,intensity,conc){
  j = intensity
  O = matrix(cbind(weights(fit),conc),ncol = 2)
  k = summary(fit)$df[1]
  P =  O%*% solve(t(O) %*% O) %*% t(O)
  lev = diag(P)
  b = solve(t(O)%*%O)%*%t(O)%*%j
  RSS = sum((j-O%*%b)^2)
  s2 =  RSS/(length(j)-k)                  
  residuals(fit)^2/(k*s2)*(lev/(1-lev)^2)
}

outlier_detection <- function(fit,data,dtp,CI_level,bias_thr){
  intensity = data$intensity
  conc = data$conc
  
  ## cook SD
  if("cook"%in%dtp&length(fit)!=0){
    cooksD <- cookD(fit = fit,intensity = intensity, conc = conc)
    ind_cook <- unname(which(cooksD < 4/length(conc)))
  }else{
    ind_cook <- NULL
  }
  
  
  ## confidence 
  if("conf"%in%dtp&length(fit)!=0){
    p_conf <- predFit(fit, newdata = data, interval = "confidence", level= CI_level)
    ind_conf <- unname(which(intensity>=p_conf[,"lwr"]&intensity<=p_conf[,"upr"]))
  }else{
    ind_conf <- NULL
  }
  
  
  ## bias 
  if("bias"%in%dtp&length(fit)!=0){
    pred <- sapply(1:length(intensity), function(x)tryCatch(invest(fit, y0 = intensity[x], interval = "none"), error=function(err) NA))
    ind_bias <- unname(which(abs((conc-pred)*100/pred)<=bias_thr))
    bias_na <- unname(which(is.na(pred)))
  }else{
    ind_bias <- NULL
    bias_na <- NULL
  }
  
  
  list(list(ind_cook,ind_conf,ind_bias),bias_na)
}

cal_model_fit <- function(data,dtp,weight,CI_level,bias_thr){
  intensity <- unlist(data)
  conc <- as.numeric(sapply(1:ncol(data), function(x)strsplit(colnames(data)[x],"_")[[1]][2]))
  data <- data.frame(intensity=intensity,conc=conc)
  
  model_ls <- vector(mode='list', length=24)
  data_pt_ls <- vector(mode='list', length=24)
  bias_na_ls <- vector(mode='list', length=6) 
  #
  w <- list(rep(1,nrow(data)),
            1/(data$conc)^1,
            1/(data$conc)^2)
  
  ## linear
  for(w_ind in which(weight%in%c("1","x","x2"))){
    
    
    fit <- tryCatch(nls(intensity ~ theta1+theta2*conc,data=data,start = list(theta1 = 0, theta2 = 0),weights = w[[w_ind]]), error=function(err) list())
    if(length(fit)!=0){
      model_ls[[(w_ind-1)*4+1]] <- fit
      
      data_pt_ls[(w_ind-1)*4+1] <- list(1:nrow(data))
      
      outlier <- outlier_detection(fit=fit,data=data,dtp=dtp,CI_level=CI_level,bias_thr=bias_thr)
      data_pt_ls[((w_ind-1)*4+2):((w_ind-1)*4+4)] <- outlier[[1]]
      bias_na_ls[w_ind] <- outlier[2]
      for(z in which(sapply(1:3, function(x)length(outlier[[1]][[x]]))>3)){
        data_fit <- data[outlier[[1]][[z]],]
        model_ls[[z+(w_ind-1)*4+1]] <- tryCatch(nls(intensity ~ theta1+theta2*conc,data=data_fit,start = list(theta1 = 0, theta2 = 0),weights = w[[w_ind]][outlier[[1]][[z]]]), error=function(err) tryCatch(nls(intensity ~ theta1+theta2*conc,data=data_fit,start = list(theta1 = 1, theta2 = 0),weights = w[[w_ind]][outlier[[1]][[z]]]), error=function(err) list()))
      }
    }
    
    
  } 
  
  ## quadratic
  for(w_ind in which(weight%in%c("1","x","x2"))){
    fit <- tryCatch(nls(intensity ~ theta1+theta2*conc+theta3*conc^2,data=data,start = list(theta1=0, theta2=0, theta3=0),weights = w[[w_ind]]), error=function(err) list())
    if(length(fit)!=0){
      model_ls[[(w_ind-1)*4+13]] <- fit
      
      data_pt_ls[(w_ind-1)*4+13] <- list(1:nrow(data))
      
      outlier <- outlier_detection(fit=fit,data=data,dtp=dtp,CI_level=CI_level,bias_thr=bias_thr)
      data_pt_ls[((w_ind-1)*4+14):((w_ind-1)*4+16)] <- outlier[[1]]
      bias_na_ls[w_ind+3] <- outlier[2]
      for(z in which(sapply(1:3, function(x)length(outlier[[1]][[x]]))>3)){
        data_fit <- data[outlier[[1]][[z]],]
        model_ls[[z+(w_ind-1)*4+13]] <-tryCatch(nls(intensity ~ theta1+theta2*conc+theta3*conc^2,data=data_fit,start = list(theta1=0, theta2=0, theta3=0),weights = w[[w_ind]][outlier[[1]][[z]]]), error=function(err) tryCatch(nls(intensity ~ theta1+theta2*conc+theta3*conc^2,data=data_fit,start = list(theta1=1, theta2=1, theta3=1),weights = w[[w_ind]][outlier[[1]][[z]]]), error=function(err) list()))
      }
    }
    
    
   
  } 
  
  name <- c(paste(rep("lm",12),rep(c("1","x","x2"),each=4),rep(c("all","cook","conf","bias"),3),sep = "_"),
            paste(rep("qm",12),rep(c("1","x","x2"),each=4),rep(c("all","cook","conf","bias"),3),sep = "_"))
  
  
  data_pt_ls <- sapply(1:length(data_pt_ls),function(x)conc[data_pt_ls[[x]]])
  names(data_pt_ls) <- name
  names(model_ls) <- name
  bias_na_ls <-  sapply(1:length(bias_na_ls),function(x)paste0(conc[bias_na_ls[[x]]],collapse = ";"))
  names(bias_na_ls) <- c(paste(rep("lm",3),rep(c("1","x","x2"),each=1),rep(c("bias"),3),sep = "_"),
                         paste(rep("qm",3),rep(c("1","x","x2"),each=1),rep(c("bias"),3),sep = "_"))
  
  list(model = model_ls,
       data_pt = data_pt_ls,
       bias_na_ls = bias_na_ls)
  
}


model_out <- function(peak_info,df,m,w,dtp,CI_level,bias_thr,outpath){
  
  conc <- as.numeric(sapply(1:ncol(df), function(x)strsplit(colnames(df)[x],"_")[[1]][2]))
  
  df <- df[,order(conc)]
  conc <- conc[order(conc)]
  
  model_fit <- lapply(1:nrow(df), function(ind){
    cal_model_fit(data=df[ind,],dtp=dtp,weight=w,CI_level=CI_level,bias_thr=bias_thr)
  })
  
  aa <- lapply(1:length(model_fit), function(ind){
    fit <- model_fit[[ind]]
    out <- c()
    for(mm in 1:length(m)){
      for(ww in 1:length(w)){
        model_name <- paste(m[mm],w[ww],dtp,sep = "_")
        out_tmp <- c(sapply(1:length(model_name), function(x){
          if(length(fit$model[[model_name[x]]])==0){
            c("outlier_detect",rep(NA,6))
          }else{
            beta <- coefficients(fit$model[[model_name[x]]])
            if(length(beta)==2){beta <- c(beta,theta3=NA)}
            c("outlier_detect",paste(fit$data_pt[model_name[x]][[1]],collapse = ";"),beta,R2(fit=fit$model[[model_name[x]]]))
          }
          
          
        }))
        out <- rbind(out,out_tmp)
      }
    }
    
    bias_na <- unlist(lapply(fit$bias_na_ls,function(x) if(identical(x,character(0))) ' ' else x))
    names(bias_na) <- c(paste(rep("lm",3),rep(c("1","x","x2"),each=1),sep = "_"),
                        paste(rep("qm",3),rep(c("1","x","x2"),each=1),sep = "_"))
    
    colnames(out) <- rep(c("m","concentration","theta1","theta2","theta3","R2","adj.R2"),length(dtp))
    colnames(out)[colnames(out)=="m"] <- dtp
    out[out%in%"outlier_detect"] <- ""
    model_name <- paste(rep(m,each=length(w)),rep(w,length(m)),sep = "_")
    bias_na <- bias_na[model_name]
    
    model_name <- gsub("lm","linear",model_name)
    model_name <- gsub("qm","quadratic",model_name)
    model_name <- gsub("1","unweighted",model_name)
    model_name <- gsub("x","1/x",model_name)
    model_name  <- sapply(1:length(model_name), function(x) strsplit(model_name[x],"_"))
    
    
    out <- cbind(model=sapply(1:length(model_name), function(x) model_name[[x]][1]),
                 weights=sapply(1:length(model_name), function(x) model_name[[x]][2]),out)
    rownames(out) <- NULL
    if("bias"%in%dtp){
      col_ind <- which(colnames(out)=="bias")
      cbind(peak_info[ind,],out[,1:col_ind],bias_na,out[,(col_ind+1):ncol(out)], row.names = NULL)
    }else{
      cbind(peak_info[ind,],out, row.names = NULL)
    }
    
  })
  
  
  
  bb <- do.call("rbind", aa)
  colnames(bb) <- gsub("all","Original",colnames(bb))
  colnames(bb) <- gsub("cook","Cook's Distance",colnames(bb))
  colnames(bb) <- gsub("conf","Confidence Interval",colnames(bb))
  colnames(bb) <- gsub("bias","Bias",colnames(bb))
  
  names(model_fit) <- paste0("ID",peak_info$Peak_Index,"_mz",peak_info$mz)
  
  mw <- c("unweighted","weights=1/x","weights=1/x2")
  names(mw) <- c("1","x","x2")
  mo <- c("","Cook's distance","Confidence Interval","Bias")
  names(mo) <- c("all","cook","conf","bias")
  
  ## visualization
  n_row <- length(w)
  n_col <- length(dtp)
  
  
  
  comb <- apply(expand.grid(w, dtp), 1, paste, collapse="_")
  
  
  
  for(mod in m){
    for(comp_ind in 1:nrow(df)){
      tiff(paste0(outpath,"/PID",peak_info$Peak_Index[comp_ind],"_",peak_info$Name[comp_ind],"_mz",peak_info$mz[comp_ind],"_",mod,".tiff"), width=1440*n_col*2, height=800+1080*n_row*2, compression="lzw", res=300*2)
      par(mar=c(4,4,5,4),oma=c(2,2,2,2))
      layout(rbind(rep(1,n_col),matrix(1:(n_row*n_col),ncol=n_col)+1),heights = c(800,rep(1080*2,n_row)))
      
      plot(0, 0,xlim=c(0,1),ylim=c(0,1),xlab="",ylab="",xpd=NA,bty="n",yaxt="n",xaxt="n",yaxs = "i",xaxs = "i",bty = 'n',type="n")
      text(0.5,0.5,paste0("Peak Index ",peak_info$Peak_Index[comp_ind],", ",peak_info$Name[comp_ind],", m/z = ",peak_info$mz[comp_ind]),font=2,xpd=NA,cex=2)
      legend("topright",                   
             legend = c("Standard","Outlier"),
             pch = c(16,16),
             col = c("black","red"),xpd=NA,cex=2)
      
      
      
      for(ind in 1:length(comb)){
        plot(conc,df[comp_ind,],pch=16,xlab="",ylab="",xpd=NA,bty="n",yaxt="n",xaxt="n",cex=2)
        box(which = "plot", bty = "l",lwd=2)
        axis(side = 1, lwd = 2,cex.axis=1.5,font=2)
        axis(side = 2, lwd = 2,cex.axis=1.5,font=2,las=2)
        
        pt <- model_fit[[comp_ind]][["data_pt"]][[paste0(mod,"_",comb[ind])]]
        pt_i <- which(!conc%in%pt)
        points(conc[pt_i],df[comp_ind,pt_i],pch=16,col="red",cex=2)
        
        loc <- par("usr")
        text(loc[1], loc[4]*1.05, "Intensity", pos = 2, xpd = NA,font=2,cex=1.5)
        
        mtext(side=1,line=3 ,"Concentration",font=2,cex=1)
        
        mtext(side=3, line=1, cex=1, mw[strsplit(comb[ind],"_")[[1]][1]],font=2)
        mtext(side=3, line=2.5, cex=1, mo[strsplit(comb[ind],"_")[[1]][2]],font=2)
        
        if(length(pt)>=4&length(model_fit[[comp_ind]][["model"]][[paste0(mod,"_",comb[ind])]])>0){
          #
          # abline(model_fit[[comp_ind]][["model"]][[paste0("lm_",comb[ind])]],lwd=2.5)
          pred = predict(model_fit[[comp_ind]][["model"]][[paste0(mod,"_",comb[ind])]], pt)
          # lines(pt, pred, lwd = 3, col = "blue")
          
          beta <- round(coef(model_fit[[comp_ind]][["model"]][[paste0(mod,"_",comb[ind])]]),2)
          r2 <- round(R2(model_fit[[comp_ind]][["model"]][[paste0(mod,"_",comb[ind])]]),4)
          
          if(length(beta)==2){
            expr_beta = bquote(bold(Y == .(beta[1])~"+"~.(beta[2])~"X"))
            curve(beta[1]+beta[2]*x,conc, add = TRUE, lwd = 3, col = "blue")
          }else{
            expr_beta = bquote(bold(Y == .(beta[1])~"+"~.(beta[2])~"X"~"+"~.(beta[3])~X^2))
            curve(beta[1]+beta[2]*x+beta[3]*x^2,conc, add = TRUE, lwd = 3, col = "blue")
          }
          
          expr_R2 = bquote(bold(R^2 ~ adj == .(r2[2])))
          
          
          mtext(side=3, line=-1, cex=1, expr_beta,font=2)
          mtext(side=3, line=-2.5, cex=1, expr_R2,font=2)
        }
        
        
        
        
        
        
      }
      
      dev.off()
    }
    
  }
  
  
  
  ## output
  
  ## csv table
  write.csv(bb,paste0(outpath,"/Calibration-curve_info.csv"),row.names = F,na = "")
  
  ## Rdata
  save(model_fit,df,peak_info, 
       file = paste0(outpath,"/model_fit.RData"))
  
  # list(model_fit=model_fit,output=bb)
  # names(model_fit[[1]]$data_pt)
}

calibration_curve <- function(){
  dlg <- tktoplevel(width = 800); if(isIcon) tk2ico.set(dlg,icon)
  tkwm.title(dlg, "Calibration Curve Construction")
  
  fr_input <- tkframe(dlg, width = 800)
  
  fr_step <- tkframe(dlg, width = 800)
  tkgrid(tklabel(fr_step, text = "   Step1: Import Data",foreground="black"),
         tklabel(fr_step, text = "  -> Step2: Quality Control",foreground="gray"),
         tklabel(fr_step, text = "  -> Step3: Parameter Setting",foreground="gray"))
  tkgrid(fr_step, sticky = "w")
  
  fr_import <- tkframe(dlg)
  
  
  textCaliinput <<- tclVar()
  textinputWidget <- tkentry(fr_input,width="70", textvariable = textCaliinput, bg = "white")
  box.input <- tkbutton(fr_input, text = "...",  command = function() tclvalue(textCaliinput) <- tkgetOpenFile(initialfile = tclvalue(textCaliinput), filetypes = "{{Text Files} {.txt .csv}}"))
  tkgrid(tklabel(fr_input, text = "", height = 0, font = fontIntro_para))
  tkgrid(tklabel(fr_input, text="   Input file: "),textinputWidget, box.input, tklabel(fr_input,text="    "), sticky = "w")
  tkgrid(tklabel(fr_input, text="",height = 0, font = fontIntro_para))
  tkgrid(fr_input,sticky = "w")
  
  
  if(!exists("textoutput")){
    textoutput <<- tclVar()
    textoutputWidget <- tkentry(fr_input,width="70", textvariable = textoutput, bg = "white")
    box.output <- tkbutton(fr_input, text = "...",  command = function(){
      tclvalue(textoutput) <- tkchooseDirectory()
    })
    tkgrid(tklabel(fr_input, text = "   Output folder: "), textoutputWidget, box.output, tklabel(fr_input, text = "    "), sticky = "w")
  }else{
    if(tclvalue(textoutput)==""){
      textoutput <<- tclVar()
      textoutputWidget <- tkentry(fr_input,width="70", textvariable = textoutput, bg = "white")
      box.output <- tkbutton(fr_input, text = "...",  command = function(){
        tclvalue(textoutput) <- tkchooseDirectory()
      })
      tkgrid(tklabel(fr_input, text = "   Output folder: "), textoutputWidget, box.output, tklabel(fr_input, text = "    "), sticky = "w")
    }else{
      textoutput <<- tclvalue(textoutput)
      textoutputWidget <- tkentry(fr_input,width="70", textvariable = textoutput, bg = "white")
      box.output <- tkbutton(fr_input, text = "...",  command = function(){
        tclvalue(textoutput) <- tkchooseDirectory()
      })
      tkgrid(tklabel(fr_input, text = "   Output folder: "), textoutputWidget, box.output, tklabel(fr_input, text = "    "), sticky = "w")
      
      
    }
  } 
  
  
  text_missing <<- tclVar("NA")
  missing_lab <- tklabel(fr_input, text = "   Missing data:       ")
  missing_widget <- tkentry(fr_input, textvariable = text_missing, bg = "white")
  tkgrid(missing_lab, missing_widget, sticky = "w")
  
  
  text_concunit <<- tclVar("ppb")
  concunit_lab <- tklabel(fr_input, text = "   Units of Concentration:       ")
  concunit_widget <- tkentry(fr_input, textvariable = text_concunit, bg = "white")
  tkgrid(concunit_lab, concunit_widget, sticky = "w")
  
  tkgrid(tklabel(fr_input,text="    ", height = 0, font = fontIntro_para))
  
  
  onCancel <- function()
  {
    tkdestroy(dlg)
    tkfocus(tt)
  }
  
  
  fr <- tkframe(dlg)
  tkgrid(tklabel(fr,text="", font = fontIntro_para, height = 0))
  
  tkgrid(fr)
  contin.but     <- tkbutton(fr,text="  Continue  ",command=function(...){
    if(file.exists(tclvalue(textCaliinput)) & file.exists(tclvalue(textoutput))){
      outpath = paste(tclvalue(textoutput), "/Concentration Calibration", sep = "")
      dir.create(outpath, showWarnings = F)
      setwd(outpath)
      
      tkdestroy(dlg)
      checking <- tktoplevel(); if(isIcon) tk2ico.set(checking,icon)
      tktitle(checking) = "Column Information"
      input_idx_head = tkframe(checking)
      tkgrid(tklabel(input_idx_head, text = "   Please provide column information:"), sticky = "w")
      tkgrid(tklabel(input_idx_head, text = "", font = fontIntro_para, height = 0), sticky = "w")
      tkgrid(input_idx_head, sticky = "w")
      
      input_idx = tkframe(checking)
      
      PI.lab = tklabel(input_idx, text = "   Column index of peak index: ")
      tk2tip(PI.lab, "Please input column index of peak index if you have.")
      index.PI <<- tclVar("NA")
      PI_entry = tkentry(input_idx, width = "5", textvariable = index.PI, bg = "white")	
      tkgrid(PI.lab, PI_entry, sticky = "w")
      
      name.lab = tklabel(input_idx, text = "   Column index of name: ")
      tk2tip(name.lab, "Please input column index of name if you have.")
      index.name <<- tclVar("NA")
      name_entry = tkentry(input_idx, width = "5", textvariable = index.name, bg = "white")	
      tkgrid(name.lab, name_entry, sticky = "w")
      
      
      mass.lab <- tklabel(input_idx, text = "   Column index of mass: ")
      index.mass <<- tclVar("")
      mass_entry = tkentry(input_idx, width = "5", textvariable = index.mass, bg = "white")
      tkgrid(mass.lab, mass_entry, sticky = "w")
      
      
      RT.lab = tklabel(input_idx, text = "   Column index of retention time: ")
      index.RT <<- tclVar("")
      RT_entry = tkentry(input_idx, width = "5", textvariable = index.RT, bg = "white")
      RT_unit = c("min", "sec")
      RT_text = tclVar("sec")
      RTunit.lab = tklabel(input_idx, text = "  unit: ")
      RTcomboBox <- ttkcombobox(input_idx, state = "readonly", values = RT_unit, width = 4, textvariable = RT_text)
      tkgrid(RT.lab, RT_entry, RTunit.lab, RTcomboBox, tklabel(input_idx, text = "   "), sticky = "w")
      
      
      first.lab = tklabel(input_idx, text = "   Column index of first sample: ")
      index.first <<- tclVar("")
      first_entry = tkentry(input_idx, width = "5" ,textvariable = index.first, bg = "white")
      tkgrid(first.lab, first_entry, sticky = "w")
      
      tkgrid(tklabel(input_idx, text = "", height = 0, font = fontIntro_para))
      tkgrid(input_idx)
      
      contiframe = tkframe(checking)
      
      conti.button <- tkbutton(contiframe, text = "   Import   ", command = function(){
        RT.unit <<- tclvalue(RT_text)
        tkdestroy(checking)
        
        
        align_table_in <- read.table(tclvalue(textCaliinput), header = T, quote = "\"", fill = T, sep = ifelse(grepl(".txt", tclvalue(textCaliinput)), "\t", ","), as.is = T, na.string = c("NA", as.character(tclvalue(text_missing))))
        if(as.character(tclvalue(index.PI))=="NA"|as.character(tclvalue(index.name))=="NA"){
          
          align_table =  align_table_in[,as.numeric(c(tclvalue(index.mass), tclvalue(index.RT), seq.int(as.numeric(tclvalue(index.first)), ncol(align_table_in))))]
          if(as.character(tclvalue(index.PI))=="NA"){
            align_table$Peak_Index <- 1:nrow(align_table_in)
          }else{
            align_table$Peak_Index <- align_table_in[,as.numeric(tclvalue(index.PI))]
          }
          if(as.character(tclvalue(index.name))=="NA"){
            align_table$Name <- align_table$Peak_Index
          }else{
            align_table$Name <-align_table_in[,as.numeric(tclvalue(index.name))]
          }
          
          align_table <- align_table[,c(which(colnames(align_table)=="Peak_Index"),
                                        which(colnames(align_table)=="Name"),
                                        setdiff(1:ncol(align_table),c(which(colnames(align_table)=="Peak_Index"),which(colnames(align_table)=="Name"))))]
          
        }else{
          align_table = align_table_in[,as.numeric(c(tclvalue(index.PI),tclvalue(index.name), tclvalue(index.mass), tclvalue(index.RT), seq.int(as.numeric(tclvalue(index.first)), ncol(align_table_in))))]
        }
        nRow <- nrow(align_table)
        nCol <- ncol(align_table)
        align_table <- peakabunCheck(align_table,5)
        
        
        if(RT.unit == "min") align_table[,4] = 60*align_table[,4]
        colnames(align_table) = c("Peak_Index","Name", "mz", "Ret_time.sec", gsub("^\\d{4,8}_(.*?)|(^[A-Z]\\d{4,8})_(.*?)", "\\1", colnames(align_table)[-c(1:4)]))
        txtout <- strsplit(tclvalue(textCaliinput),"/")[[1]]
        # write.table(align_table, file = gsub("_forSMART.csv|_forSMART.txt", "_calibration_samples_forSMART.csv", txtout[length(txtout)]), sep = ",", col.names = T, row.names = F, quote = c(1))
        
        assign("cali_table", align_table, envir = .GlobalEnv)
        
        setwd(tclvalue(textoutput))
        # tkfocus(tt)
        
        
        
        tkmessageBox(title = "Data Import", message = sprintf("Data import is done.\n%d out of %d non-informative replicate sample(s) are excluded.\n%d out of %d non-informative peak(s) are excluded.",nCol-ncol(align_table),nCol-4,nRow-nrow(align_table),nRow), icon = "info", type = "ok")
        cat(sprintf("Data import is done.\n%d out of %d non-informative replicate sample(s) are excluded.\n%d out of %d non-informative peak(s) are excluded.\n",nCol-ncol(align_table),nCol-4,nRow-nrow(align_table),nRow))
        
        sample = colnames(cali_table)[-c(1:4)]
        sample_ini_idx <<- 1:length(sample)
        sample_sel_idx <<- NULL
        
        ## Step 2 Quality Control
        QC <- tktoplevel(width = 800); if(isIcon) tk2ico.set(QC,icon)
        tktitle(QC) = "Calibration Curve Construction"
        
        
        fr_step <- tkframe(QC, width = 800)
        tkgrid(tklabel(fr_step, text = "   Step1: Import Data",foreground="gray"),
               tklabel(fr_step, text = "  -> Step2: Quality Control",foreground="black"),
               tklabel(fr_step, text = "  -> Step3: Parameter Setting",foreground="gray"))
        tkgrid(fr_step, sticky = "w")
        
        fr_qc <- tkframe(QC, width = 800)
        tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
        tkgrid(tklabel(fr_qc, text = paste("Input file: ", tclvalue(textCaliinput), "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
        tkgrid(fr_qc, sticky = "w")
        
        
        tkgrid(tklabel(fr_qc, text = paste("Output folder: ", tclvalue(textoutput), "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
        tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
        tkgrid(fr_qc, sticky = "w")
        
        
        
        # sample_select <- tktoplevel(); if(isIcon) tk2ico.set(sample_select,icon)
        
        # tkwm.title(sample_select, "Calibration Curve - Sample Selection")
        tkgrid(tklabel(fr_qc, text = "Sample Selection: ", padx = 11, wraplength = 600, justify = "left"), sticky = "w")
        tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
        
        
        choose_frame <- tkframe(fr_qc)
        
        ini_frame <- tkframe(choose_frame)
        ini_vscr <- tkscrollbar(ini_frame, repeatinterval = 5, orient="vertical", command = function(...) tkyview(ini_tl,...))
        ini_hscr <- tkscrollbar(ini_frame, repeatinterval = 1, orient="horizontal", command = function(...) tkxview(ini_tl,...))
        ini_tl <- tklistbox(ini_frame, height = 15, selectmode = "extended", xscrollcommand = function(...) tkset(ini_hscr,...), yscrollcommand = function(...) tkset(ini_vscr,...), background = "white")
        tkgrid(tklabel(ini_frame, text = "Sample"))
        tkgrid(ini_tl, ini_vscr)
        tkgrid(ini_hscr, sticky="new")
        tkgrid.configure(ini_vscr, rowspan = 4, sticky = "nsw")
        for(x in sample_ini_idx){
          tkinsert(ini_tl, "end", sample[x])
        }
        sel_frame <- tkframe(choose_frame)
        sel_vscr <- tkscrollbar(sel_frame, repeatinterval = 5, orient="vertical", command = function(...) tkyview(sel_tl,...))
        sel_hscr <- tkscrollbar(sel_frame, repeatinterval = 1, orient="horizontal", command = function(...) tkxview(sel_tl,...))
        sel_tl <- tklistbox(sel_frame, height = 15, selectmode = "extended", xscrollcommand = function(...) tkset(sel_hscr, ...), yscrollcommand = function(...) tkset(sel_vscr, ...), background = "white")
        tkgrid(tklabel(sel_frame, text = "Sample Selection"))
        tkgrid(sel_tl, sel_vscr)
        tkgrid(sel_hscr, sticky="new")
        tkgrid.configure(sel_vscr, rowspan = 4, sticky = "nsw")
        in_out <- tkframe(choose_frame)
        tkpack(tkbutton(in_out, text = "  >>  ", command = function(...){
          if(length(as.integer(tkcurselection(ini_tl)))!=0){
            iniIndex <- as.integer(tkcurselection(ini_tl))
            for(x in 1:length(iniIndex)){
              tkdelete(ini_tl, iniIndex[x]-x+1)
            }
            sample_sel_idx <<- sort(c(sample_sel_idx, sample_ini_idx[iniIndex+1]))
            for(x in iniIndex){
              tkinsert(sel_tl, which(sample_sel_idx==sample_ini_idx[x+1])-1, sample[sample_ini_idx[x+1]])
            }
            sample_ini_idx <<-  sample_ini_idx[-(iniIndex+1)]
          }
          
        }))
        tkpack(tklabel(in_out, text = "     "))
        tkpack(tkbutton(in_out, text = "  <<  ", command = function(...){
          if(length(as.integer(tkcurselection(sel_tl)))!=0){
            selIndex <- as.integer(tkcurselection(sel_tl))
            for(x in 1:length(selIndex)){
              tkdelete(sel_tl, selIndex[x]-x+1)
            }
            sample_ini_idx <<- sort(c(sample_ini_idx, sample_sel_idx[selIndex+1]))
            for(x in selIndex){
              tkinsert(ini_tl, which(sample_ini_idx==sample_sel_idx[x+1])-1, sample[sample_sel_idx[x+1]])
            }
            sample_sel_idx <<- sample_sel_idx[-(selIndex+1)]
          }
          
        }))
        
        tkgrid(ini_frame, in_out, sel_frame, padx = 10)
        tkgrid(tklabel(choose_frame, text = "", height = 0, font = fontIntro_para))
        tkgrid(choose_frame)
        
        # rt mz 
        fr_rtmz <- tkframe(fr_qc)
        rtmz_choice <- tclVar("1")
        rtmz_yes <- tkradiobutton(fr_rtmz, variable = rtmz_choice, value = "1", command = function(...){
          tkconfigure(rtmz1, state = "normal")
          if(tclvalue(rt.val)=="1"){
            tkconfigure(rtstart.entry, state = "normal")
            tkconfigure(rtend.entry, state = "normal")
          }else{
            tkconfigure(rtstart.entry, state = "disable")
            tkconfigure(rtend.entry, state = "disable")
          }
          tkconfigure(rtmz2, state = "normal")
          if(tclvalue(mz.val)=="1"){
            tkconfigure(mzstart.entry, state = "normal")
            tkconfigure(mzend.entry, state = "normal")
          }else{
            tkconfigure(mzstart.entry, state = "disable")
            tkconfigure(mzend.entry, state = "disable")
          }
        })
        rtmz_no <- tkradiobutton(fr_rtmz, variable = rtmz_choice, value = "2", command = function(...){
          tkconfigure(rtmz1, state = "disable")
          tkconfigure(rtstart.entry, state = "disable")
          tkconfigure(rtend.entry, state = "disable")
          tkconfigure(rtmz2, state = "disable")
          tkconfigure(mzstart.entry, state = "disable")
          tkconfigure(mzend.entry, state = "disable")
        })
        
        rt.val <- tclVar("1")
        rtmz1 <- tkcheckbutton(fr_rtmz, variable = rt.val, command = function(...){
          if(tclvalue(rt.val)=="1"){
            tclvalue(rtmz_choice) = 1
            tkconfigure(rtstart.entry, state = "normal")
            tkconfigure(rtend.entry, state = "normal")
          }else{
            tkconfigure(rtstart.entry, state = "disable")
            tkconfigure(rtend.entry, state = "disable")
          }
        })
        rtstart <- tclVar()
        rtstart.entry <- tkentry(fr_rtmz, width = 5, textvariable = rtstart, bg = "white")
        rtend <- tclVar()
        rtend.entry <- tkentry(fr_rtmz, width = 5, textvariable = rtend, bg = "white")
        
        mz.val <- tclVar("0")
        rtmz2 <- tkcheckbutton(fr_rtmz, variable = mz.val, command = function(...){
          if(tclvalue(mz.val)=="1"){
            tclvalue(rtmz_choice) = 1
            tkconfigure(mzstart.entry, state = "normal")
            tkconfigure(mzend.entry, state = "normal")
          }else{
            tkconfigure(mzstart.entry, state = "disable")
            tkconfigure(mzend.entry, state = "disable")
          }
        })
        
        mzstart <- tclVar()
        mzstart.entry <- tkentry(fr_rtmz, width = 5, textvariable = mzstart, bg = "white")
        mzend <- tclVar()
        mzend.entry <- tkentry(fr_rtmz, width = 5, textvariable = mzend, bg = "white")
        tkconfigure(mzstart.entry, state = "disable")
        tkconfigure(mzend.entry, state = "disable")
        
        tkgrid(tklabel(fr_rtmz, text = "   Retention time (RT) and m/z: "), rtmz_yes, tklabel(fr_rtmz, text = "Yes "), rtmz1, tklabel(fr_rtmz, text = "RT: From"), rtstart.entry, tklabel(fr_rtmz, text = " to"), rtend.entry, tklabel(fr_rtmz, text = "(sec) and "), sticky = "w")
        tkgrid(tklabel(fr_rtmz, text = " "), tklabel(fr_rtmz, text = " "), tklabel(fr_rtmz, text = " "), rtmz2, tklabel(fr_rtmz, text = "m/z: From"), mzstart.entry, tklabel(fr_rtmz, text = " to"), mzend.entry)
        tkgrid(tklabel(fr_rtmz, text = "   "), rtmz_no, tklabel(fr_rtmz, text = "No"))
        tkgrid(fr_rtmz, sticky = "w")
        
        fr_next <- tkframe(QC)
        next.button <- tkbutton(fr_next, text = "  Next  ", state="normal", command = function(...){
          if(length(sample_sel_idx)>=4){
            tkdestroy(QC)
            # tkconfigure(tt,cursor="watch")
            
            cali_table <- cbind(cali_table[,1:4],cali_table[,sample[sample_sel_idx]])
            
            temp = NULL
            if(tclvalue(rtmz_choice) == "1"){
              if(tclvalue(rt.val)=="1"){
                RT_idx = which(cali_table[,4]>=as.numeric(tclvalue(rtstart)) & cali_table[,4]<=as.numeric(tclvalue(rtend)))
                
                temp = c(temp, c(1:nrow(cali_table))[-RT_idx])
              }
              if(tclvalue(mz.val)=="1"){
                MZ_idx = which(cali_table[,3]>=as.numeric(tclvalue(mzstart)) & cali_table[,3]<=as.numeric(tclvalue(mzend)))
                
                temp = c(temp, c(1:nrow(cali_table))[-MZ_idx])
              }
              temp = unique(temp)
            }
            if(length(temp)>0){
              QCrow = nrow(cali_table)
              cali_table = cali_table[-temp,]
              
              tkmessageBox(title = "Quality Control", message = paste("In the region of RT (and MZ), number of peaks is reduced from ", QCrow, " to ", QCrow-length(temp), ".\nThe file is saved as ''S", ncol(cali_table)-4, "_P", nrow(cali_table), ".csv''.", sep = ""), icon = "info", type = "ok") 
              cat("Quality Control - In the region of RT (and MZ), number of peaks is reduced from ", QCrow, " to ", nrow(cali_table), ".\nThe file is saved as ''S", ncol(cali_table)-4, "_P", nrow(cali_table), ".csv''.\n", sep = "") 
            }else{
              
              
              if(tclvalue(rtmz_choice) == "1"){
                tkmessageBox(title = "Quality Control", message = "All peaks are in the region of RT (and MZ).", icon = "info", type = "ok")
                cat("Quality Control - All peaks are in the region of RT (and MZ).\n")
              }
            }
            
            
            assign("cali_table", cali_table, envir = .GlobalEnv)
            outpath = paste0(tclvalue(textoutput), "/Concentration Calibration/S",ncol(cali_table)-4,"_P",nrow(cali_table),"_",substr(gsub("-| |:","",Sys.time()),1,12))
            
            
            
            dir.create(outpath, showWarnings = F)
            setwd(outpath)
            assign("cali_table_outpath", outpath, envir = .GlobalEnv)
            
            write.table(cali_table, file = paste(outpath, "/Peak_abundance_S",ncol(cali_table)-4,"_P",nrow(cali_table), ".csv", sep = ""), sep = ",", col.names = T, row.names = F, quote = 1)
            textCaliinput <<-paste(outpath, "/Peak_abundance_S",ncol(cali_table)-4,"_P",nrow(cali_table), ".csv", sep = "")
            
            
            
            ## Step 3 Parameter Setting
            ParaSet <- tktoplevel(width = 800); if(isIcon) tk2ico.set(ParaSet,icon)
            tkwm.title(ParaSet, "Calibration Curve Construction")
            
            fr_step <- tkframe(ParaSet, width = 800)
            tkgrid(tklabel(fr_step, text = "   Step1: Import Data",foreground="gray"),
                   tklabel(fr_step, text = "  -> Step2: Quality Control",foreground="gray"),
                   tklabel(fr_step, text = "  -> Step3: Parameter Setting",foreground="black"))
            tkgrid(fr_step, sticky = "w")
            
            fr_qc <- tkframe(ParaSet, width = 800)
            tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
            tkgrid(tklabel(fr_qc, text = paste("Input file: ", textCaliinput, "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
            tkgrid(fr_qc, sticky = "w")
            
            
            tkgrid(tklabel(fr_qc, text = paste("Output folder: ", tclvalue(textoutput), "    ", sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
            tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
            tkgrid(fr_qc, sticky = "w")
            
            tkgrid(tklabel(fr_qc, text = paste("# of sample: ", ncol(cali_table)-4, sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
            tkgrid(tklabel(fr_qc, text = paste("# of peak: ", nrow(cali_table), sep = ""), padx = 11, wraplength = 600, justify = "left"), sticky = "w")
            
            tkgrid(tklabel(fr_qc, text = "", height = 0, font = fontIntro_para))
            tkgrid(fr_qc, sticky = "w")
            
            
            fr_para <- tkframe(ParaSet)
            tkgrid(tklabel(fr_para, text = "   Parameter setting:"))
            tkgrid(fr_para, sticky = "w")
            
            fr_para_choice <- tkframe(ParaSet)
            tkgrid(fr_para_choice, sticky = "w")
            
            ## model
            fr_mod <- tkframe(fr_para_choice)
            tkgrid(fr_mod, sticky = "w")
            
            labelmod <- tklabel(fr_mod,text = "      Model: ")
            
            mod_l.val = tclVar(1)
            modlinear = tkcheckbutton(fr_mod, variable = mod_l.val)
            labelmod.linear <- tklabel(fr_mod, text = "Linear")
            
            mod_q.val = tclVar(1)
            modquadr = tkcheckbutton(fr_mod, variable = mod_q.val)
            labelmod.quadr <- tklabel(fr_mod, text = "Quadratic")
            
            tkgrid(labelmod, modlinear, labelmod.linear, 
                   modquadr,labelmod.quadr, sticky = "w")
            
            
            ## weighting
            fr_wt <- tkframe(fr_para_choice)
            tkgrid(fr_wt, sticky = "w")
            
            labelweight <- tklabel(fr_wt,text = "      Weighting: ")
            
            weight_1.val = tclVar(1)
            modweight.1 = tkcheckbutton(fr_wt, variable = weight_1.val)
            labelweight.1 <- tklabel(fr_wt, text = "unweighted")
            
            weight_x.val = tclVar(1)
            modweight.over1 = tkcheckbutton(fr_wt, variable = weight_x.val)
            labelweight.over1 <- tklabel(fr_wt, text = "1/x")
            
            weight_x2.val = tclVar(1)
            modweight.over2 = tkcheckbutton(fr_wt, variable = weight_x2.val)
            labelweight.over2 <- tklabel(fr_wt, text = "1/x^2")
            
            
            tkgrid(labelweight,modweight.1,labelweight.1,
                   modweight.over1, labelweight.over1,
                   modweight.over2, labelweight.over2, sticky = "w")
            
            
            
            
            # outlier
            fr_outlier <- tkframe(fr_para_choice)
            tkgrid(fr_outlier, sticky = "w")
            
            labeloutlier <- tklabel(fr_outlier, text="      Outlier Dectection: ")
            
            
            outlier_choice <- tclVar("1")
            outlier_yes <- tkradiobutton(fr_outlier, variable = outlier_choice, value = "1", command = function(...){
              tkconfigure(outlier_CI, state = "normal")
              tkconfigure(outlier_CI.entry, state = "normal")
              tkconfigure(outlier_cook, state = "normal")
              tkconfigure(outlier_dev, state = "normal")
              tkconfigure(outlier_dev.entry, state = "normal")
            })
            
            outlier_no <- tkradiobutton(fr_outlier, variable = outlier_choice, value = "2", command = function(...){
              tkconfigure(outlier_CI, state = "disable")
              tkconfigure(outlier_CI.entry, state = "disable")
              tkconfigure(outlier_cook, state = "disable")
              tkconfigure(outlier_dev, state = "disable")
              tkconfigure(outlier_dev.entry, state = "disable")
            })
            
            cI.val = tclVar(1)
            outlier_CI <- tkcheckbutton(fr_outlier, variable = cI.val, command = function(...){
              if(tclvalue(cI.val)=="1"){
                tclvalue(outlier_choice) = 1
                tkconfigure(outlier_CI.entry, state = "normal")
              }else{
                tkconfigure(outlier_CI.entry, state = "disable")
              }
            }) 
            
            outlier_CI_level <- tclVar("0.95")
            outlier_CI.entry <- tkentry(fr_outlier, width = 5, textvariable = outlier_CI_level, bg = "white")
            
            
            
            cook.val = tclVar(1)
            outlier_cook = tkcheckbutton(fr_outlier, variable = cook.val)
            
            
            dev.val = tclVar(1)
            outlier_dev <- tkcheckbutton(fr_outlier, variable = dev.val, command = function(...){
              if(tclvalue(dev.val)=="1"){
                tclvalue(outlier_choice) = 1
                tkconfigure(outlier_dev.entry, state = "normal")
              }else{
                tkconfigure(outlier_dev.entry, state = "disable")
              }
            }) 
            outlier_dev_level <- tclVar("20")
            outlier_dev.entry <- tkentry(fr_outlier, width = 3, textvariable = outlier_dev_level, bg = "white")
            
            
            
            
            
            tkgrid(labeloutlier, outlier_no, tklabel(fr_outlier, text = "No "))
            tkgrid(tklabel(fr_outlier, text = "   "), outlier_yes, tklabel(fr_outlier, text = "Yes"),
                   tklabel(fr_outlier, text = " ("),
                   outlier_cook,tklabel(fr_outlier, text = "Cook's Distance, "),
                   outlier_CI,tklabel(fr_outlier, text = "Confidence Interval"),
                   outlier_CI.entry,tklabel(fr_outlier, text = "(0~1), "),
                   outlier_dev,tklabel(fr_outlier, text = "Deviation"),outlier_dev.entry,
                   outlier_CI.entry,tklabel(fr_outlier, text = "% (0~100) )"))
            
            
            
            
            
            tkgrid(tklabel(fr_mod,text="", height = 0, font = fontIntro_para))
            #
            onRun <- function(){
              
              m <- c("lm","qm")
              w <- c("1","x","x2")
              dtp <- c("all","cook","conf","bias")
              
              if(sum(as.numeric(c(tclvalue(mod_l.val),tclvalue(mod_q.val))))==0|sum(as.numeric(c(tclvalue(weight_1.val),tclvalue(weight_x.val),tclvalue(weight_x2.val))))==0){
                tkmessageBox(title = "Error", message = "Please select the model or the weighting method.", icon = "error", type = "ok")
                cat("Please select the model or the weighting method.")
                stop("Please select the model or the weighting method.")
              }
              
              tkdestroy(ParaSet)
              # tkconfigure(tt,cursor="watch")
              
              m <- m[as.numeric(c(tclvalue(mod_l.val),tclvalue(mod_q.val)))==1]
              w <- w[as.numeric(c(tclvalue(weight_1.val),tclvalue(weight_x.val),tclvalue(weight_x2.val)))==1]
              dtp <- dtp[as.numeric(1,tclvalue(cook.val),tclvalue(cI.val),tclvalue(dev.val))==1]
              
              
              
              
              CI_level=as.numeric(tclvalue(outlier_CI_level))
              bias_thr=as.numeric(tclvalue(outlier_dev_level))
              
              outpath = paste(tclvalue(textoutput), "/Concentration Calibration", sep = "")
              
              peak_info <- cali_table[,1:4]
              df <- cali_table[,5:ncol(cali_table)]
              conc <- as.numeric(sapply(1:ncol(df), function(x)strsplit(colnames(df)[x],"_")[[1]][2]))
              df <- df[,order(conc)]
              
              model_out(peak_info=peak_info,df=df,m=m,w=w,dtp=dtp,CI_level=CI_level,bias_thr=bias_thr,outpath=cali_table_outpath)
              
              tkmessageBox(title = "Concentration Calibration - Calibration Curve Construction", message = "Concentration Calibration - Calibration Curve Construction is done.", icon = "info", type = "ok")
              cat("Concentration Calibration - Calibration Curve Construction is done.\n")
              
            }
            tkgrid(tklabel(ParaSet, text = ""))
            
            fr_Run <- tkframe(ParaSet)
            Run.but     <-tkbutton(fr_Run,text="    Run    ",command=onRun)
            # Cancel.but <-tkbutton(fr_Run,text="   Cancel   ",command=function()
            # {
            #   tkdestroy(ParaSet)
            #   tkfocus(tt)
            # })
            # 
            # tkgrid(tklabel(fr_Run,text="               "), OK.but,tklabel(fr_Run,text="                                      "), Cancel.but, tklabel(fr_Run,text="               "))
            tkgrid(Run.but)
            tkgrid(tklabel(fr_Run, text = "", height = 0, font = fontIntro_para))
            tkgrid(fr_Run)
            # 
            
            
            
          }else{
            tkmessageBox(title = "Error", message = "Sample size should more than 4.\nPlease .", icon = "error", type = "ok")
            cat("Data Import(Error) - Sample size should more than 4.\n")
            tkfocus(QC)
          }
          
          
          
          
        })
        
        tkgrid(next.button)
        tkgrid(tklabel(fr_next, text = "", height = 0, font = fontIntro_para))
        tkgrid(fr_next)
        # tkwait.window(fr_qc)
        
        ##
      })
      tkgrid(conti.button)
      tkgrid(tklabel(contiframe, text = "", height = 0, font = fontIntro_para))
      tkgrid(contiframe)
      
    }else{
      tkmessageBox(title = "Error", message = "File is not found.\nPlease input the correct directories.", icon = "error", type = "ok")
      cat("Data Import(Error) - File is not found. Please input the correct directories.\n")
      tkfocus(dlg)
    }
    
    
    
  })
  Cancel.but <-tkbutton(fr,text="   Cancel   ",command=onCancel)
  tkgrid(tklabel(fr,text="               "), contin.but,tklabel(fr,text="                                                         "), Cancel.but, tklabel(fr,text="               "))
  tkgrid(tklabel(fr,text="    ", height = 0, font = fontIntro_para))
  
  tkbind(dlg, "<Destroy>", function() {tkgrab.release(dlg);tkfocus(tt)})
  
  
  tkwait.window(dlg)
  
}


